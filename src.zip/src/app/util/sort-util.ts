export class sortUtil {
    private sortOrder = -1; // ascending by default
  
    constructor() {}
  
    public compareFuntn(
      sortOrder: string,
      columnProperty: string,
      data_type: string
    ) {
      if (sortOrder === 'Desc') {
        this.sortOrder = 1;
      }
  
      return (a: string, b: string) => {
        if (data_type === 'date') {
          return this.compare(
            new Date(this.getValueFromProperty(a, columnProperty)),
            new Date(this.getValueFromProperty(b, columnProperty))
          );
        } else {
          return this.compare(
            this.getValueFromProperty(a, columnProperty),
            this.getValueFromProperty(b, columnProperty)
          );
        }
      };
    }
  
    private compare(a: any, b: any) {
      if (a === b) {
        return 0;
      } else if (a === null) {
        return 1;
      } else if (b === null) {
        return -1;
      } else if (
        (typeof a === 'string' && typeof b === 'string' && a.toUpperCase() < b.toUpperCase()) || 
        (typeof a !== 'string' && typeof b !== 'string' && a < b)) {
        return 1 * this.sortOrder;
      } else if (
        (typeof a === 'string' && typeof b === 'string' && a.toUpperCase() > b.toUpperCase()) || 
        (typeof a !== 'string' && typeof b !== 'string' && a > b)) {
        return -1 * this.sortOrder;
      } else {
        return 0;
      }
    }
    private getValueFromProperty(object: any, property: string): any {
      if (!object || !property) {
        return null;
      }
      let index = property.indexOf('.');
      if (index > -1) {
        return this.getValueFromProperty(
          object[property.substring(0, index)],
          property.substring(index + 1)
        );
      }
      return object[property];
    }
  }
  