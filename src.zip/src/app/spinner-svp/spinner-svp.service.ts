import { Injectable, EventEmitter} from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SpinnerServiceSVP {
  private messageSource = new BehaviorSubject(false);
  currentMessage = this.messageSource.asObservable();

  showorHide(input: boolean) {
    this.messageSource.next(input);
  }
}