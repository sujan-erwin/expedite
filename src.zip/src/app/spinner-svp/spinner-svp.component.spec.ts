import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpinnerSVPComponent } from './spinner-svp.component';

describe('SpinnerSVPComponent', () => {
  let component: SpinnerSVPComponent;
  let fixture: ComponentFixture<SpinnerSVPComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpinnerSVPComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpinnerSVPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
