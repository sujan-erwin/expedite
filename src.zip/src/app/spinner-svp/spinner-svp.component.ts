import { Component, OnInit } from '@angular/core';
import { SpinnerServiceSVP } from './spinner-svp.service';

@Component({
  selector: 'app-spinner-svp',
  templateUrl: './spinner-svp.component.html',
  styleUrls: ['./spinner-svp.component.scss']
})
export class SpinnerSVPComponent implements OnInit {

  show: boolean =false;
  constructor(private spinnerServicey: SpinnerServiceSVP) { }

  ngOnInit() {
    this.spinnerServicey.currentMessage.subscribe(data =>{
      console.log("show"+ data);
      this.show = data;
    });
  }

}
