import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { InternalPatientDocumentsComponent } from './internal-patient-documents.component';
import { DatePipe } from '@angular/common';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { SpinnerService } from '../spinner/spinner.service';
import { RouterModule, ActivatedRoute, Params } from '@angular/router';
import { FormsModule, NgModel, ReactiveFormsModule } from '@angular/forms';
import { MultiselectComponent } from './multiselect/multiselect.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../services/auth.service';
import { PatientDocumentService } from '../services/patientDocument.service';
import { SearchService } from '../services/search.service';
import { By } from "@angular/platform-browser";
import { of } from 'rxjs/Observable/of'; 
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs';
import 'rxjs/add/observable/from';
import 'rxjs/add/observable/of';
import { type } from 'os';

describe('InternalPatientDocumentsComponent', () => {
  let component: InternalPatientDocumentsComponent;
  let fixture: ComponentFixture<InternalPatientDocumentsComponent>;
  let params: Subject<Params>;
  let searchService: SearchService;
  let modalService: NgbModal;
  const firstName = 'peggy', lastName = 'Heist', dateOfBirth = '12/21/2000', ssId = "ssId", assigningAuthority = 'assigningAuthority', id = 'id', docSearchDate = 'docSearchDate';
  const testUserName = '9025804', gender='Female', addressline1="123 Prospect Ln", city="Chicago", zipcode="12345", state="IL";
  let docList = '{"docRefs":[{"id": "391","title": "Ambulatory Summary","status": "Relevant Document Retrieval Success","type": "Ambulatory Summary","typeCode": "34133-9","orgName": "ABCClinic","url": "/Binary?documentId=2.16.840.1.113883.3.2054.2.1.204666161&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.112", "contentType": "text/xml","encounterDate": "2020-01-12T00:00","data": null},{"id": "390","title": "Ambulatory Summary", "status": "Relevant Document Retrieval Success","type": "Ambulatory Summary","typeCode": "34133-9","orgName": "GHYClinic","url": "/Binary?documentId=2.16.840.1.113883.3.2054.2.1.204666161&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.112", "contentType": "text/xml","encounterDate": "2020-01-12T00:00","data": null}]}'

  beforeEach(waitForAsync(() => {
    params = new Subject<Params>();
    TestBed.configureTestingModule({
      declarations: [InternalPatientDocumentsComponent, MultiselectComponent],
      imports: [FormsModule, ReactiveFormsModule, HttpClientModule, HttpClientModule, NgbModule, RouterModule.forRoot([], { relativeLinkResolution: 'legacy' })],
      providers: [AuthService, PatientDocumentService, DatePipe, SpinnerService,SearchService,NgbModal,
        {
          provide: ActivatedRoute, useValue: { queryParams : Observable.of({statusCode:"200", httpStatusCode: "200"}) }
         
        },]
      })
      .compileComponents();
  }));

  beforeEach(() => {
    searchService = TestBed.get(SearchService);
    const pSevice: PatientDocumentService = TestBed.get(PatientDocumentService);
    const httpClient: HttpClient = TestBed.get(HttpClient);
    const authService: AuthService = TestBed.get(AuthService);
    modalService = TestBed.get(NgbModal);
      const patient = {
        "HBSID": "9308198",
        "firstName": firstName,
        "lastName": lastName,
        "gender":gender,
        "dob":dateOfBirth,
        "addressline1": addressline1,
        "city":city,
        "zipCode":zipcode,
        "state":state,
        "docSearchDate":docSearchDate

      }

      const resource = {
         "docRefs": JSON.parse(docList).docRefs,
         "prescriber": "John"
      };
      // spyOn(authService, 'getUser').and.returnValue({ userName: testUserName });
      spyOn(httpClient, 'post').and.returnValue(of({}));
    //   spyOn(searchService, 'getPatient').and.returnValue(patient);
    spyOn(searchService, 'getInternalResourceToPatient').and.returnValue(patient);
      spyOn(searchService, 'getInternalResource').and.returnValue(resource);
      spyOn(pSevice, 'getDocList').and.returnValue(JSON.parse(docList).docRefs);
      fixture = TestBed.createComponent(InternalPatientDocumentsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
    //expect(component.patient).toBeTruthy()

  });

  it('should check all the fields are loaded to component', () => {
     const orgFilters =  fixture.debugElement.query(By.css('.container3'));
     const typeFilters = fixture.debugElement.query(By.css('.container4'));
     const view = fixture.debugElement.query(By.css('.view'));
     const searchBar = fixture.debugElement.query(By.css('#searchBar'));

expect(orgFilters).toBeTruthy();
expect(typeFilters).toBeTruthy();
expect(view).toBeTruthy();
expect(searchBar).toBeTruthy();


  });

  it('shod show dob fname lname in header', () => {
  fixture.detectChanges();
   const pname =      fixture.debugElement.nativeElement.querySelector('.patientName');
    expect(pname).toBeTruthy();
   expect(pname.innerHTML).toContain('Heist, peggy');

  });

  it('should send feedback when click on yes', () => {

    component.show =true;
    fixture.detectChanges();
    spyOn(component, 'feedbackAnswerYes');
   const optY =  fixture.debugElement.nativeElement.querySelector('.optionYes');
    optY.click();
    expect(optY).toBeTruthy();
  });

  it('should open dialog when feeback option is NO', () => {
    component.show =true;
    fixture.detectChanges();
    spyOn(component,'open');
   const optN =  fixture.debugElement.nativeElement.querySelector('.optionNo');
    optN.click();
    component.showFeedbackComment = true;
    fixture.detectChanges();
      
    // spyOn(modalService, 'open').and.callFake(() => Promise.resolve({}));

     expect(optN).toBeTruthy();

  });

it('should clear text in search bar ', () => {

  const searchInput = fixture.nativeElement.querySelector('#searchBar');
  searchInput.value = '12345'
  searchInput.dispatchEvent(new Event('input'));
  fixture.detectChanges();
  const clearAll= fixture.nativeElement.querySelector('.clearAll');
  expect(clearAll).toBeTruthy();
  clearAll.click();
  fixture.detectChanges();
  expect(searchInput.value).toBe('');

});  

  it('should update filter values', () => {
    expect(component.typeFilterValues.length).toBeGreaterThan(0);
    expect(component.organizationFilterValues.length).toBeGreaterThan(0);
  });
  it('should filter DocList and populate matched org name', () => {
    component.filterDocuments('');
    expect(component.filterDocuments.length).toBeGreaterThan(0);
    component.populateMatchedOrgname();
    expect(component.matchedOrgname).toBe('ABCClinic');
  });
  it('should get feedback value - Yes', () => {
    spyOn(searchService, 'captureFeedback').and.callFake(()=>{return Observable.from(['{}'])});
    component.feedbackAnswerYes();
    expect(searchService.captureFeedback).toHaveBeenCalled();
  });
  it('should get feedback value - No with comments', () => {
    spyOn(searchService, 'captureFeedback').and.callFake(()=>{return Observable.from(['{}'])});
    component.commentSectionForm.controls['comments'].setValue('Got some info');
    component.feedbackAnswerComment();
    expect(searchService.captureFeedback).toHaveBeenCalled();
  });
  it('should call search service with keyword ABCClinic', () => {
    component.filterDocuments('');
    expect(component.filterDocuments.length).toBeGreaterThan(0);
    component.populateMatchedOrgname();
    expect(component.matchedOrgname).toBe('ABCClinic');
  });
});
