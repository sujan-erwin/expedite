import { Component, Input, Output, EventEmitter, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subject, BehaviorSubject } from 'rxjs';
@Component({
    templateUrl: './multiselect.component.html',
    selector: "app-multiselect",
    styleUrls: ['./multiselect.component.scss'],
    providers: [{
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => MultiselectComponent),
        multi: true
    }]
})
export class MultiselectComponent {
    @Input() name: string;
    @Input() values: string[];
    @Input() matchedOrgname: string;
    @Input() selected: boolean[];
    @Output() public applyFilter = new EventEmitter<any[]>();
    onChange;
    constructor() {
        this.selected = [];

    }
    ngOnInit() {
    }

    updateValues() {
        const selectedValues = Object.keys(this.selected).filter(value => this.selected[value]);
        console.log(this.name);
        this.applyFilter.emit([this.name, selectedValues]);
    }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { }
    writeValue(val) {
        this.selected = [];
        val.forEach(item => this.selected[item] = true);

    }
}

