
export const errorBanners =
{
    externalPatientSearch:
    {
        7003:
        {
            title: "No documents found with advanced search",
            info: "NoDoc",
            type: "info"
        },
        7000:
        {
            title: "No patient found with advanced search",
            info: "Change the demographic information and try again",
            type: "error"
        },
        7303:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7303",
            type: "warning"
        },
        7304:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7304",
            type: "warning"
        },
        7305:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7305",
            type: "warning"
        },
        7306:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7306",
            type: "warning"
        },
        7307:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7307",
            type: "warning"
        },
        7308:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7308",
            type: "warning"
        },
        7403:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7403",
            type: "warning"
        },
        7404:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7404",
            type: "warning"
        },
        7405:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7405",
            type: "warning"
        },
        7406:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7406",
            type: "warning"
        },
        7407:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7407",
            type: "warning"
        },
        7408:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7408",
            type: "warning"
        },
        7500:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7500",
            type: "warning"
        },
        7501:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7501",
            type: "warning"
        },
        7502:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7502",
            type: "warning"
        },
        7503:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7503",
            type: "warning"
        },
        7504:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7504",
            type: "warning"
        },
        7505:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7505",
            type: "warning"
        },
        7506:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7506",
            type: "warning"
        },
        7507:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7507",
            type: "warning"
        },
        7508:
        {
            title: "We're experiencing service connectivity issues",
            info: "We cannot successfully carry out the search at this time, please try again later",
            statusCode: "7508",
            type: "warning"
        },
        default:
        {
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning"
        }
        
    },
    internalPatientSearch:
    {
        7000:
        {
            title: "No Patient found.Please try again",
            info: "NoPatient",
            type: "info"
        },
        7003:
        {
            title: "No docs found",
            info: "NoDocs",
            type: "info"
        },
        7015: {
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning",
            displayResponseStatus: true
        },
        7024:{
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning",
            displayResponseStatus: true
        },
        1111:{
            title: "Oops, something went wrong!",
            info: "No Internet connectivity",
            type: "warning",
            displayResponseStatus: true
        },
        7029:{
            code: 7029,
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning",
            displayResponseStatus: true
        },
        7001:{
            code: 7001,
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning",
            displayResponseStatus: true
        },
        7006:{
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning",
            displayResponseStatus: true
        },
        default:
        {
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning"
        }
    },
    lookupPatient: 
    {
        7000:
        {
            title: "No Patient found.Please try again",
            info: "NoPatient",
            type: "info"
        },
        7003:
        {
            title: "No docs found",
            info: "NoDocs",
            type: "info"
        },
        7023:
        {
            title: "No docs found",
            info: "NoDocs",
            type: "info"
        },
        7015: {
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning",
            displayResponseStatus: true
        },
        7024:{
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning",
            displayResponseStatus: true
        },
        7006:{
            title: "Oops, something went wrong!",
            info: "{errorDesc}",
            type: "warning",
            displayResponseStatus: true
        },
        7027:{
            title: "Multiple patient profiles are found. Please lookup by Patient Account Number",
            info: "MultiplePatientsfound",
            type: "info",
            multiplePatients: "To locate most recent records,"
        },
        1111:{
            title: "Oops, something went wrong!",
            info: "The connection has timed out",
            type: "warning",
            displayResponseStatus: true
        },
        default:
            {
                title: "Oops, something went wrong!",
                info: "{errorDesc}",
                type: "warning"
            }
    }
}