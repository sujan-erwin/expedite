import { Component, ViewChild, ElementRef, HostListener, AfterViewInit} from '@angular/core';
import {allPaths} from './app-routes';
import { environment } from '../environments/environment';
import { AuthService } from '../app/services/auth.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { SessionExpiryModalComponent } from './modules/session/components/session-expiry-modal/session-expiry-modal.component';
import { SpinnerService } from './spinner/spinner.service';
import { RouterStateSnapshot, Router, ActivationEnd, NavigationEnd } from '@angular/router';
import { tabPaths } from './tab-routes';
import { Location } from '@angular/common';
import { IdleService } from '../app/services/idle.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  firstName: string;
  title = 'DigitalLogin';
  subTitle = "Welcome DigitalLogin user!!";
  patientSearchURL = allPaths.quickLookUp.link
  pastSearchURL = allPaths.pastSearches.link;
  isPatientsTabActive = false;
  isPastsTabActive = false;
  KEYCODE_TAB: number = 9;

  timerCount: number;
  idleTimerLeft: string;
  secondTimerLeft: string;
  isModalOpen: boolean = false;
  
  constructor(
    private authService: AuthService,
    private modalService: NgbModal,
    private spinnerService: SpinnerService, private router: Router, location: Location, private idle: IdleService,
    private elementRef: ElementRef
) {
      router.events.subscribe((val) => {
        if (location.path() !== '' && val instanceof ActivationEnd) {
          let route = location.path();
          let path = route.split('/');  
        this.isPatientsTabActive = tabPaths.patientSearch.some((item=>item.link.indexOf(path[1])>0));
        this.isPastsTabActive = tabPaths.pastSearches.some((item=>item.link.indexOf(path[1])>0));
        }
      });
     }
     
     @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(
      event: KeyboardEvent
    ) {
      if (this.isModalOpen) this.continue();
    }
  
    @HostListener('document:keydown', ['$event'])
    handleTabKey(event: any) {
      this.handleTabKeyWInModel(
        event,
        '#sessionOutAlert',
        this.elementRef.nativeElement,
        'input,button,select,a,[tabindex]:not([tabindex="-1"])'
      );
    }

  ngOnInit() {
    let userProfile = this.authService.getUserProfile();
    this.firstName = userProfile?userProfile.firstName:'';
    //Start watching for user inactivity.
    // this.userIdle.startWatching();

    // // Start watching when user idle is starting.
    // this.userIdle.onTimerStart()
    //   //.pipe(first())
    //   .subscribe((response: any) => {
    //     console.log("timerStarted: "+response);
    //     if (!this.modalService.hasOpenModals()) {
    //       const modalRef = this.modalService.open(SessionExpiryModalComponent, { centered: true, size: 'lg', windowClass: 'main-class' });
    //       modalRef.result.then((reason) => {
    //         if(reason === 'Close click'){
    //           this.userIdle.stopTimer();
    //           this.modalService.dismissAll();
    //         } else if (reason === 'Sign out') {
    //           this.signOut();
    //         }
    //       })
    //     }
    //   });

    // // Start watch when time is up.
    
    // this.userIdle.onTimeout().subscribe(() => {
    //   console.log("timerup");
    //   this.modalService.dismissAll();
    //   this.signOut();
    // });
    // if (userProfile && userProfile.firstName) {
      console.log('started watching.....', new Date());
      this.initTimer(
        environment.userIdle.idleTime,
        environment.userIdle.timeout
      );
    // }
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.continue();
      }
    });
    var script = document.getElementsByTagName('script')[0];
    script.src = environment.config.qmURL;
  }

  goToHome(){
    this.router.navigate([allPaths.quickLookUp.link]);
  }
  signOut = function () {
    sessionStorage.clear();
    window.location.href = environment.config.URLEndPoint + '/login/#/login';
  }

  handleTabKeyWInModel(e, modelId: string, nativeElement, tagsList: string) {
    // console.log(e, modelId, nativeElement, tagsList);
    if (e.keyCode === this.KEYCODE_TAB && this.isModalOpen) {
      const focusable = nativeElement
        .querySelector(modelId)
        .querySelectorAll(tagsList);
      if (focusable.length) {
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        const shift = e.shiftKey;
        if (shift) {
          if (e.target === first) {
            last.focus();
            e.preventDefault();
          }
        } else {
          if (e.target === last) {
            first.focus();
            e.preventDefault();
          }
        }
      }
    }
  }
  initTimer(firstTimerValue: number, secondTimerValue: number): void {
    this.idle.USER_IDLE_TIMER_VALUE_IN_MIN = firstTimerValue;
    this.idle.FINAL_LEVEL_TIMER_VALUE_IN_MIN = secondTimerValue;
    console.log('idle : ', firstTimerValue, ' timeout : ', secondTimerValue);
    // Watch on timer
    this.idle.initilizeSessionTimeout();
    this.idle.userIdlenessChecker.subscribe((status: string) => {
      this.initiateFirstTimer(status);
    });

    this.idle.secondLevelUserIdleChecker.subscribe((status: string) => {
      this.initiateSecondTimer(status);
    });
  }

  showAlert() {
    // this.modal.show();
    // this.isModalOpen = true;
    this.handleTabKeyWInModel(
      { keyCode: this.KEYCODE_TAB },
      '#sessionOutAlert',
      this.elementRef.nativeElement,
      'input,button,select,a,[tabindex]:not([tabindex="-1"])'
    );
    if (!this.modalService.hasOpenModals()) {
      const modalRef = this.modalService.open(SessionExpiryModalComponent, { centered: true, size: 'lg', windowClass: 'main-class' });
      modalRef.result.then((reason) => {
        if(reason === 'Close click'){
          // this.userIdle.stopTimer();
          this.modalService.dismissAll();
          this.continue();
        } else if (reason === 'Sign out') {
          this.signOut();
        }
      })
    }
  }

  initiateFirstTimer = (status: string) => {
    switch (status) {
      case 'INITIATE_TIMER':
        break;

      case 'RESET_TIMER':
        break;

      case 'STOPPED_TIMER':
        this.showAlert();
        break;

      default:
        // this.idleTimerLeft = this.formatTimeLeft(Number(status));
        // console.log('idle timer',this.idleTimerLeft)
        break;
    }
  };

  initiateSecondTimer = (status: string) => {
    switch (status) {
      case 'INITIATE_SECOND_TIMER':
        break;

      case 'SECOND_TIMER_STARTED':
        break;

      case 'SECOND_TIMER_STOPPED':
        this.onLogout('true');
        break;

      default:
        this.secondTimerLeft = status;
        break;
    }
  };

  continue() {
    console.log('continued...');
    // this.modal.hide();
    // this.isModalOpen = false;
    this.modalService.dismissAll();
    // stop second timer and initiate idle timer again
    IdleService.runSecondTimer = false;
    this.idle.initilizeSessionTimeout();
  }
  onLogout(flag) {
    // stop all timer and end the session
    // this.isModalOpen = false;
    this.modalService.dismissAll();
    IdleService.runTimer = false;
    IdleService.runSecondTimer = false;
    this.signOut();
  }
}
