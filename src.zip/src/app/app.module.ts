import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';

import { AppComponent } from './app.component';

import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SpexInterceptor } from './util/spex-interceptor';
import { AuthGuard } from './util/auth-guard';

// import { CookieService } from 'ngx-cookie-service';

import { ErrorComponent } from './error/error.component';

import { NgxMaskModule } from 'ngx-mask';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SessionModule } from './modules/session/session.module';
import { ExternalPatientSearchComponent } from './externalPatientSearch/externalPatientSearch.component';
import { QuickLookUpComponent } from './quickLookup/quickLookup.component';
import {MatTabsModule} from '@angular/material/tabs';
import {MatButtonModule} from '@angular/material/button';
import {MatMenuModule} from '@angular/material/menu';
import {MatSidenavModule} from '@angular/material/sidenav';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BreadCrumbComponent } from './bread-crumb/bread-crumb.component';
import { PastSearchComponent } from './past-search/past-search.component';
import { DatePipe } from '@angular/common';
import { PatientDocumentsComponent } from './patient-documents/patient-documents.component';
import {InternalPatientDocumentsComponent} from './internal-patient-documents/internal-patient-documents.component';
import { MultiselectComponent } from './internal-patient-documents/multiselect/multiselect.component';
import { LookupPatientComponent } from './lookup-patient/lookup-patient.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { SpinnerService } from './spinner/spinner.service';
import { AutocompleteComponent } from './externalPatientSearch/autoAddress';
import { StoreModule } from '@ngrx/store';
import { reducer } from './patient-summary/store/patient-summary.reducer';
import { LabsComponent } from './patient-summary/labs/labs.component';
import { ProgressNotesComponent } from './patient-summary/progress-notes/progress-notes.component';
import { ConditionsComponent } from './patient-summary/conditions/conditions.component';
import { MedicationsComponent } from './patient-summary/medications/medications.component';
import { VitalsComponent } from './patient-summary/vitals/vitals.component';
import { AllergiesComponent } from './patient-summary/allergies/allergies.component';
import { MedicationsMapper } from './model/medications-mapper.model';
import {ProgressNotesMapper} from './model/progressNotes-mapper.model';
import { SpinnerSVPComponent } from './spinner-svp/spinner-svp.component';
import { PatientSummaryComponent } from './patient-summary/patient-summary.component';

const routes = [
 
 {
    path: 'advanced-search',
    component: ExternalPatientSearchComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'quick-lookup',
    component: QuickLookUpComponent,
    canActivate: [AuthGuard]
  },  
  {
    path: 'externalPatientSearch',
    component: ExternalPatientSearchComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'past-search',
    component: PastSearchComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'patient-documents',
    component: PatientDocumentsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'Patient-documents', //slight difference from PatientDocumentsComponent path (P uppercase)
    component: InternalPatientDocumentsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'lookup-patient', // combining Adv search & QL components
    component: LookupPatientComponent,
    canActivate: [AuthGuard]
  },
  {
    path: '**',
    component: ErrorComponent,
    canActivate: [AuthGuard]
  }    
];


@NgModule({
  declarations: [
    AppComponent,
    ErrorComponent,
    ExternalPatientSearchComponent,
    QuickLookUpComponent,
    BreadCrumbComponent,
    PastSearchComponent,
    PatientDocumentsComponent,
    InternalPatientDocumentsComponent,
    MultiselectComponent,
    LookupPatientComponent,
    SpinnerComponent,
    AutocompleteComponent,
    ConditionsComponent,
    PatientSummaryComponent,
    LabsComponent,
    ProgressNotesComponent,
    MedicationsComponent,
    VitalsComponent,
    AllergiesComponent,
    SpinnerSVPComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    NgxMaskModule.forRoot(),
    // FontAwesomeModule,
    NgbModule,
    MatTabsModule,
    MatButtonModule,
    MatMenuModule,
    MatSidenavModule,
    // UserIdleModule.forRoot({ idle: 3, timeout: 180, ping: 0 }),
    RouterModule.forRoot(routes, { useHash: true, scrollPositionRestoration: 'enabled', relativeLinkResolution: 'legacy' }),
    SessionModule,
    BrowserAnimationsModule,
    StoreModule.forRoot({'patientSummary': reducer})
  ],
  providers: [
    HttpClientModule, AuthGuard,DatePipe,SpinnerService,MedicationsMapper,ProgressNotesMapper,
    // CookieService,
    { provide: HTTP_INTERCEPTORS, useClass: SpexInterceptor, multi: true },
  ],
  bootstrap: [AppComponent],

})
export class AppModule { }

