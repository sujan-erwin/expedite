import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgxMaskModule } from 'ngx-mask';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule, DatePipe } from '@angular/common';
import { StoreModule } from '@ngrx/store';

import { AppComponent } from './app.component';
import { ErrorComponent } from './components/error/error.component';
import { SpinnerService } from './services/spinner/spinner.service';
import { reducer } from './patient-summary/store/patient-summary.reducer';
import { MedicationsMapper } from './model/medications-mapper';
import { PatientSummaryComponent } from './patient-summary/patient-summary.component';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './modules/shared/shared.module';
import { LookupPatientModule } from './modules/lookup-patient/lookup-patient.module';
import { InternalPatientDocumentsModule } from './modules/internal-patient-documents/internal-patient-documents.module';
import { ExternalPatientSearchModule } from './modules/external-patient-search/external-patient-search.module';
import { QuickLookupModule } from './modules/quick-lookup/quick-lookup.module';
import { PatientDocumentsModule } from './modules/patient-documents/patient-documents.module';
import { PastSearchModule } from './modules/past-search/past-search.module';
import { AuthGuard } from './guards/auth/auth-guard';
import { SpexInterceptor } from './interceptors/spex-interceptor';

@NgModule({
  declarations: [
    AppComponent,
    ErrorComponent,
    PatientSummaryComponent,
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    NgxMaskModule.forRoot(),
    NgbModule,
    BrowserAnimationsModule,
    StoreModule.forRoot({ 'patientSummary': reducer }),
    SharedModule,
    LookupPatientModule,
    InternalPatientDocumentsModule,
    ExternalPatientSearchModule,
    QuickLookupModule,
    PatientDocumentsModule,
    PastSearchModule,
  ],
  providers: [
    HttpClientModule,
    AuthGuard,
    DatePipe,
    SpinnerService,
    MedicationsMapper,
    {
      provide: HTTP_INTERCEPTORS, useClass: SpexInterceptor, multi: true
    },
  ],
  bootstrap: [AppComponent],

})
export class AppModule { }

