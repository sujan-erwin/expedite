import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { PastSearchComponent } from './past-search.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('PastSearchComponent', () => {
  let component: PastSearchComponent;
  let fixture: ComponentFixture<PastSearchComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ PastSearchComponent ],
      imports:[RouterTestingModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PastSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
