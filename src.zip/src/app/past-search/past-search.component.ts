import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { allPaths } from '../app-routes';


@Component({
  selector: 'app-past-search',
  templateUrl: './past-search.component.html',
  styleUrls: ['./past-search.component.scss']
})
export class PastSearchComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  onSubmit(){
    this.router.navigate([allPaths.quickLookUp.link]);
  }

}
