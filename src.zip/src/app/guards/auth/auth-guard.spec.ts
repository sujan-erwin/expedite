import { AuthGuard } from './auth-guard';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';



describe('AuthGuard', () => {

  let authGuard: AuthGuard;
  let httpClient: HttpTestingController;
  beforeEach(() => TestBed.configureTestingModule({
    providers: [AuthGuard],
    imports:[RouterTestingModule, HttpClientTestingModule]

  }));

  it('should create an instance', () => {
     const authGuard: AuthGuard = TestBed.get(AuthGuard);
    expect(authGuard).toBeTruthy();
  });
});
