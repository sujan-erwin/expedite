import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';

import {IPatientSummary} from './../patient-summary/store/patient-summary.interface';
import { AppInitialState } from './../patient-summary/store/api/app-initial.state';
import {PatientSummaryService} from './store/patient-summary.service';
import * as PatientSummaryActions from './store/patient-summary.action';



@Component({
  selector: 'app-patient-summary',
  templateUrl: './patient-summary.component.html',
  styleUrls: ['./patient-summary.component.scss']
})

export class PatientSummaryComponent implements OnInit {
  ipatientSummary: IPatientSummary;
  ipatientSummaryObserv: Observable<IPatientSummary>;
  constructor(private store: Store<AppInitialState>, private patientSummaryService: PatientSummaryService) {
    // this.ipatientSummary = (this.state.getValue()?.payload?.patientSummary || {});
    this.store.dispatch(new PatientSummaryActions.PatientSummarySuccess(this.patientSummaryService.getPatientSummary()));
    this.ipatientSummaryObserv = store.select('patientSummary');
    this.ipatientSummaryObserv.subscribe(result => {
      this.ipatientSummary = result;
    });

    console.info(this.ipatientSummary)
  }

  ngOnInit(): void {
  }

}
