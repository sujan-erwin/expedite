export interface IPatientSummary {
    patientId?: string;
    summaryHeader?: ISummaryHeader;
    vitals?: IVitals;
    conditions?: IConditions;
    labs?: ILabs;
    medications?: IMedications
    allergies?: IAllergies;
    notes?: IProgressNotes;
}

export interface ISummaryHeader {
    patient?: {
        id?: string;
        firstName?: string;
        lastName?: string;
        dob?: Date;
        sex?: string;
        address?: {
            street?: string;
            city?: string;
            state?: string;
            zip?: number;
        };
    };
    provider?: {
        id?: string;
        title?: string;
        firstName?: string;
        lastName?: string;
        status?: string;
    };
    organizations?: Array<{
        name?: string;
        id?: string;
    }>;
};

export interface IVitals {
    height?: {
        date?: string;
        value?: string | number;
    };
    weight?: {
        date?: string;
        value?: string | number;
    };
    bsa?: string;
    ccdURL?: string;
};

export interface IConditions {
    items?: Array<{
        id?: string;
        code?: string;
        description?: string;
        date?: string;
    }>;
    ccdURL?: string;
};

export interface ILabs {
    items?: Array<{
        id?: string;
        date?: string;
        facility?: string;
        doctor?: string;
        testType?: {
            name?: string;
            ccdURL?: string;
        };
    }>;
};

export interface IMedications {
    items?: Array<{
        id?: string;
        label?: string;
        qty?: string;
        instructions?: string;
        indications?: string;
        items?: Array<string>;
    }>; 
    ccdURL?: string;
};

export interface IAllergies {
    items?: Array<{
        id?: string;
        activeAllergy?: string;
        reaction?: {
            value?: string;
            severity?: string
        };
        date?: string;
    }>;
    ccdURL?: string;
};

export interface IProgressNotes {
    items?: Array<{
        date?: string;
        doctor?: string;
        content?: string;
    }>;
}
