import { IPatientSummary } from "./../patient-summary.interface";

export interface AppInitialState {
   readonly patientSummary: IPatientSummary
}