import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { IPatientSummary } from './patient-summary.interface';
import { AuthService } from 'src/app/services/auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class PatientSummaryService {
  user: any;
  getPatientSummary() {
    return this.mockPatientSummary;
  }
  public mockPatientSummary: IPatientSummary = {
    patientId: '1',
    summaryHeader: {
      patient: {
        id: '1',
        firstName: 'testuser1',
        lastName: 'testuserLastName',
        dob: new Date('1981-01-01'),
        sex: 'F',
        address: {
          street: '123 Main st',
          city: 'Downingtown',
          state: 'PA',
          zip: 19226,
        }
      },
      provider: {
        id: '100',
        title: 'DR',
        firstName: 'Michael',
        lastName: 'Roy',
        status: 'any',
      },
      organizations: [
        { name: 'united org', id: '1' },
        { name: 'org1', id: '2' },
        { name: 'org2', id: '3' }
      ]
    },
    vitals: {
      height: {
        date: '04/12/2021',
        value: '72'
      },
      weight: {
        date: '04/12/2021',
        value: '117'
      },
      bsa: '1.7',
      ccdURL: 'URL'
    },
    conditions: {
      items: [
        {
          id: 'R19.4',
          code: 'Z79.899',
          description: 'Controlled substance agreement signed',
          date: '04/12/2021'
        },
        {
          id: 'M10.01',
          code: 'S71.101A',
          description: 'Open wound of thigh',
          date: '04/12/2021'
        },
        {
          id: 'K10.01',
          code: 'ICD9',
          description: 'Hidradenitis suppurativa ',
          date: '04/12/2021'
        },
        {
          id: 'R11.01',
          code: 'ICD9',
          description: 'Essential hypertension',
          date: '04/12/2021'
        },
        {
          id: 'R11.01',
          code: 'ICD9',
          description: 'Controlled substance agreement signed',
          date: '04/12/2021'
        }
      ],
      ccdURL: 'URL'
    },
    labs: {
      items: [
        {
          id: '3',
          date: '04/12/2021',
          facility: 'st.Ives',
          doctor: 'Mark',
          testType: {
            name: 'Results',
            ccdURL: 'URL'
          }
        },
        {
          id: '4',
          date: '04/12/2021',
          facility: 'Harvard',
          doctor: 'Joe',
          testType: {
            name: 'TB Test',
            ccdURL: 'URL'
          }
        },
        {
          id: '5',
          date: '05/12/2021',
          facility: 'Humira Inst.',
          doctor: 'Smith',
          testType: {
            name: 'Stress Test',
            ccdURL: 'URL'
          }
        },
        {
          id: '6',
          date: '06/12/2021',
          facility: 'Health Org.',
          doctor: 'Walton',
          testType: {
            name: 'BP Test',
            ccdURL: 'URL'
          }
        }
      ]
    },
    medications: {
      items: [
        {
          id: '1',
          label: 'Doxycycline (VIBRAMYCIN) 100mg Capsule',
          qty: '60 Capsules',
          instructions: 'capsule by mouth 2x daily',
          indications: 'Hidradenitis suppurativa',
          items: ['Adalimumab (HUMIRA PEN 40MG/)', '04ML Pen-injector kit', '04ML Pen-injector kit', 'Adalimumab (HUMIRA PEN 40MG/)']
        },
        {
          id: '2',
          label: 'Insulin glargine (BASAGLAR) subcutaneous injection (pen)',
          qty: '6 ML',
          instructions: 'Inject 24 unites under the skin at bedtime',
          indications: 'Type 2 diabetes mellitus with hyperglycemia, long term current use of insulin (HCC)',
          items: ['item4', 'item5', 'item6']
        },
        {
          id: '3',
          label: 'Varencicline (CHANTIX) 1 mg tablet',
          qty: '60 Tablets',
          instructions: '1 tablet by mouth 2x daily',
          indications: 'Tobacco use',
          items: ['item4', 'item5', 'item6']
        }
      ],
      ccdURL: 'URL'
    },
    allergies: {
      items: [
        {
          id: '7',
          activeAllergy: 'Y',
          reaction: {
            value: 'Etanercept enzyme',
            severity: 'low'
          },
          date: '04/12/2021'
        },
        {
          id: '8',
          activeAllergy: 'N',
          reaction: {
            value: 'Epinephrine',
            severity: 'intolerance'
          },
          date: '05/12/2020'
        },
        {
          id: '9',
          activeAllergy: 'N',
          reaction: {
            value: 'Epinephrine',
            severity: 'intolerance'
          },
          date: '06/14/2020'
        },
        {
          id: '10',
          activeAllergy: 'N',
          reaction: {
            value: 'Epinephrine allergy',
            severity: '-'
          },
          date: '09/14/2020'
        },
      ],
      ccdURL: 'URL'
    },
    notes: {
      items: [
        {
          date: '09/15/2020',
          doctor: 'Mark',
          content: 'Reason for Consultation: Type 2 Diabetes Mellitus on  Ari A Luotonen is a 50 y.o. male with hx of Heart Failure. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
        },
        {
          date: '04/15/2020',
          doctor: 'John',
          content: 'Reason for Consultation: Type 2 Diabetes Mellitus on  Ari A Luotonen is a 50 y.o. male with hx of Heart Failure. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
        }
      ]
    }
  };

  constructor(
    private authService: AuthService,
    private httpClient: HttpClient
    ) {
  }

  /* medicationslist service call */
  medicationsList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      "requestedBy": "9308198",
      // "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.medicationsPatientSummary,
      JSON.stringify(data));
  }
  /* progressNotes service call */
  progressNotesList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      "requestedBy": "9308198",
      // "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.progressNotesSummary,
      JSON.stringify(data));
  }
  /* vitalslist service call for summary screen*/
  vitalsList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      "requestedBy": "9308198",
      // "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.vitalsSummary,
      JSON.stringify(data));
  }

  /* conditionslist service call for summary screen*/
  conditionsList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      "requestedBy": "9308198",
      // "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.conditionsSummary,
      JSON.stringify(data));
  }
// Allergies list service call
  allergiesList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      "requestedBy": "9308198",
      // "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.allergiesSummary,
      JSON.stringify(data));
  }

  /* MedCompletelist service call for Vitals screen*/
  completeMedicationsList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      "requestedBy": "9308198",
      // "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.completeMedicationsSummary,
      JSON.stringify(data));
  }

 /* progressNotes service call */
 completeProgressNotesList(hbsId: any, docSearchDate: any) {
  this.user = this.authService.getUser();
  var data = {
    "hbsId": hbsId,
    "docSearchDate": docSearchDate,
    "requestedBy": "9308198",
    // "requestedBy": this.user.userName,
  }
  return this.httpClient.post(
    this.getInternalServerEndPoint() + environment.config.path.completeProgressNotesSummary,
    JSON.stringify(data));
}

  /* vitalsCompletelist service call for Vitals screen*/
  completeVitalsList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      "requestedBy": "9308198",
      // "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.completeVitalsSummary,
      JSON.stringify(data));
  }
  /* vitalsCompletelist service call for Vitals screen*/
  completeConditionsList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      // "requestedBy": "9308198",
      "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.completeConditionsSummary,
      JSON.stringify(data));
  }

  /* AllergiesCompletelist service call for Vitals screen*/
  completeAllergiesList(hbsId: any, docSearchDate: any) {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "docSearchDate": docSearchDate,
      "requestedBy": "9308198",
      // "requestedBy": this.user.userName,
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.completeAllergiesSummary,
      JSON.stringify(data));
  }

  getProgressNoteFullDocument(documentRef: any): Observable<any> {
    this.user = this.authService.getUser();
    var data = {
      "docId": documentRef,
      "requestedBy": this.user.userName
      // "requestedBy": "9308198"
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.progessNotesViewDocument,
      JSON.stringify(data)).pipe(map(res => res),
        catchError(err => {
          return throwError(err);
        }));
  }

  getInternalServerEndPoint() {
    let serverEndPoint = environment.config.baseURL;
    console.log("env:", environment.env);
    if (environment.env === 'prod') {
      serverEndPoint = environment.config.baseURL;
    }
    return serverEndPoint;
  }
}
