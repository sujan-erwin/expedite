import { createReducer, on } from '@ngrx/store';
import * as PatientSummaryActions from './patient-summary.action';
import {PatientSummaryService} from './patient-summary.service';
import {IPatientSummary} from './patient-summary.interface'; 

export function reducer( state: IPatientSummary, action: PatientSummaryActions.Actions) {
      switch (action.type) {
        case PatientSummaryActions.PATIENT_SUMMARY_INVOKE: {
          return state;
        }
        case PatientSummaryActions.PATIENT_SUMMARY_SUCCESS: {
          return action.payload;
        }
        case PatientSummaryActions.PATIENT_SUMMARY_ERROR: {
          return action.payload;
        }
        default:
          return state;
      }
    }
