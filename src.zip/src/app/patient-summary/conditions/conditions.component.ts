import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { State, Store } from '@ngrx/store';
import {IPatientSummary} from '../../patient-summary/store/patient-summary.interface'; 
import { AppInitialState } from '../../patient-summary/store/api/app-initial.state';
import {PatientSummaryService} from '../store/patient-summary.service';
import * as PatientSummaryActions from '../store/patient-summary.action';

@Component({
  selector: 'app-conditions',
  templateUrl: './conditions.component.html',
  styleUrls: ['./conditions.component.scss']
})
export class ConditionsComponent implements OnInit {

  ipatientSummary: IPatientSummary;
ipatientSummaryObserv: Observable<IPatientSummary>;
@Output() showAdditionalDocs: EventEmitter<any> = new EventEmitter();


  constructor(private store: Store<AppInitialState>, private patientSummaryService: PatientSummaryService) { 
    this.store.dispatch(new PatientSummaryActions.PatientSummarySuccess(this.patientSummaryService.getPatientSummary()));
    this.ipatientSummaryObserv = store.select('patientSummary');
    this.ipatientSummaryObserv.subscribe(result => {
      this.ipatientSummary = result;
    });
    
    console.info(this.ipatientSummary)
  }

  ngOnInit(): void {
  }

  onClickShowaddDocs() {
    this.showAdditionalDocs.emit(true);
  }

}