import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-vitals',
  templateUrl: './vitals.component.html',
  styleUrls: ['./vitals.component.scss']
})
export class VitalsComponent implements OnInit {
  @Output() showAdditionalDocs: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }
  onClickShowaddDocs() {
    this.showAdditionalDocs.emit(true);
  }
}
