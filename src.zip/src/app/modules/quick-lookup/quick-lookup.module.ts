import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { QuickLookupRoutingModule } from './quick-lookup-routing.module';
import { QuickLookupComponent } from './quick-lookup.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    QuickLookupComponent
  ],
  imports: [
    CommonModule,
    QuickLookupRoutingModule,
    SharedModule,
  ]
})
export class QuickLookupModule { }
