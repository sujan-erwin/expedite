import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuickLookupComponent } from './quick-lookup.component';

const routes: Routes = [
  {
    path: '',
    component: QuickLookupComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class QuickLookupRoutingModule { }
