import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LookupPatientComponent } from './lookup-patient.component';

const routes: Routes = [
  {
    path: '', // combining Adv search & QL components
    component: LookupPatientComponent,
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class LookupPatientRoutingModule { }
