import { Component, OnInit, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Title } from "@angular/platform-browser";

import { SpinnerService } from 'src/app/services/spinner/spinner.service';
import { allPaths } from 'src/app/util/app-routes';
import { EncryptDecrypt } from 'src/app/services/crypto-js/crypto-js.encrypt.decrypt';
import { SearchService } from 'src/app/services/search/search.service';
import { PatientDocumentService } from 'src/app/services/patient-document/patient-document.service';
import { AuthService } from 'src/app/services/auth/auth.service';
import { DateValidator } from 'src/app/util/date-validator';
import { errorBanners } from 'src/app/util/error-messages';


@Component({
  selector: 'lookup-patient',
  templateUrl: './lookup-patient.component.html',
  styleUrls: ['./lookup-patient.component.scss']
})
export class LookupPatientComponent implements OnInit {

  @ViewChild('firstName') firstNameElement: ElementRef;
  @ViewChild('hbs') HBSIDElement: ElementRef;
  // @ViewChild('noPatientFoundWithDemo', { read: TemplateRef }) noPatientFoundWithDemo: TemplateRef<any>;
  @ViewChild('multiplePatientProfiles', { read: TemplateRef }) multiplePatientProfiles: TemplateRef<any>;

  patientLookupForm: FormGroup;
  result: any;
  selectedLink: any;
  isSubmitted: boolean;
  stateList: JSON;
  modalRef: any;
  demographicLookupFields: any = ['firstName', 'lastName', 'dob', 'zipCode', 'gender', 'addressline1', 'city', 'state'];
  isPatientNotFound: boolean = false;
  multiplePatientProfileList: Array<any> = [];
  selectedMultiplePatientProfileId: String = '';
  isSelectedMultiplePatientsProfileID: boolean = false;
  disableFields: boolean = false;
  initialDelayAfterQueueingPatient = 29000;

  constructor(
    fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private searchService: SearchService,
    private spinnerService: SpinnerService,
    private patientDocService: PatientDocumentService,
    private modalService: NgbModal,
    private titleService: Title,
    private encryptDecrypt: EncryptDecrypt,
  ) {
    this.result = {};
    this.result.display = false;
    this.stateList = this.searchService.getStateList();
    window.onunload = function () {
      sessionStorage.removeItem('hbsId');
      sessionStorage.setItem('lookUpOption', this.encryptDecrypt.aesEncrypt(JSON.stringify('HBS')));
    }
    this.patientLookupForm = fb.group({
      patientLookUpOption: ['HBS', [Validators.required]],
      HBSID: [''],
      firstName: [''],
      lastName: [''],
      dob: [''],
      zipCode: [''],
      gender: [''],
      addressline1: [''],
      addressline2: [''],
      city: [''],
      state: [''],
      phone: [''],
      NPI: ['']
    });
    // this.setPatientLookUpOptionsValidators();
    this.applyDemographicValidators();
    this.titleService.setTitle("Dataviewer - Lookup Patient");
    const HBSID_VAL = this.searchService.retrieveHbsId();
    const Demo_VAL = this.searchService.retrieveDemographicsInfo();
    const lookUpOption_VAL = this.searchService.retrieveLookupOption();
    if (HBSID_VAL) {
      this.HBSID.setValue(HBSID_VAL);
    }
    if (Demo_VAL) {
      this.patientLookupForm.setValue(Demo_VAL);
      if (Demo_VAL.addressline1 && Demo_VAL.city && Demo_VAL.state) {
        this.isPatientNotFound = true;
      }
    }
    //Hide Addressline fields on click of patient lookup breadcrumbs
    this.searchService.getDemoFieldsStatus().subscribe(status => {
      if (status) {
        this.isPatientNotFound = false;
        this.resetAddressFieldsValidators();
      }
    });
    if (lookUpOption_VAL && lookUpOption_VAL !== "refresh") {
      this.patientLookUpOption.setValue(lookUpOption_VAL, { emitEvent: false });
    } else {
      this.searchService.storeLookupOption(this.patientLookUpOption.value);
    }
    if (this.patientLookUpOption.value === 'HBS') {
      this.patientLookupForm.controls['HBSID'].setValidators([Validators.required]);
    }
  }

  ngOnInit() {
  }
  radioChecked(value) {
    console.log(value)
  }

  setValidatorForDemographicFields(validators: any): void {
    var lookupFields = ['firstName', 'lastName', 'dob', 'zipCode', 'gender', 'addressline1', 'city', 'state'];
    if (validators === null) {
      for (var val of lookupFields) {
        this.patientLookupForm.controls[val].clearValidators();
        this.patientLookupForm.controls[val].updateValueAndValidity();
      }
    } else {
      this.applyDemographicValidators();
    }
  }

  applyAddressFieldsValidators() {
    var lookupFields = ['addressline1', 'city', 'state'];
    for (var val of lookupFields) {
      this.patientLookupForm.controls[val].setValidators(Validators.required);
      this.patientLookupForm.controls[val].reset();
    }
  }
  // making Addressline validators not required
  resetRequiredAddressFields() {
    var lookupFields = ['addressline1', 'city', 'state'];
    for (var val of lookupFields) {
      this.patientLookupForm.controls[val].setValidators([]);
      this.patientLookupForm.controls[val].reset();
    }
  }

  resetAddressFieldsValidators() {
    var lookupFields = ['addressline1', 'city', 'state'];
    for (var val of lookupFields) {
      this.patientLookupForm.controls[val].reset();
    }
  }

  applyDemographicValidators() {
    var lookupFields = ['firstName', 'lastName', 'dob', 'gender', 'zipCode'];
    for (var val of lookupFields) {
      if (val === 'dob') {
        this.patientLookupForm.controls[val].setValidators([Validators.required, DateValidator]);
      } else if (val === 'zipCode') {
        this.patientLookupForm.controls[val].setValidators([Validators.required, Validators.pattern('[0-9]{5}')]);
      } else {
        this.patientLookupForm.controls[val].setValidators(Validators.required);
      }
    }
  }

  resetOptionValue() {
    const hbsID = this.patientLookupForm.get('HBSID');
    this.isSubmitted = false;
    this.clearSearch();
    this.searchService.storeLookupOption(this.patientLookUpOption.value);
    this.isPatientNotFound = false;
    this.disableFields = false;
    if (this.patientLookUpOption.value === 'HBS') {
      this.patientLookupForm.controls['HBSID'].setValidators([Validators.required]);
      this.setValidatorForDemographicFields(null);
    } else {
      hbsID.clearValidators();
      hbsID.updateValueAndValidity();
      this.setValidatorForDemographicFields(Validators.required);
    }

  }

  startSearch() {
    this.router.navigate([allPaths.advancedSearch.link]);
  }

  onSubmit() {
    this.searchService.setShowfeedbackQuestion(true);
    this.isSubmitted = true;
    this.resetErrorBanner();
    console.info(this.patientLookUpOption.value);
    console.info("on submit", this.patientLookupForm);
    if (this.patientLookUpOption.value === 'HBS') {
      if (!this.patientLookupForm.controls.HBSID.value) {
        this.patientLookupForm.controls['HBSID'].setErrors({ 'required': true });
        return;
      }
      this.searchService.setPatient(this.patientLookupForm.value);
      this.searchService.storeHbsId(this.patientLookupForm.value.HBSID);
      const hbsId = this.patientLookupForm.value.HBSID;
      this.searchService.searchInternalPatient(hbsId, 'retryFalse').subscribe(data => { this.handleHbsIdSearchResponse(data) }, (error) => {
        if (error.response) {
          this.handleError(error.response, error.response.statusCode, error.status);
          console.log("errorResponse", error.response);
        }
        else {
          this.handleError(null, null, null);
        }
      });
    }
    else if (this.patientLookupForm.valid && this.patientLookUpOption.value === 'demographic') {
      console.info(this.patientLookupForm.value);
      if (!this.result.displayDemographicError && !this.isPatientNotFound) {
        this.searchService.setPatient(this.patientLookupForm.value);
        this.searchService.storeDemographicsInfo(this.patientLookupForm.value);
        this.searchService.storeLookupOption(this.patientLookUpOption.value);
        this.searchService.searchPatientByDemo(this.patientLookupForm.value).subscribe(data => { this.handleDemographicSearchResponse(data) }, (error) => {
          console.log("PatientInfoValuewithDemo", this.patientLookupForm.value);
          if (error.response) {
            this.handleError(error.response, error.response.statusCode, error.status);
          }
          else {
            this.handleError(null, null, null);
          }
        });
      } else {
        this.searchService.setPatient(this.patientLookupForm.value);
        this.searchService.storeDemographicsInfo(this.patientLookupForm.value);
        this.searchService.storeLookupOption(this.patientLookUpOption.value);
        this.searchService.searchPatientByAddressDemo(this.patientLookupForm.value).subscribe(data => { this.handleDemographicSearchResponse(data) }, (error) => {
          console.log("PatientInfoValuewithDemo", this.patientLookupForm.value);
          if (error.response) {
            this.handleError(error.response, error.response.statusCode, error.status);
          }
          else {
            this.handleError(null, null, null);
          }
        });
      }

    }
  }

  handleSearchResponse(body) {
    this.isPatientNotFound = false;
    if (body && body.response) {
      if (body.response.statusCode === '0000') {
        console.log("response", body.response);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        if (body.response.resources && body.response.resources.length > 0) {
          let list = body.response.resources[0].docRefs;
          list = list.filter(doc => doc.contentType == "text/xml");
          this.patientDocService.setDocList(list);
          this.patientDocService.setPrescriber(body.response.resources[0].prescriber);
          this.router.navigate([allPaths.internalPatientDocuments.link]);
        } else {
          this.result.display = true;
          this.result.banner = errorBanners.lookupPatient[7004];
        }
      } else if (body.response.statusCode === '7003') {
        this.searchService.setShowfeedbackQuestion(false);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        this.searchService.setSourceLookupPage('Patient lookup');
        localStorage.setItem('patientLookup', 'Patient lookup');
        localStorage.removeItem("quickLookup");
        if (this.isSelectedMultiplePatientsProfileID && this.selectedMultiplePatientProfileId) {
          localStorage.setItem('isMPDocsNotFound', 'true');
        } else {
          localStorage.setItem('isMPDocsNotFound', 'false');
        }
        this.router.navigate([allPaths.internalPatientDocuments.link]);
      }
      else {
        this.handleError(body.response, body.response.statusCode, null);
      }
    }
    else {
      let body = {
        statusCode: "Unknown",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleError(body, body.statusCode, null);
    }
  }

  handleError(response, statusCode, httpStatusCode) {
    this.resetErrorBanner();
    this.spinnerService.hide();
    this.result.display = true;
    if (response) {
      console.log("Error response", response);
      this.result.banner = errorBanners.lookupPatient[response.statusCode];
    } else {
      this.result.banner = errorBanners.lookupPatient[1111];
    }
    if (!this.result.banner) {
      let code = statusCode ? statusCode : 'default';
      this.result.banner = errorBanners.lookupPatient[code];
    }
    if (statusCode) {
      if (this.result.banner && this.result.banner.displayResponseStatus) {
        this.result.banner.info = '';
        if (httpStatusCode) {
          this.result.banner.info = httpStatusCode + ' - ';
        }
        this.result.banner.info += `${statusCode} - ${response?.statusDesc}`;
      }
      else {
        this.handleDisplayError(response, statusCode);
      }
    }
  }

  handleDisplayError(response, statusCode) {
    if (this.patientLookupForm.get("patientLookUpOption").value === 'demographic') {
      this.result.displayDemosError = true;
      // this.result.displayDemographicError = false;
      if (statusCode === '7027') {
        this.result.display = false;
        if (response.resources && response.resources.length > 0) {
          this.multiplePatientProfileList = response.resources;
          // this.selectedMultiplePatientProfileId = this.multiplePatientProfileList[0].id;
          this.isSelectedMultiplePatientsProfileID = false;
          this.selectedMultiplePatientProfileId = '';
          this.modalRef = this.modalService.open(this.multiplePatientProfiles, { centered: true, size: 'lg' }).result.then((result) => {
          }, (reason) => {
            this.close();
          });
        }
      } else if (statusCode == '7000') {
        this.result.displayDemographicError = true;
        this.result.displayDemosError = false;
        this.isSubmitted = false;
        this.isPatientNotFound = true;
        if (this.searchService.isClearDisableReqFields) {
          this.disableFields = false;
          this.searchService.isClearDisableReqFields = false;
          this.isPatientNotFound = false;
        } else {
          this.disableFields = true;
        }
        const Demo_VAL = this.searchService.retrieveDemographicsInfo();
        this.applyAddressFieldsValidators();
        if (Demo_VAL) {
          this.patientLookupForm.setValue(Demo_VAL);
        }
      }
    }
    else if (this.patientLookupForm.get("patientLookUpOption").value === 'HBS') {
      this.result.displayHBSIDError = true;
    }
  }

  viewPatientProfile() {
    this.searchService.setShowfeedbackQuestion(true);
    console.log("viewPartientProfile() method is getting triggered");
    this.searchService.searchInternalPatient(this.selectedMultiplePatientProfileId, 'retryFalse').subscribe(data => { this.handleSearchResponse(data) }, (error) => {
      if (error.response) {
        this.handleError(error.response, error.response.statusCode, error.status);
        console.log("errorResponse", error.response);
      }
      else {
        this.handleError(null, null, null);
      }
    });
    this.isSelectedMultiplePatientsProfileID = false; // Retry bug fix test
    this.close();
  }
  onItemChange(value) {
    this.selectedMultiplePatientProfileId = value;
    this.isSelectedMultiplePatientsProfileID = true;
  }

  // close the modal when user clicks cross button in the modal
  close() {
    this.modalService.dismissAll();
  }
  runSearchAgain() {
    this.close();
    this.clearSearch();
  }

  enableFields() {
    this.disableFields = false;
    this.isPatientNotFound = false;
    this.resetRequiredAddressFields();
  }

  advancedSearch() {
    this.searchService.setSourcePage('lookupPatientPage');
    this.router.navigate([allPaths.advancedSearch.link]);
    this.close();
  }

  closeBanner() {
    this.result.display = false;
  }

  resetErrorBanner() {
    this.result.display = false;
    this.result.displayHBSIDError = false;
    this.result.displayDemosError = false;
    this.result.displayDemographicError = false;
  }

  setradio(id, value) {
    this.resetErrorBanner();
    this.patientLookupForm.reset();
    document.getElementById(id).focus();
    this.patientLookupForm.get("patientLookUpOption").setValue(value);
    this.isSubmitted = false;
    this.close();
  }

  clearSearch() {
    this.isSubmitted = false;
    this.resetErrorBanner();
    this.resetFormFieldsExceptLookUpOption();
    this.searchService.storeHbsId(null);
    this.searchService.storeDemographicsInfo(null);
    this.searchService.setPatient(null);
    this.searchService.setResource(null);
    this.disableFields = false;
    this.resetRequiredAddressFields();
    this.isPatientNotFound = false;

  }

  advStartSearch() {
    this.searchService.setInternalResource(null);
    this.searchService.setSourcePage('internalSearch');
    this.router.navigate([allPaths.advancedSearch.link]);
  }

  resetFormFieldsExceptLookUpOption() {
    Object.keys(this.patientLookupForm.controls).forEach(field => {
      if (field === 'patientLookUpOption') {
        return;
      }
      const control = this.patientLookupForm.get(field);
      if (control instanceof FormControl) {
        control.reset();
      }
    }
    );
  }

  restrictValue(control, type) {
    var newVal = control.value;
    if (type == 'numeric') {
      newVal = newVal.replace(/[^0-9]/g, '');
    } else {
      newVal = newVal.replace(/[^a-z0-9]/gi, '');
    }
    control.setValue(newVal);
  }

  maskDate(event) {
    if (event.inputType !== 'deleteContentBackward') {
      // remove all mask characters (keep only numeric)
      var newVal = event.target.value.replace(/[^0-9/]/g, '');
      // don't show braces for empty value
      if (newVal.length == 0) {
        newVal = '';
      } else {
        let dList = newVal.split("/");
        let count = (dList || []).length;
        //if the input already contains two / then format it.
        if (count >= 3) {
          newVal = this.formatDate(newVal);
        } else {
          if (newVal.length == 2) { //only with two chars decides whether to append zero or not.
            if (newVal.indexOf('/') == 1) {
              newVal = '0' + newVal;
            } else if (newVal.indexOf('/') < 0) { //if both chars are digits then append with / at end
              newVal = newVal.replace(/^(\d{0,2})/, '$1/');
            }
          } else if (newVal.length == 3) { //if user edit after entering 3 chars, we need append / accordingly.
            if (newVal.indexOf('/') != 2) {
              newVal = newVal.replace(/[^0-9]/g, ''); //clear all / and format it as below.
              newVal = newVal.replace(/^(\d{2})(\d{0,2})/, '$1/$2');
            }
          }
          else if (newVal.length == 5) { //when 5 chars, decide whether append dd with zero or not.
            if (newVal.substring(3, 5).indexOf('/') == 1) {
              newVal = newVal.substring(0, 3) + '0' + newVal.substring(3, 5);
            } else if (newVal.substring(3, 5).indexOf('/') < 0) { //if dd slash is not entered, then add it at end.
              newVal = newVal.replace(/[^0-9]/g, '');
              newVal = newVal.replace(/^(\d{0,2})(\d{0,2})/, '$1/$2/');
            }
          } else if (newVal.length >= 6) { //if length is more than 6 chars eligible for MM/DD/YYYY or it could be pasted content.
            newVal = this.formatDate(newVal);
          }
        }

      }
      // set the new value
      this.dob.setValue(newVal);
    }
  }

  formatDate(date) {
    let dList = date.split("/");
    let count = (dList || []).length;
    if (count >= 3 && (dList[0].length == 1 || dList[1].length == 1)) {
      if (dList[0].length == 1) {
        dList[0] = "0" + dList[0];
      }
      if (dList[1].length == 1) {
        dList[1] = "0" + dList[1];
      }
      date = dList[0] + "/" + dList[1] + "/" + dList[2];
    }
    return date;
  }

  fnNumbers(event) {
    if (event.charCode != 43 && event.charCode > 31 && (event.charCode < 48 || event.charCode > 57)) {
      return false;
    }
  }

  getAddress(event) {
    if (!event.place) {
      let address = event.address ? event.address : '';
      this.patientLookupForm.controls['addressline1'].setValue(address);
      return;
    }
    let postalField: HTMLInputElement = document.querySelector("#zipCode") as HTMLInputElement;
    let cityField: HTMLInputElement = document.querySelector("#city") as HTMLInputElement;
    let stateField = '';
    let options = {
      types: ['address'],
      componentRestrictions: {
        'country': ['us']
      },
      fields: ["address_components", "geometry"]
    }
    let address1 = "";
    for (const component of event.place.address_components as google.maps.GeocoderAddressComponent[]) {
      const componentType = component.types[0];
      switch (componentType) {
        case "street_number":
          address1 = `${component.long_name} ${address1}`;
          break;
        case "route":
          address1 += component.long_name;
          break;
        case "postal_code":
          postalField.value = component.long_name;
          break;
        case "locality":
          cityField.value = component.long_name;
          break;
        case "administrative_area_level_3":
          if (!cityField.value)
            cityField.value = component.long_name;
          break;
        case "sublocality_level_1":
          if (!cityField.value)
            cityField.value = component.long_name;
          break;
        case "administrative_area_level_1":
          stateField = component.short_name;
          break;
      }
    }
    const states: Array<any> = this.searchService.getStateList();
    const stateValue = states.find(state => state.abbreviation === stateField);
    this.patientLookupForm.controls['addressline1'].setValue(address1);
    this.patientLookupForm.controls['city'].setValue(cityField.value);
    this.patientLookupForm.controls['state'].setValue(stateValue.name);
    this.patientLookupForm.controls['zipCode'].setValue(postalField.value);
  }


  get firstName() { return this.patientLookupForm.get('firstName'); }
  get lastName() { return this.patientLookupForm.get('lastName'); }
  get HBSID() { return this.patientLookupForm.get('HBSID'); }
  get patientLookUpOption() { return this.patientLookupForm.get('patientLookUpOption'); }
  get dob() { return this.patientLookupForm.get('dob'); }
  get zipCode() { return this.patientLookupForm.get('zipCode'); }
  get gender() { return this.patientLookupForm.get('gender'); }
  get addressline1() { return this.patientLookupForm.get('addressline1'); }
  get addressline2() { return this.patientLookupForm.get('addressline2'); }
  get city() { return this.patientLookupForm.get('city'); }
  get state() { return this.patientLookupForm.get('state'); }
  get phone() { return this.patientLookupForm.get('phone'); }
  get NPI() { return this.patientLookupForm.get('NPI'); }

  ngOnDestroy() {
    if (this.modalService.hasOpenModals()) {
      this.close();
    }

  }

  handleDemographicSearchResponse(body) {
    // this.isPatientNotFound = false;
    // this.disableFields = false;
    if (body && body.response) {
      if (body.response.statusCode === '0000') {
        console.log("response", body.response);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        if (body.response.resources && body.response.resources.length > 0) {
          let list = body.response.resources[0].docRefs;
          list = list.filter(doc => doc.contentType == "text/xml");
          this.patientDocService.setDocList(list);
          this.patientDocService.setPrescriber(body.response.resources[0].prescriber);
          this.router.navigate([allPaths.internalPatientDocuments.link]);
        } else {
          this.result.display = true;
          this.result.banner = errorBanners.lookupPatient[7004];
        }
      } else if (body.response.statusCode === '7003') {
        this.searchService.setShowfeedbackQuestion(false);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        this.searchService.setSourceLookupPage('Patient lookup');
        localStorage.setItem('patientLookup', 'Patient lookup');
        localStorage.removeItem("quickLookup");
        this.router.navigate([allPaths.internalPatientDocuments.link]);
      } else if (body.response.statusCode === '7028') {
        console.log("response", body.response);
        let hbsId = body.response.resources[0].id;
        let transactionId = body.response.resources[0].transId;
        // Initial delay before first quick lookup call
        this.sleep(this.initialDelayAfterQueueingPatient);
        // Save transactionId in the context for background polling
        this.searchService.storeTransactionIdForPolling(transactionId);
        // Call quick lookup search here
        this.searchService.searchInternalPatientFromDemographicLookup(hbsId, transactionId).subscribe(data => { this.handleHbsIdSearchResponse(data) }, (error) => {
          if (error.response) {
            this.handleError(error.response, error.response.statusCode, error.status);
            console.log("errorResponse", error.response);
          }
          else {
            this.handleError(null, null, null);
          }
        });
      }
      else {
        console.log("Api response: ", body.response);
        this.handleError(body.response, body.response.statusCode, null);
      }
    }
    else {
      let body = {
        statusCode: "Unknown",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleError(body, body.statusCode, null);
    }
  }

  sleep(milliseconds) {
    console.log("Delay start");
    var start = new Date().getTime();
    var end = start;
    while (end < start + milliseconds) {
      end = new Date().getTime();
    }
    console.log("Delay end");
  }

  handleHbsIdSearchResponse(body) {
    // this.isPatientNotFound = false;
    // this.disableFields = false;
    if (body && body.response) {
      if (body.response.statusCode === '0000' || body.response.statusCode === '7701') {
        console.log("response", body.response);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        if (body.response.resources && body.response.resources.length > 0) {
          let list = body.response.resources[0].docRefs;
          list = list.filter(doc => doc.contentType == "text/xml");
          this.patientDocService.setDocList(list);
          this.patientDocService.setPrescriber(body.response.resources[0].prescriber);
          this.router.navigate([allPaths.internalPatientDocuments.link]);
        } else {
          this.result.display = true;
          this.result.banner = errorBanners.lookupPatient[7004];
        }
      } else if (body.response.statusCode === '7003') {
        this.searchService.storeDemographicLookupOption(''); // Disable background auto polling
        this.searchService.setShowfeedbackQuestion(false);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        this.searchService.setSourceLookupPage('Patient lookup');
        localStorage.setItem('patientLookup', 'Patient lookup');
        localStorage.removeItem("quickLookup");
        this.router.navigate([allPaths.internalPatientDocuments.link]);
      }
      else if (body.response.statusCode === '7700') {
        this.searchService.storeDemographicLookupOption(''); // Disable background auto polling
        this.searchService.setShowfeedbackQuestion(false);
        //const resource = body.response.resources[0];
        //this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        //Provide edit access to min Req fields
        if (this.searchService.isClearDisableReqFields) {
          this.disableFields = false;
          this.isPatientNotFound = false;
          this.searchService.isClearDisableReqFields = false;
        }
        //this.searchService.setSourceLookupPage('Patient lookup');
        //localStorage.setItem('patientLookup', 'Patient lookup');
        this.router.navigate([allPaths.LookupPatient.link]);
        this.result.display = true;
        this.result.banner = errorBanners.lookupPatient[7700];
      }
      else {
        this.handleError(body.response, body.response.statusCode, null);
      }
    }
    else {
      let body = {
        statusCode: "Unknown",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleError(body, body.statusCode, null);
    }
  }

}
