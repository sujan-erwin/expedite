import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { SharedModule } from '../shared/shared.module';
import { LookupPatientRoutingModule } from './lookup-patient-routing.module';
import { LookupPatientComponent } from './lookup-patient.component';

@NgModule({
  declarations: [
    LookupPatientComponent
  ],
  imports: [
    CommonModule,
    LookupPatientRoutingModule,
    NgbModule,
    SharedModule,
  ],
})
export class LookupPatientModule { }
