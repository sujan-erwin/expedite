import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTabsModule } from '@angular/material/tabs';

@NgModule({
  declarations: [],
  imports: [
    MatTabsModule,
    MatButtonModule,
    MatMenuModule,
    MatSidenavModule,
  ],
  exports: [
    MatTabsModule,
    MatButtonModule,
    MatMenuModule,
    MatSidenavModule,
  ],
})
export class MaterialDesignModule { }
