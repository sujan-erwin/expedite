import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PatientDocumentsRoutingModule } from './patient-documents-routing.module';
import { PatientDocumentsComponent } from './patient-documents.component';
import { SharedModule } from '../shared/shared.module';
import { MultiSelectAdvComponent } from './components/multi-select-adv/multi-select-adv.component';


@NgModule({
  declarations: [
    PatientDocumentsComponent,
    MultiSelectAdvComponent,
  ],
  imports: [
    CommonModule,
    PatientDocumentsRoutingModule,
    SharedModule,
  ]
})
export class PatientDocumentsModule { }
