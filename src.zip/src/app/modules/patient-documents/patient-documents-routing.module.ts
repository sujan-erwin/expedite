import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PatientDocumentsComponent } from './patient-documents.component';

const routes: Routes = [
  {
    path: '',
    component: PatientDocumentsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientDocumentsRoutingModule { }
