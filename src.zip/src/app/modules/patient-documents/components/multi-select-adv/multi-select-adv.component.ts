import { Component, Input, Output, EventEmitter, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
@Component({
  selector: "app-multiselect-adv",
  templateUrl: './multi-select-adv.component.html',
  styleUrls: ['./multi-select-adv.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => MultiSelectAdvComponent),
    multi: true
  }]
})
export class MultiSelectAdvComponent {
  @Input() name: string;
  @Input() values: string[];
  @Input() matchedOrgname: string;
  @Input() selected: boolean[];
  @Output() public applyFilter = new EventEmitter<any[]>();
  onChange;
  constructor() {
    this.selected = [];

  }
  ngOnInit() {
  }

  updateValues() {
    const selectedValues = Object.keys(this.selected).filter(value => this.selected[value]);
    console.log(this.name);
    this.applyFilter.emit([this.name, selectedValues]);
  }
  registerOnChange(fn) { this.onChange = fn; }
  registerOnTouched(fn) { }
  writeValue(val) {
    this.selected = [];
    val.forEach(item => this.selected[item] = true);

  }
}
