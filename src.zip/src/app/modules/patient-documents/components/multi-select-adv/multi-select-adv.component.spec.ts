import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MultiSelectAdvComponent } from './multi-select-adv.component';

describe('MultiSelectAdvComponent', () => {
  let component: MultiSelectAdvComponent;
  let fixture: ComponentFixture<MultiSelectAdvComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [MultiSelectAdvComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiSelectAdvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('updateValues method', () => {
    it('should emit values to parent component', () => {
      component.selected = [false, true];
      fixture.detectChanges();
      component.updateValues();
      expect(component.applyFilter).toBeDefined();
    });
  });

  describe('writeValue method', () => {
    it('should update selected values', () => {
      const val = [false, true];
      component.writeValue(val);
      expect(component.selected).toBeDefined();
    });
  });

});
