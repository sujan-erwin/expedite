import { Component, OnInit, OnDestroy, LOCALE_ID, Inject } from '@angular/core';
import { formatDate } from '@angular/common';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { SearchService } from 'src/app/services/search/search.service';
import { PatientDocumentService } from 'src/app/services/patient-document/patient-document.service';
import { SpinnerService } from 'src/app/services/spinner/spinner.service';
import { EncryptDecrypt } from 'src/app/services/crypto-js/crypto-js.encrypt.decrypt';
import { allPaths } from 'src/app/util/app-routes';
import { errorBanners } from 'src/app/util/error-messages';

@Component({
  selector: 'app-patient-documents',
  templateUrl: './patient-documents.component.html',
  styleUrls: ['./patient-documents.component.scss']
})
export class PatientDocumentsComponent implements OnInit, OnDestroy {

  patient: any;
  advanceSearchdocList: any;
  docList: any;
  result: any;
  isNotAllDocsAvailable: boolean = false;
  statusCode: any;
  filterForm: FormGroup;
  organizationFilterValues: any = [];
  typeFilterValues: any = [];
  EncounterFilterValues: any = [];
  providerFilterValues: any = [];
  filteredDocuments: any = [];
  selectedFilters: any = [];
  isSearchClicked: boolean = false;
  // docServiceSubscriber: any;

  constructor(
    private searchService: SearchService,
    private patientDocService: PatientDocumentService,
    private spinnerService: SpinnerService,
    private router: Router,
    private titleService: Title,
    private fb: FormBuilder,
    @Inject(LOCALE_ID) public locale: string,
    private encryptDecrypt: EncryptDecrypt
    ) {
    this.result = {};
    this.result.display = false;
    this.filterForm = fb.group({
      type: [[]],
      organization: [[]],
      encounterDate: [[]],
      provider: [[]]

    });
    this.titleService.setTitle("Dataviewer - Patient Documents Results");
    this.handleDocumentsResponse();
  }
  handleDocumentsResponse() {
    this.patient = this.searchService.getResourceToPatient();
    this.getDocList(this.searchService.getResource());
    this.filterForm.valueChanges.subscribe(values => {
      this.filterDocuments(values);
    });
    this.updateFilterValues();
  }

  // Filters logic
  filterDocuments(filter) {
    if (filter === '') {
      this.filteredDocuments = this.docList.filter(item => {
        return true;
      });
    } else {
      this.filteredDocuments = this.docList.filter(item => {
        var isAllowed = true;
        if (filter.type.length) {
          if (filter.type.indexOf(item.type) === -1) {
            isAllowed = false;
          }
        } else {
          isAllowed = true;
        }
        if (filter.encounterDate.length) {
          if (filter.encounterDate.indexOf(item.encounterDate) === -1) {
            isAllowed = false;
          }
        } else {
          isAllowed = true;
        }
        if (filter.provider.length) {
          if (filter.provider.indexOf(item.providerName) === -1) {
            isAllowed = false;
          }
        } else {
          isAllowed = true;
        }
        if (isAllowed) {
          if (filter.organization.length) {
            if (filter.organization.indexOf(item.orgName) === -1) {
              isAllowed = false;
            }
          } else {
            isAllowed = true;
          }
        }
        return isAllowed;
      });
    }
  }

  // Update Filter values
  updateFilterValues() {
    this.organizationFilterValues = [];
    this.typeFilterValues = [];
    this.EncounterFilterValues = [];
    this.providerFilterValues = [];
    if (!this.docList) { this.docList = [] };
    this.docList.forEach(doc => {
      //document.organization
      if (doc.orgName) {
        if (this.organizationFilterValues.indexOf(doc.orgName) === -1) {
          this.organizationFilterValues.push(doc.orgName);
        }
      } else if (!this.organizationFilterValues.includes('0--')) {
        this.organizationFilterValues.push('0--');
      }

      //document.type
      if (this.typeFilterValues.indexOf(doc.type) === -1) {
        this.typeFilterValues.push(doc.type);
      }
      //document.encounterDate
      if (doc.encounterDate) {
        let encounterDate = formatDate(doc.encounterDate, 'MM/dd/yyyy', this.locale);
        if (this.EncounterFilterValues.indexOf(encounterDate) === -1) {
          this.EncounterFilterValues.push(encounterDate);
        }
      } else if (!this.EncounterFilterValues.includes('00--')) {
        this.EncounterFilterValues.push('00--');
      }

      //document.provider
      if (this.providerFilterValues.indexOf(doc.providerName) === -1) {
        this.providerFilterValues.push(doc.providerName);
      }

    });
    this.filterDocuments(this.filterForm.value);
    this.organizationFilterValues.sort();
    this.typeFilterValues.sort();
    this.EncounterFilterValues.sort();
    this.providerFilterValues.sort();
    this.initialOrganizationValues = this.organizationFilterValues;
    this.initialTypeValues = this.typeFilterValues;
    this.initialEncounterValues = this.EncounterFilterValues;
    this.initialProviderValues = this.providerFilterValues;
  }
  filterTypes: any = {};
  initialOrganizationValues: any = [];
  initialTypeValues: any = [];
  initialEncounterValues: any = [];
  initialProviderValues: any = [];


  isFiltersSelected() {
    return (this.filterTypes.type && this.filterTypes.type.length > 0)
      || (this.filterTypes.organization && this.filterTypes.organization.length > 0)
      || (this.filterTypes.encounterDate && this.filterTypes.encounterDate.length > 0)
      || (this.filterTypes.providerName && this.filterTypes.providerName.length > 0);
  }

  clearAll() {
    this.selectedFilters = [];
    this.filteredDocuments = this.docList;
    this.organizationFilterValues = this.initialOrganizationValues;
    this.typeFilterValues = this.initialTypeValues;
    this.EncounterFilterValues = this.initialEncounterValues;
    this.providerFilterValues = this.initialProviderValues;
    this.filterTypes = {};

  }
  // Apply Filter on values
  applyFilter(attr) {
    var typeFilter = attr[0];
    var values = attr[1];
    if ("Type" == typeFilter) {
      var filteredTypes = this.initialTypeValues.filter(item => {
        if (values.indexOf(item) !== -1) {
          return true;
        }
        return false;
      });
      this.filterTypes.type = filteredTypes;
      if (!filteredTypes || filteredTypes.length === 0) {
        this.typeFilterValues = this.initialTypeValues;
      }
      else {
        this.typeFilterValues = [];
        this.typeFilterValues = filteredTypes;
      }
    }
    else if ("Organization" == typeFilter) {
      var filteredOrgs = this.initialOrganizationValues.filter(item => {
        if (values.indexOf(item) !== -1) {
          return true;
        }
        return false;
      });
      this.filterTypes.organization = filteredOrgs;
      if (!filteredOrgs || filteredOrgs.length === 0) {
        this.organizationFilterValues = this.initialOrganizationValues;
      }
      else {
        this.organizationFilterValues = [];
        this.organizationFilterValues = filteredOrgs;
      }
    }
    else if ("Encounter Date" == typeFilter) {
      var filteredEncounter = this.initialEncounterValues.filter(item => {
        if (values.indexOf(item) !== -1) {
          return true;
        }
        return false;
      });
      this.filterTypes.encounterDate = filteredEncounter;
      if (!filteredEncounter || filteredEncounter.length === 0) {
        this.EncounterFilterValues = this.initialEncounterValues;
      }
      else {
        this.EncounterFilterValues = [];
        this.EncounterFilterValues = filteredEncounter;
      }
    }
    else if ("Provider" == typeFilter) {
      var filteredProvider = this.initialProviderValues.filter(item => {
        if (values.indexOf(item) !== -1) {
          return true;
        }
        return false;
      });
      this.filterTypes.providerName = filteredProvider;
      if (!filteredProvider || filteredProvider.length === 0) {
        this.providerFilterValues = this.initialProviderValues;
      }
      else {
        this.providerFilterValues = [];
        this.providerFilterValues = filteredProvider;
      }
    }
    if ((!this.filterTypes.type || this.filterTypes.type.length === 0)) {
      this.filteredDocuments = this.docList;
      // this.organizationFilterValues = this.initialOrganizationValues;
      // this.typeFilterValues = this.initialTypeValues;
      // this.EncounterFilterValues = this.initialEncounterValues;
      // this.providerFilterValues = this.initialProviderValues;

    }
    if (!this.isSearchClicked) {
      this.filteredDocuments = this.docList;
    }
    if (this.filterTypes.type && this.filterTypes.type.length > 0) {
      this.filteredDocuments = this.filteredDocuments.filter(item => {

        if (this.filterTypes.type && this.filterTypes.type.indexOf(item.type) !== -1) {
          return true;
        }
        return false;
      });
    }
    if (this.filterTypes.organization && this.filterTypes.organization.length > 0) {
      this.filteredDocuments = this.filteredDocuments.filter(item => {
        let orgName = '0--';
        if (item.orgName) {
          orgName = item.orgName;
        }
        if (this.filterTypes.organization && this.filterTypes.organization.indexOf(orgName) !== -1) {
          return true;
        }

        return false;
      });
    }
    if (this.filterTypes.encounterDate && this.filterTypes.encounterDate.length > 0) {
      this.filteredDocuments = this.filteredDocuments.filter(item => {
        let encounterDate = '00--';
        if (item.encounterDate) {
          encounterDate = formatDate(item.encounterDate, 'MM/dd/yyyy', this.locale);
        }
        if (this.filterTypes.encounterDate.indexOf(encounterDate) !== -1) {
          return true;
        }
        return false;
      });
    }
    if (this.filterTypes.providerName && this.filterTypes.providerName.length > 0) {
      this.filteredDocuments = this.filteredDocuments.filter(item => {
        if (this.filterTypes.providerName && this.filterTypes.providerName.indexOf(item.providerName) !== -1) {
          return true;
        }
        return false;
      });
    }
  }

  isEligibleToShow() {
    return this.isFiltersSelected()
  }

  clearFilters() {
    this.selectedFilters = [];
    this.organizationFilterValues = this.initialOrganizationValues;
    this.typeFilterValues = this.initialTypeValues;
    this.EncounterFilterValues = this.initialEncounterValues;
    this.providerFilterValues = this.initialProviderValues;
    this.filterTypes = [];
  }

  sortList(list) {
    if (list) {
      let sortOrder = {
        1: ["Continuity of Care Document", "Summarization of episode note", "Ambulatory Summary", "Summary of episode note"],
        2: "Encounter Summary",
        3: "Location Summary"
      };//Keep all the order in lower case.
      let ccdList = list.filter(function (item) {
        return item.typeCode === '34133-9' && item.type &&
          (
            item.type.includes(sortOrder[1][0]) ||
            item.type.includes(sortOrder[1][1]) ||
            item.type.includes(sortOrder[1][2]) ||
            item.type.includes(sortOrder[1][3])
          );
      });
      if (ccdList) {
        ccdList = ccdList.sort(function (a, b) {

          return a.orgName > b.orgName ? 1 : a.orgName < b.orgName ? -1 : 0;
        });
      }
      let encounterSumList = list.filter(function (item) {
        return (item.typeCode === '11506-3') || (item.typeCode === '34133-9' && item.type && item.type.includes(sortOrder[2]));
      });
      encounterSumList = this.sortByEncounterDate(encounterSumList);
      let ssLSumList = list.filter(function (item) {
        return item.typeCode === '34133-9' && item.type && item.type.includes(sortOrder[3]);
      });
      var ids = ccdList.map(function (docRef) { return docRef.id; });
      encounterSumList.forEach(docRef => { ids.push(docRef.id) });
      ssLSumList.forEach(docRef => { ids.push(docRef.id); });

      let typeCodeNullList = list.filter(function (item) {
        return (item.typeCode == "") || !(ccdList.includes(item) || encounterSumList || ssLSumList.includes(item))
      });
      var nullListIds = typeCodeNullList.map(function (docRef) { return docRef.id });
      ids = [].concat(ids, nullListIds);
      let otherList = list.filter(function (item) {
        return !ids.includes(item.id);
      });
      let dateList = [].concat(typeCodeNullList, encounterSumList, otherList);
      dateList = this.sortByEncounterDate(dateList);
      ccdList = this.sortByEncounterDate(ccdList);
      ssLSumList = this.sortByEncounterDate(ssLSumList);
      list = [].concat(ccdList, dateList, ssLSumList);
    }
    return list;
  }
  sortByEncounterDate(list) {
    if (list) {
      list = list.sort(function (a, b) {
        let aDate = a.encounterDate;
        let bDate = b.encounterDate;
        aDate = !aDate || aDate == '' ? '01/01/1888' : aDate;
        bDate = !bDate || bDate == '' ? '01/01/1888' : bDate;
        return <any>new Date(bDate) - <any>new Date(aDate);
      });
    }
    return list;
  }

  getDocList(resource) {
    if (resource) {
      let list = resource.docRefs;
      if (list && list.length > 0) {
        list = list.filter(function(doc: { contentType: string; }) {
          return (doc.contentType == "text/xml" || doc.contentType == "application/pdf")
        });
        this.isNotAllDocsAvailable = resource.isNotAllDocsAvailable;
        this.statusCode = resource.statusCode
        this.patientDocService.setExternalDocList(list);
        this.docList = this.sortList(this.patientDocService.getExternalDocList());
        this.filteredDocuments = this.docList;
        this.result.display = false;
      } else {
        this.result.display = true;
        this.result.banner = errorBanners.externalPatientSearch[7003];
      }
    } else {
      let response = {
        statusCode: "default",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleError(response);
    }

  }

  // handleResponse(body) {
  //   let list1;
  //   if (body && body.response) {
  //     if (body.response.statusCode === '0000') {
  //       this.spinnerService.hide();
  //       if (body.response.resources && body.response.resources.length > 0) {
  //         let list = body.response.resources[0].docRefs;
  //         list = list.filter(doc => doc.contentType == "text/xml");
  //         list1 = this.sortList(list);
  //         this.patientDocService.setExternalDocList(list1);
  //         this.docList = this.patientDocService.getExternalDocList();
  //       } else {
  //         this.result.display = true;
  //         this.result.banner = errorBanners.externalPatientSearch[7003];
  //       }

  //     } else {
  //       this.handleError(body.response);
  //     }
  //   } else {
  //     let body = {
  //       statusCode: "Unknown",
  //       statusDesc: "Unknown error occured while calling backend service."
  //     }
  //     this.handleError(body);
  //   }
  // }

  handleError(response) {
    this.spinnerService.hide();
    this.result.display = true;
    this.result.banner = errorBanners.externalPatientSearch[response.statusCode];
    if (!this.result.banner) {
      this.result.banner = errorBanners.externalPatientSearch['default'];
    }
    var info = this.result.banner.info;
    info = info == '{errorDesc}' ? response.statusDesc : info;
    this.result.banner.info = info;
  }

  openDocument(digitalId) {
    let document = this.docList.find(item => item.digitalId == digitalId);
    let sDoc = Object.assign({}, document);
    document.viewStatus = "loading";
    let resource = Object.assign({}, this.searchService.getResource());
    resource.docRefs = [sDoc];
    let patient = {
      patient: resource
    }

    this.patientDocService.getDocument(patient).subscribe((data: any) => {
      if (data && data.response.statusCode === '0000') {
        document.viewStatus = "viewed";
        if (document.contentType == "text/xml") {
          var htmlContent = window.atob(data.response.resources[0].content);
          const newWindow = window.open(document.id + '.html');
          newWindow.document.title = document.title;
          newWindow.document.write(htmlContent);
        } else if (document.contentType == "application/pdf") {
          var pdfContent = data.response.resources[0].content;
          let blob = this.base64ToBlob(pdfContent, 'application/pdf');
          const blobURL = URL.createObjectURL(blob);
          const theWindow = window.open("");
          theWindow.document.write("<iframe width='100%' height='100%' src='" + blobURL + "'></iframe>");
        }
      } else {
        this.handleRetry(document);

      }

    }, error => {
      this.handleRetry(document);
    });
  }

  //converts base64 to blob type
  base64ToBlob(base64: string, contentType: string) {
    const binStr = window.atob(base64);
    const len = binStr.length;
    const arr = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      arr[ i ] = binStr.charCodeAt( i );
    }
    return new Blob( [ arr ], { type: contentType } );
  }

  handleRetry(document) {
    document.viewStatus = "retry";
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 3) {
      document.viewStatus = "error";
    }
  }

  editSearch() {
    this.router.navigate([this.getPreviousPage()]);
  }
  startSearch() {
    this.searchService.setPatient(null);
    this.searchService.setResource(null);
    this.searchService.setSourcePage("externalSearch");
    this.patientDocService.setExternalDocList(null);
    this.router.navigate([this.getPreviousPage()]);
  }

  ngOnInit() {
  }

  getPreviousPage() {
    let page = allPaths.quickLookUp.link;
    let ob = sessionStorage.getItem("breadcrumbList");
    let breadcrumbList = (ob && ob != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(ob)) : null;
    if (breadcrumbList.length > 1) {
      return this.getPreviousPath(breadcrumbList[breadcrumbList.length - 2]);
    }
    return page;
  }
  getPreviousPath(breadcrumbName) {
    for (const [key, value] of Object.entries(allPaths)) {
      if (value.label === breadcrumbName.label) {
        return value.link;
      }
    }
  }

  ngOnDestroy() {
    this.patientDocService.setExternalDocList(null);
    this.spinnerService.hide();
  }
}
