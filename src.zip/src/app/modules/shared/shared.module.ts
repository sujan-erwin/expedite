import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialDesignModule } from '../material-design/material-design.module';
import { SessionModule } from '../session/session.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateFormatPipePipe } from './pipes/date-format-pipe/date-format-pipe.pipe';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { SortDirective } from './directives/sort/sort.directive';
import { BreadCrumbComponent } from './components/bread-crumb/bread-crumb.component';



@NgModule({
  declarations: [
    BreadCrumbComponent,
    DateFormatPipePipe,
    SpinnerComponent,
    SortDirective,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialDesignModule,
    SessionModule,
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    MaterialDesignModule,
    SessionModule,
    BreadCrumbComponent,
    DateFormatPipePipe,
    SpinnerComponent,
    SortDirective
  ]
})
export class SharedModule { }
