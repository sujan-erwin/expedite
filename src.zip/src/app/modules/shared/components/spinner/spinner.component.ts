import { Component, Input, OnInit } from '@angular/core';

import { SpinnerService } from 'src/app/services/spinner/spinner.service';

@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit {
  @Input() loading: boolean = false;
  @Input() loadingViewAllMedications: boolean = false;
  @Input() loadingProgressNotes: boolean = false;
  @Input() loadingViewAllPN: boolean = false;
  @Input() loadingVitals: boolean = false;
  @Input() loadingViewAllVitals: boolean = false;
  @Input() loadingConditions: boolean = false;
  @Input() loadingViewAllConditions: boolean = false;
  @Input() loadingAllergies: boolean = false;
  @Input() loadingViewAllAllergies: boolean = false;
  overlayShow: boolean = false;
  // show: boolean =false;
  constructor(private spinnerService: SpinnerService) { }

  ngOnInit() {
    this.spinnerService.getEmitter().subscribe(data => {
      console.log('SPINNER SHOW: ' + data);
      this.overlayShow = data;
    });
  }

}
