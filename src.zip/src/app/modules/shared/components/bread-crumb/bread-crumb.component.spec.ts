import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { DatePipe, Location } from '@angular/common';
import { BreadCrumbComponent } from './bread-crumb.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SearchService } from 'src/app/services/search/search.service';

describe('BreadCrumbComponent', () => {
  let component: BreadCrumbComponent;
  let fixture: ComponentFixture<BreadCrumbComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ BreadCrumbComponent ],
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [
        { provide: Location, useValue: location },
        SearchService,
        DatePipe
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadCrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
