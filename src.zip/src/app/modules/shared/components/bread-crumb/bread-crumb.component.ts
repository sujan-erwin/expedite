import { Component, OnInit } from '@angular/core';
import { Router, ActivationEnd } from '@angular/router';
import { Location } from '@angular/common';

import { BreadCrumb } from '../../../../model/bread-crumb';
import { allPaths } from '../../../../util/app-routes';
import { EncryptDecrypt } from '../../../../services/crypto-js/crypto-js.encrypt.decrypt';
import { SearchService } from 'src/app/services/search/search.service';
import { tabPaths } from 'src/app/util/tab-routes';

@Component({
  selector: 'bread-crumb',
  templateUrl: './bread-crumb.component.html',
  styleUrls: ['./bread-crumb.component.scss']
})
export class BreadCrumbComponent implements OnInit {

  route: string;
  breadcrumbList: Array<BreadCrumb>;
  routeLinks: number;

  constructor(
    location: Location,
    private router: Router,
    private searchService: SearchService,
    private encryptDecrypt: EncryptDecrypt
  ) {
    router.events.subscribe((val) => {

      if (location.path() !== '' && val instanceof ActivationEnd) {
        let ob = sessionStorage.getItem("breadcrumbList");
        this.breadcrumbList = (ob && ob != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(ob)) : null;
        this.route = location.path();
        let path = this.route.split('/');
        let bc: BreadCrumb = new BreadCrumb();
        bc.link = path[1];
        let myValue = tabPaths.patientSearch.find(item => item.link.indexOf(bc.link) > 0);
        if (!myValue) {
          myValue = tabPaths.pastSearches.find(item => item.link.indexOf(bc.link) > 0);
        }
        if (myValue) {
          bc.label = myValue.label;
          bc.isLink = false;
          if (!this.breadcrumbList || bc.label === allPaths.quickLookUp.label || bc.label === allPaths.pastSearches.label) {
            this.breadcrumbList = [];
          }
          let index = this.breadcrumbList.findIndex(item => item.link === bc.link);

          this.breadcrumbList.forEach(function (item) {
            if (item.link !== bc.link) { item.isLink = true }
            else { item.isLink = false }
          });
          if (index > -1) {
            this.breadcrumbList = this.breadcrumbList.slice(0, index);
          }
          if (bc.link === 'lookup-patient') {
            this.searchService.enableDemoFields();
          }
          if (bc.link === "Patient-documents") {
            this.searchService.setResultBannerStatus(true);
          }
          this.breadcrumbList.push(bc);
          sessionStorage.setItem("breadcrumbList", this.encryptDecrypt.aesEncrypt(JSON.stringify(this.breadcrumbList)));
          if (bc.label === allPaths.pastSearches.label) { //remove this code when we need BC on Past search page.
            this.breadcrumbList = [];
            sessionStorage.setItem("breadcrumbList", this.encryptDecrypt.aesEncrypt(JSON.stringify(this.breadcrumbList)));
          }
        }
      }
    });
  }

  goTo(link: string) {
    this.router.navigate([link]);
  }

  ngOnInit() { }
}
