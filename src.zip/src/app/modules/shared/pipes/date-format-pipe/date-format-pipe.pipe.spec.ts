import { DateFormatPipePipe } from './date-format-pipe.pipe';

describe('DateFormatPipePipe', () => {
  it('create an instance', () => {
    const pipe = new DateFormatPipePipe();
    expect(pipe).toBeTruthy();
  });
});
