import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'dateFormatPipe'
})
export class DateFormatPipePipe implements PipeTransform {

  transform(value: string): string {
    let datePipe = new DatePipe("en-US");
    const reqDate:Array<any>  = value.split('T');
    value = reqDate[0];
    const split:Array<any> = value.split('-');
    if(split.length === 1) {
      value = datePipe.transform(value, 'yyyy');
    } else if(split.length === 2) {
      value = datePipe.transform(value, 'MM/yyyy');
    } else {
      value = datePipe.transform(value, 'MM/dd/yyyy');
    }
    return value;
  } 

}
