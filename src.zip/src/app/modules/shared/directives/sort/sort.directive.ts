import {
  Directive,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnInit,
  Output,
  Renderer2,
} from '@angular/core';
import { sortUtil } from 'src/app/util/sort-util';

@Directive({
  selector: '[appSort]',
})
export class SortDirective implements OnInit {
  @Input('appSort') data: Array<any>;
  @Output() sortEvnt: EventEmitter<any> = new EventEmitter();

  constructor(private elementRef: ElementRef, private renderer: Renderer2) { }

  ngOnInit(): void { }

  @HostListener('click')
  executeSorting() {
    // console.log("elementRef", this.elementRef);
    let property = this.elementRef.nativeElement.getAttribute('data-name');
    let sortOrder = this.elementRef.nativeElement.getAttribute('data-order');
    let dataType = this.elementRef.nativeElement.getAttribute('data-type');
    let elementId = this.elementRef.nativeElement.getAttribute('id');
    let columnName = this.elementRef.nativeElement.getAttribute('data-column');
    const util = new sortUtil();
    this.sortEvnt.emit({
      id: elementId,
      column: property,
      order: sortOrder,
      type: dataType,
      name: columnName,
    });
    if (sortOrder === 'Asc') {
      this.data?.sort(util.compareFuntn(sortOrder, property, dataType));
      this.renderer.setAttribute(
        this.elementRef.nativeElement,
        'data-order',
        'Desc'
      );
    }
    if (sortOrder === 'Desc') {
      this.data?.sort(util.compareFuntn(sortOrder, property, dataType));
      this.renderer.setAttribute(
        this.elementRef.nativeElement,
        'data-order',
        'Asc'
      );
    }
  }
}
