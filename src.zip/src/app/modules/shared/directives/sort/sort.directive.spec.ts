import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { SortDirective } from './sort.directive';

@Component({
  template:
    '<table class="table"><thead><tr><th id="medication-name" ' +
    'scope="col" class="header-cell" ' +
    '[appSort]="completeMedicationsToRender" ' +
    'data-name="" ' +
    'data-order="" data-type="" ' +
    '[attr.data-column]="medHdrs.medName.title"' +
    '>Medications' +
    '</th>' +
    '<th id="start-date" ' +
    'scope="col" class="header-cell" ' +
    '[appSort]="completeMedicationsToRender" ' +
    'data-name="" ' +
    'data-order="" data-type="" ' +
    '[attr.data-column]="medHdrs.medStartDate.title" ' +
    '>medStartDate' +
    '</th>' +
    '</tr></thead>' +
    '<tbody>' +
    '<tr *ngFor="let medication of completeMedicationsToRender">' +
    '<td>{{medication.medicationName}}</td>' +
    '<td>{{medication?.medicationStartDate}}</td>' +
    '</tr>' +
    '</tbody></table>',
})
class TestComponent {
  public column_data_name: string;
  public medHdrs: any = {
    medName: { id: 'medication-name', title: 'Medications' },
    medStartDate: { id: 'start-date', title: 'Start Date' },
    medEndDate: { id: 'end-date', title: 'End Date' },
    prescriber: { id: 'prescriber-name', title: 'Prescriber' },
    instructions: { id: 'instructions', title: 'Instructions' },
    status: { id: 'status', title: 'Status' }
  };
  public completeMedicationsToRender: any = [{
    "response": {
      "resources": [
        {
          "medicationStartDate": "1999-01-08",
          "medicationEndDate": null,
          "medicationName": "cetirizine (ZyrTEC) 10 mg tablet",
          "instruction": "Take 10 mg by mouth daily as needed for allergies.",
          "indications": null,
          "prescriber": {
            "firstName": "Historical",
            "lastName": "Provider"
          },
          "qty": null,
          "documentRef": "d7148c66f21c49002e7d37caa3013aed",
          "status": "Active"
        },
        {
          "medicationStartDate": "2022-10-26",
          "medicationEndDate": "1999-01-08",
          "medicationName": "albuterol HFA (PROVENTIL HFA;VENTOLIN HFA) 90 mcg/actuation inhaler 4 puff",
          "instruction": null,
          "indications": null,
          "prescriber": {
            "firstName": "Gautam",
            "lastName": "George"
          },
          "qty": null,
          "documentRef": "d7148c66f21c49002e7d37caa3013aed",
          "status": "Completed"
        },
      ],
      "resource": null,
      "statusDesc": "Success",
      "statusCode": "0000",
      "requestedBy": "Sahil"
    }
  }]
}

describe('SortDirective', () => {
  let fixture: ComponentFixture<TestComponent>;
  let component: TestComponent;
  let sortableElements: DebugElement[];

  beforeEach(() => {
    fixture = TestBed.configureTestingModule({
      declarations: [SortDirective, TestComponent],
    }).createComponent(TestComponent);
    fixture.detectChanges();
    component = fixture.componentInstance;
    sortableElements = fixture.debugElement.queryAll(
      By.directive(SortDirective)
    );
  });
  it('should create an instance', () => {
    expect(component).toBeTruthy();
  });

  it('should sort by descending', () => {
    sortableElements[0].nativeElement.setAttribute(
      'data-name',
      'medication.medicationName'
    );
    sortableElements[0].nativeElement.setAttribute('data-order', 'Desc');
    sortableElements[0].triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.completeMedicationsToRender[0].response.resources[0].medicationName).toEqual('cetirizine (ZyrTEC) 10 mg tablet');

    sortableElements[0].nativeElement.setAttribute(
      'data-name',
      'medication.medicationStartDate'
    );
    sortableElements[1].nativeElement.setAttribute('data-order', 'Desc');
    sortableElements[1].triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.completeMedicationsToRender[0].response.resources[0].medicationStartDate).toEqual('1999-01-08');
  });

  it('should sort by ascending', () => {
    sortableElements[0].nativeElement.setAttribute(
      'data-name',
      'medication.medicationName'
    );
    sortableElements[0].nativeElement.setAttribute('data-order', 'Asc');
    sortableElements[0].triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.completeMedicationsToRender[0].response.resources[1].medicationName).toEqual('albuterol HFA (PROVENTIL HFA;VENTOLIN HFA) 90 mcg/actuation inhaler 4 puff');

    sortableElements[0].nativeElement.setAttribute(
      'data-name',
      'medication.medicationStartDate'
    );
    sortableElements[1].nativeElement.setAttribute('data-order', 'Asc');
    sortableElements[1].triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.completeMedicationsToRender[0].response.resources[1].medicationStartDate).toEqual('2022-10-26');
  });
});
