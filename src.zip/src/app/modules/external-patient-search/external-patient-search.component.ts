import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Title } from "@angular/platform-browser";

import { SpinnerService } from 'src/app/services/spinner/spinner.service';
import { allPaths } from 'src/app/util/app-routes';
import { AuthService } from 'src/app/services/auth/auth.service';
import { SearchService } from 'src/app/services/search/search.service';
import { PatientDocumentService } from 'src/app/services/patient-document/patient-document.service';
import { DateValidator } from 'src/app/util/date-validator';
import { errorBanners } from 'src/app/util/error-messages';



@Component({
  selector: 'app-external-patient-search',
  templateUrl: './external-patient-search.component.html',
  styleUrls: ['./external-patient-search.component.scss']
})
export class ExternalPatientSearchComponent implements OnInit {
  // FormGroup
  externalsearchForm: FormGroup;
  stateList: JSON;
  router: Router;
  result: any;
  patientServiceSubscriber: any;


  constructor(
    fb: FormBuilder,
    private authService: AuthService,
    private searchService: SearchService,
    private spinnerService: SpinnerService,
    private patientDocService: PatientDocumentService,
    router: Router,
    private activatedRoute: ActivatedRoute,
    private datePipe: DatePipe,
    private titleService: Title
  ) {
    this.stateList = this.getStateList();
    this.router = router;
    this.result = {};
    this.result.display = false;
    this.titleService.setTitle("Dataviewer - Advanced search");
    let patient = null;
    let sourcePage = searchService.getSourcePage();
    console.log("sourcePage", sourcePage);
    if (sourcePage === 'externalSearch' || sourcePage === 'lookupPatientPage') {
      patient = searchService.getPatient();
      if (sourcePage === 'lookupPatientPage') {
        patient.HBSID = this.datePipe.transform(patient.dob, 'MMddyyyy') + patient.zipCode;
      }
    }
    else {
      patient = searchService.getInternalResourceToPatient();
    }
    if (!patient) {
      patient = {};
    }
    if (patient.dob) {
      patient.dob = this.datePipe.transform(patient.dob, 'MM/dd/yyyy');
    }
    if (patient.gender === 'M') {
      patient.gender = 'Male';
    } else if (patient.gender === 'F') {
      patient.gender = 'Female';
    }

    // const patient = searchService.getPatient();
    this.externalsearchForm = fb.group({
      // FormGroup fields
      HBSID: [patient.HBSID, [Validators.required]],
      firstName: [patient.firstName, [Validators.required]],
      lastName: [patient.lastName, [Validators.required]],
      middleName: [patient.middleName],
      suffix: [patient.suffix],
      dob: [patient.dob, [Validators.required, DateValidator]],
      gender: [patient.gender, [Validators.required]],
      addressline1: [patient.addressline1, [Validators.required]],
      addressline2: [patient.addressline2],
      city: [patient.city, [Validators.required]],
      state: [patient.state, [Validators.required]],
      zipCode: [patient.zipCode, [Validators.required, Validators.pattern('[0-9]{5}')]],
      phone: [patient.phone],
      npi: [patient.npi]
    })
  }

  ngOnInit() {

  }

  formatPatient(patient) {
    if (!patient || !patient.firstName) {
      patient = {
        firstName: "",
        lastName: "",
        middleName: "",
        suffix: "",
        dob: "",
        gender: "",
        addressline1: "",
        addressline2: "",
        city: "",
        state: "",
        zipCode: "",
        phone: "",
        npi: ""
      };
    }
    return patient;
  }

  startSearch() {
    this.router.navigate([allPaths.quickLookUp.link]);
  }
  onSubmit() {
    this.result.display = false;
    if (this.externalsearchForm.valid) {
      console.log("ExternalSearchForm", this.externalsearchForm);
      this.searchService.setPatient(this.externalsearchForm.value);
      this.searchService.setSourcePage('externalSearch');
      this.patientServiceSubscriber = this.searchService.advancedPatientSearch(this.externalsearchForm.value).subscribe(data =>
        this.handleSearchResponse(data), error => this.handleSearchResponse(error));

    } else {
      this.validateAllFormFields(this.externalsearchForm);

    }
  }

  handleSearchResponse(body) {
    if (body && body.response) {
      let statusCodes = ['0000', '7200', '7201', '7203', '7204', '7300', '7301', '7302', '7400', '7401', '7402', '7410'];
      let partialDocAvailableCodes = ['7300', '7301', '7302', '7400', '7401', '7402', '7410'];
      if (statusCodes.includes(body.response.statusCode)) {
        const resource = body.response.resources[0];
        resource.isNotAllDocsAvailable = partialDocAvailableCodes.includes(body.response.statusCode);
        resource.statusCode = body.response.statusCode;
        this.searchService.setResource(resource);
        this.spinnerService.hide();
        if (resource) {
          this.router.navigate([allPaths.patientDocuments.link]);
        }
      } else if (body.response.statusCode === '7003' || body.response.statusCode === '7205' || body.response.statusCode === '7206') {
        this.result.display = true;
        const resource = body.response.resources[0];
        this.searchService.setResource(resource);
        this.spinnerService.hide();
        this.router.navigate([allPaths.patientDocuments.link]);
      }
      else {
        this.handleError(body.response);
      }
    } else {
      let body = {
        statusCode: "Unknown",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleError(body);
    }
  }

  handleError(response) {
    this.spinnerService.hide();
    this.result.display = true;
    this.result.banner = errorBanners.externalPatientSearch[response.statusCode];
    if (!this.result.banner) {
      this.result.banner = errorBanners.externalPatientSearch['default'];
      this.result.tryAgain = true;
      var info = this.result.banner.info;
      info = info == '{errorDesc}' ? response.statusCode + " - " + response.statusDesc : info;
      this.result.banner.info = info;
    }
    else {
      this.result.tryAgain = false;
    }
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        if (!control.valid && !control.value) {
          control.markAsTouched();
        }

      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  maskDate(event) {

    if (event.inputType !== 'deleteContentBackward') {

      // remove all mask characters (keep only numeric)
      var newVal = event.target.value.replace(/[^0-9/]/g, '');
      // don't show braces for empty value
      if (newVal.length == 0) {
        newVal = '';
      } else {
        let dList = newVal.split("/");
        let count = (dList || []).length;
        //if the input already contains two / then format it.
        if (count >= 3) {
          newVal = this.formatDate(newVal);
        } else {
          if (newVal.length == 2) { //only with two chars decides whether to append zero or not.
            if (newVal.indexOf('/') == 1) {
              newVal = '0' + newVal;
            } else if (newVal.indexOf('/') < 0) { //if both chars are digits then append with / at end
              newVal = newVal.replace(/^(\d{0,2})/, '$1/');
            }
          } else if (newVal.length == 3) { //if user edit after entering 3 chars, we need append / accordingly.
            if (newVal.indexOf('/') != 2) {
              newVal = newVal.replace(/[^0-9]/g, ''); //clear all / and format it as below.
              newVal = newVal.replace(/^(\d{2})(\d{0,2})/, '$1/$2');
            }
          }
          else if (newVal.length == 5) { //when 5 chars, decide whether append dd with zero or not.
            if (newVal.substring(3, 5).indexOf('/') == 1) {
              newVal = newVal.substring(0, 3) + '0' + newVal.substring(3, 5);
            } else if (newVal.substring(3, 5).indexOf('/') < 0) { //if dd slash is not entered, then add it at end.
              newVal = newVal.replace(/[^0-9]/g, '');
              newVal = newVal.replace(/^(\d{0,2})(\d{0,2})/, '$1/$2/');
            }
          } else if (newVal.length >= 6) { //if length is more than 6 chars eligible for MM/DD/YYYY or it could be pasted content.
            newVal = this.formatDate(newVal);
          }
        }

      }
      // set the new value
      this.dob.setValue(newVal);
    }
  }

  formatDate(date) {
    let dList = date.split("/");
    let count = (dList || []).length;
    if (count >= 3 && (dList[0].length == 1 || dList[1].length == 1)) {
      if (dList[0].length == 1) {
        dList[0] = "0" + dList[0];
      }
      if (dList[1].length == 1) {
        dList[1] = "0" + dList[1];
      }
      date = dList[0] + "/" + dList[1] + "/" + dList[2];
    }
    return date;
  }

  clearSearch() {
    this.searchService.setPatient(null);
    this.searchService.setResource(null);
    this.patientDocService.setExternalDocList(null);
    this.externalsearchForm.reset();
    this.state.setValue("");
    this.result.display = false;
  }

  restrictValue(control, type) {
    var newVal = control.value;
    if (type == 'numeric') {
      newVal = newVal.replace(/[^0-9]/g, '');
    } else {
      newVal = newVal.replace(/[^a-z0-9]/gi, '');
    }
    control.setValue(newVal);
  }

  getAddress(event) {
    if (!event.place) {
      let address = event.address ? event.address : '';
      this.externalsearchForm.controls['addressline1'].setValue(address);
      return;
    }
    let postalField: HTMLInputElement = document.querySelector("#zipCode") as HTMLInputElement;
    let cityField: HTMLInputElement = document.querySelector("#city") as HTMLInputElement;
    let stateField: HTMLInputElement = document.querySelector("#state") as HTMLInputElement;
    let options = {
      types: ['address'],
      componentRestrictions: {
        'country': ['us']
      },
      fields: ["address_components", "geometry"]
    }
    let address1 = "";
    for (const component of event.place.address_components as google.maps.GeocoderAddressComponent[]) {
      const componentType = component.types[0];
      switch (componentType) {
        case "street_number":
          address1 = `${component.long_name} ${address1}`;
          break;
        case "route":
          address1 += component.long_name;
          break;
        case "postal_code":
          postalField.value = component.long_name;
          break;
        case "locality":
          cityField.value = component.long_name;
          break;
        case "administrative_area_level_3":
          if (!cityField.value)
            cityField.value = component.long_name;
          break;
        case "sublocality_level_1":
          if (!cityField.value)
            cityField.value = component.long_name;
          break;
        case "administrative_area_level_1":
          stateField.value = component.short_name;
          break;
      }
    }
    this.externalsearchForm.controls['addressline1'].setValue(address1);
    this.externalsearchForm.controls['city'].setValue(cityField.value);
    this.externalsearchForm.controls['state'].setValue(stateField.value);
    this.externalsearchForm.controls['zipCode'].setValue(postalField.value);
  }

  get HBSID() { return this.externalsearchForm.get('HBSID'); }
  get firstName() { return this.externalsearchForm.get('firstName'); }
  get lastName() { return this.externalsearchForm.get('lastName'); }
  get middleName() { return this.externalsearchForm.get('middleName'); }
  get suffix() { return this.externalsearchForm.get('suffix'); }
  get dob() { return this.externalsearchForm.get('dob'); }
  get gender() { return this.externalsearchForm.get('gender'); }
  get addressline1() { return this.externalsearchForm.get('addressline1'); }
  get addressline2() { return this.externalsearchForm.get('addressline2'); }
  get city() { return this.externalsearchForm.get('city'); }
  get state() { return this.externalsearchForm.get('state'); }
  get zipCode() { return this.externalsearchForm.get('zipCode'); }
  get phone() { return this.externalsearchForm.get('phone'); }
  get npi() { return this.externalsearchForm.get('npi'); }

  // List of states
  private getStateList() {
    var stateList: any = [
      {
        "name": "Alabama",
        "abbreviation": "AL"
      },
      {
        "name": "Alaska",
        "abbreviation": "AK"
      },
      {
        "name": "American Samoa",
        "abbreviation": "AS"
      },
      {
        "name": "Arizona",
        "abbreviation": "AZ"
      },
      {
        "name": "Arkansas",
        "abbreviation": "AR"
      },
      {
        "name": "California",
        "abbreviation": "CA"
      },
      {
        "name": "Colorado",
        "abbreviation": "CO"
      },
      {
        "name": "Connecticut",
        "abbreviation": "CT"
      },
      {
        "name": "Delaware",
        "abbreviation": "DE"
      },
      {
        "name": "District Of Columbia",
        "abbreviation": "DC"
      },
      {
        "name": "Federated States Of Micronesia",
        "abbreviation": "FM"
      },
      {
        "name": "Florida",
        "abbreviation": "FL"
      },
      {
        "name": "Georgia",
        "abbreviation": "GA"
      },
      {
        "name": "Guam",
        "abbreviation": "GU"
      },
      {
        "name": "Hawaii",
        "abbreviation": "HI"
      },
      {
        "name": "Idaho",
        "abbreviation": "ID"
      },
      {
        "name": "Illinois",
        "abbreviation": "IL"
      },
      {
        "name": "Indiana",
        "abbreviation": "IN"
      },
      {
        "name": "Iowa",
        "abbreviation": "IA"
      },
      {
        "name": "Kansas",
        "abbreviation": "KS"
      },
      {
        "name": "Kentucky",
        "abbreviation": "KY"
      },
      {
        "name": "Louisiana",
        "abbreviation": "LA"
      },
      {
        "name": "Maine",
        "abbreviation": "ME"
      },
      {
        "name": "Marshall Islands",
        "abbreviation": "MH"
      },
      {
        "name": "Maryland",
        "abbreviation": "MD"
      },
      {
        "name": "Massachusetts",
        "abbreviation": "MA"
      },
      {
        "name": "Michigan",
        "abbreviation": "MI"
      },
      {
        "name": "Minnesota",
        "abbreviation": "MN"
      },
      {
        "name": "Mississippi",
        "abbreviation": "MS"
      },
      {
        "name": "Missouri",
        "abbreviation": "MO"
      },
      {
        "name": "Montana",
        "abbreviation": "MT"
      },
      {
        "name": "Nebraska",
        "abbreviation": "NE"
      },
      {
        "name": "Nevada",
        "abbreviation": "NV"
      },
      {
        "name": "New Hampshire",
        "abbreviation": "NH"
      },
      {
        "name": "New Jersey",
        "abbreviation": "NJ"
      },
      {
        "name": "New Mexico",
        "abbreviation": "NM"
      },
      {
        "name": "New York",
        "abbreviation": "NY"
      },
      {
        "name": "North Carolina",
        "abbreviation": "NC"
      },
      {
        "name": "North Dakota",
        "abbreviation": "ND"
      },
      {
        "name": "Northern Mariana Islands",
        "abbreviation": "MP"
      },
      {
        "name": "Ohio",
        "abbreviation": "OH"
      },
      {
        "name": "Oklahoma",
        "abbreviation": "OK"
      },
      {
        "name": "Oregon",
        "abbreviation": "OR"
      },
      {
        "name": "Palau",
        "abbreviation": "PW"
      },
      {
        "name": "Pennsylvania",
        "abbreviation": "PA"
      },
      {
        "name": "Puerto Rico",
        "abbreviation": "PR"
      },
      {
        "name": "Rhode Island",
        "abbreviation": "RI"
      },
      {
        "name": "South Carolina",
        "abbreviation": "SC"
      },
      {
        "name": "South Dakota",
        "abbreviation": "SD"
      },
      {
        "name": "Tennessee",
        "abbreviation": "TN"
      },
      {
        "name": "Texas",
        "abbreviation": "TX"
      },
      {
        "name": "Utah",
        "abbreviation": "UT"
      },
      {
        "name": "Vermont",
        "abbreviation": "VT"
      },
      {
        "name": "Virgin Islands",
        "abbreviation": "VI"
      },
      {
        "name": "Virginia",
        "abbreviation": "VA"
      },
      {
        "name": "Washington",
        "abbreviation": "WA"
      },
      {
        "name": "West Virginia",
        "abbreviation": "WV"
      },
      {
        "name": "Wisconsin",
        "abbreviation": "WI"
      },
      {
        "name": "Wyoming",
        "abbreviation": "WY"
      }
    ]

    return <JSON>stateList;
  }
  ngOnDestroy() {
    this.spinnerService.hide();
    if (this.patientServiceSubscriber) {
      this.patientServiceSubscriber.unsubscribe();
    }
  }
}

