import { Component, ViewChild, EventEmitter, Output, OnInit, AfterViewInit, Input, OnChanges } from '@angular/core';

@Component({
    selector: 'app-auto-address',
    template: `
      <input id="addresstext"  name="addresstextName"
        type="text" required
        [(ngModel)]="addresstext"
        [ngClass] = "{'error': showError,'valid': !showError}"
        (blur) = "triggerAutoInputChange()"
        #addresstextElm #addresstextName="ngModel" style="width: 42rem;">
    `,
    styles: ['.error{border: 2px solid #DB3321; background-color: #FAE6E6;}', '.valid{border: 2px solid #262626;}']
})


export class AutoAddressComponent implements OnInit, AfterViewInit, OnChanges {
    @Input() addressType: string;
    @Input() addressline1: string;
    @Output() setAddress: EventEmitter<any> = new EventEmitter();
    @ViewChild('addresstextElm') addresstextElm: any;
    @Input() showError: boolean;
    addresstext: string;
    queryWait: boolean;

    constructor() {
    }

    triggerAutoInputChange() {
        this.invokeEvent(null, this.addresstext);
    }

    ngOnChanges() {
        this.addresstext = this.addressline1;
    }

    ngOnInit() {
    }

    ngAfterViewInit() {
        if (this.addressline1) {
            this.addresstext = this.addressline1;
        }
        this.getPlaceAutocomplete();
    }

    private getPlaceAutocomplete() {
        const autocomplete = new google.maps.places.Autocomplete(this.addresstextElm.nativeElement,
            {
                componentRestrictions: { country: 'US' },
                types: [this.addressType]  // 'establishment' / 'address' / 'geocode'
            });
        google.maps.event.addListener(autocomplete, 'place_changed', () => {
            console.log("listener + ", this.addresstext);
            const place = autocomplete.getPlace();
            this.invokeEvent(place, null);
        });
    }
    invokeEvent(place: Object, address: string) {
        let result = { "address": address, "place": place }
        this.setAddress.emit(result);
    }

}
