import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExternalPatientSearchRoutingModule } from './external-patient-search-routing.module';
import { SharedModule } from '../shared/shared.module';
import { ExternalPatientSearchComponent } from './external-patient-search.component'
import { AutoAddressComponent } from './compoents/auto-address/auto-address.component';


@NgModule({
  declarations: [
    ExternalPatientSearchComponent,
    AutoAddressComponent,
  ],
  imports: [
    CommonModule,
    ExternalPatientSearchRoutingModule,
    SharedModule,
  ]
})
export class ExternalPatientSearchModule { }
