import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ExternalPatientSearchComponent } from './external-patient-search.component';

const routes: Routes = [
  {
    path: '',
    component: ExternalPatientSearchComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExternalPatientSearchRoutingModule { }
