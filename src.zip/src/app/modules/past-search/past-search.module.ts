import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PastSearchRoutingModule } from './past-search-routing.module';
import { PastSearchComponent } from './past-search.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    PastSearchComponent
  ],
  imports: [
    CommonModule,
    PastSearchRoutingModule,
    SharedModule,
  ]
})
export class PastSearchModule { }
