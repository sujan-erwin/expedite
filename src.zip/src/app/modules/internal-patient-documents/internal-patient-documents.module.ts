import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InternalPatientDocumentsRoutingModule } from './internal-patient-documents-routing.module';
import { InternalPatientDocumentsComponent } from './internal-patient-documents.component';
import { MultiselectComponent } from './components/multiselect/multiselect.component';
import { SharedModule } from '../shared/shared.module';
import { AllergiesComponent } from './components/allergies/allergies.component';
import { ConditionsComponent } from './components/conditions/conditions.component';
import { LabsComponent } from './components/labs/labs.component';
import { MedicationsComponent } from './components/medications/medications.component';
import { ProgressNotesComponent } from './components/progress-notes/progress-notes.component';
import { VitalsComponent } from './components/vitals/vitals.component';


@NgModule({
  declarations: [
    InternalPatientDocumentsComponent,
    MultiselectComponent,
    AllergiesComponent,
    ConditionsComponent,
    LabsComponent,
    MedicationsComponent,
    ProgressNotesComponent,
    VitalsComponent
  ],
  imports: [
    CommonModule,
    InternalPatientDocumentsRoutingModule,
    SharedModule,
  ]
})
export class InternalPatientDocumentsModule { }
