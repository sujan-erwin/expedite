import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { InternalPatientDocumentsComponent } from './internal-patient-documents.component';

const routes: Routes = [
  {
    path: '',
    component: InternalPatientDocumentsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InternalPatientDocumentsRoutingModule { }
