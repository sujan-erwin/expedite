import { Component, OnInit, OnDestroy, ViewChild, TemplateRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Title } from '@angular/platform-browser';
import { take, map } from 'rxjs/operators';
import { interval } from 'rxjs';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { SpinnerService } from 'src/app/services/spinner/spinner.service';
import { PatientSummaryService } from 'src/app/patient-summary/store/patient-summary.service';
import { EncryptDecrypt } from 'src/app/services/crypto-js/crypto-js.encrypt.decrypt';
import { allPaths } from 'src/app/util/app-routes';
import { SearchService } from 'src/app/services/search/search.service';
import { PatientDocumentService } from 'src/app/services/patient-document/patient-document.service';
import { AuthService } from 'src/app/services/auth/auth.service';
import { errorBanners } from 'src/app/util/error-messages';

export interface errorBlock {
  medicationsErrTitle: any,
  medicationsErrMsg: any,
  isMedicationsErr: boolean,
  status: number;
  statusRetry: boolean;
}
export interface errorBlockCompleteMed {
  completeMedicationsErrTitle: any,
  completeMedicationsErrMsg: any,
  isCompleteMedicationsErr: boolean,
  status: number;
  statusRetry: boolean;
}
export interface errorBlockPN {
  progressNotesErrTitle: string;
  progressNotesErrMsg: string;
  isProgressNotesErr: boolean;
  status: number;
  statusRetry: boolean;
}
export interface errorBlockCompletePN {
  completePNErrTitle: any,
  completePNErrMsg: any,
  isCompletePNErr: boolean,
  status: number;
  statusRetry: boolean;
}
export interface errorBlockVitals {
  vitalsErrTitle: any,
  vitalsErrMsg: any,
  status: number;
  isVitalsErr: boolean
  statusRetry: boolean;
}
export interface errorBlockCompleteVitals {
  completeVitalsErrTitle: any,
  completeVitalsErrMsg: any,
  isCompleteVitalsErr: boolean,
  status: number;
  statusRetry: boolean;
}
export interface errorBlockConditions {
  conditionsErrTitle: any,
  conditionsErrMsg: any,
  status: number;
  isConditionsErr: boolean
  statusRetry: boolean;
}
export interface errorBlockCompleteConditions {
  completeConditionsErrTitle: any,
  completeConditionsErrMsg: any,
  isCompleteConditionsErr: boolean,
  status: number;
  statusRetry: boolean;
}
export interface errorBlockAllergies {
  allergiesErrTitle: any,
  allergiesErrMsg: any,
  isAllergiesErr: boolean,
  status: number;
  statusRetry: boolean;
}
export interface errorBlockCompleteAllergies {
  completeAllergiesErrTitle: any,
  completeAllergiesErrMsg: any,
  isCompleteAllergiesErr: boolean,
  status: number;
  statusRetry: boolean;
}

@Component({
  selector: 'app-internal-patient-documents',
  templateUrl: './internal-patient-documents.component.html',
  styleUrls: ['./internal-patient-documents.component.scss']
})
export class InternalPatientDocumentsComponent implements OnInit, OnDestroy {
  @ViewChild('noSearchResultsmodal', { read: TemplateRef }) noSearchResultsmodal: TemplateRef<any>;
  // FormGroups
  filterForm: FormGroup;
  internalPatientDocumentForm: FormGroup;
  commentSectionForm: FormGroup;

  // any Type
  patient: any;
  docList: any = [];
  organizationFilterValues: any = [];
  typeFilterValues: any = [];
  filteredDocuments: any = [];
  searchedDocuments: any = [];
  relevantDocuments: any = [];
  prescriber: any;
  matchedOrgname: any;
  originalDocList: any = [];
  result: any = { display: false };
  statusCode: string;
  httpStatusCode: string;
  modalRef: any;
  searchResultResponse: string = "";
  selectedFilters: any = [];
  medicationlistStatus: any;
  retrievalDocStatus = ['CCD Retrieval Success', 'Relevant Document Retrieval Success', 'Relevant CCD Retrieval Success'];
  hbsId: any;
  medicationsData: any;
  progressNotesData: any;
  vitalsData: any;
  conditionsData: any;
  allergiesData: any;
  completeMedicationsData: any;
  completePNData: any;
  completeVitalsData: any;
  completeConditionsData: any;
  completeAllergiesData: any;
  viewAll: boolean = false;
  showPN: boolean = false;
  individualProgressNotes: any;
  isMedicationsDataLoading: boolean = false;
  isProgressNotesDataLoading: boolean = false;
  isVitalsDataLoading: boolean = false;
  isConditionsDataLoading: boolean = false;
  isAllergiesDataLoading: boolean = false;
  isCompleteMedicationsDataLoading: boolean = false;
  isCompletePNDataLoading: boolean = false;
  isCompleteVitalsDataLoading: boolean = false;
  isCompleteConditionsDataLoading: boolean = false;
  isCompleteAllergiesDataLoading: boolean = false;
  isRefreshClicked: boolean = false;
  isDisplayPSVOneHrDelay: boolean = false;
  isMedRecordsNotFound: boolean = false;
  isPNRecordsNotFound: boolean = false;
  isVitalsRecordsNotFound: boolean = false;
  isAllergiesRecordsNotFound: boolean = false;
  isConditionsRecordsNotFound: boolean = false;

  medicationsErrorBlock: errorBlock = {
    medicationsErrTitle: '',
    medicationsErrMsg: '',
    isMedicationsErr: false,
    status: -1,
    statusRetry: false
  }
  completeMedErrorBlock: errorBlockCompleteMed = {
    completeMedicationsErrTitle: '',
    completeMedicationsErrMsg: '',
    isCompleteMedicationsErr: false,
    status: -1,
    statusRetry: false
  }
  isMPDocsNotFound: boolean = false;
  pnErrorBlock: errorBlockPN = {
    progressNotesErrTitle: '',
    progressNotesErrMsg: '',
    isProgressNotesErr: false,
    status: -1,
    statusRetry: false
  }
  completePNErrorBlock: errorBlockCompletePN = {
    completePNErrTitle: '',
    completePNErrMsg: '',
    isCompletePNErr: false,
    status: -1,
    statusRetry: false
  }
  vitalsErrorBlock: errorBlockVitals = {
    vitalsErrTitle: '',
    vitalsErrMsg: '',
    isVitalsErr: false,
    status: -1,
    statusRetry: false
  }
  completeVitalsErrorBlock: errorBlockCompleteVitals = {
    completeVitalsErrTitle: '',
    completeVitalsErrMsg: '',
    isCompleteVitalsErr: false,
    status: -1,
    statusRetry: false
  }
  conditionsErrorBlock: errorBlockConditions = {
    conditionsErrTitle: '',
    conditionsErrMsg: '',
    isConditionsErr: false,
    status: -1,
    statusRetry: false
  }
  completeConditionsErrorBlock: errorBlockCompleteConditions = {
    completeConditionsErrTitle: '',
    completeConditionsErrMsg: '',
    isCompleteConditionsErr: false,
    status: -1,
    statusRetry: false
  }
  allergiesErrorBlock: errorBlockAllergies = {
    allergiesErrTitle: '',
    allergiesErrMsg: '',
    isAllergiesErr: false,
    status: -1,
    statusRetry: false
  }
  completeAllergiesErrorBlock: errorBlockCompleteAllergies = {
    completeAllergiesErrTitle: '',
    completeAllergiesErrMsg: '',
    isCompleteAllergiesErr: false,
    status: -1,
    statusRetry: false
  }

  // Boolean variables
  show: boolean = true;
  showFeedback: boolean = false;
  isSearchClicked: boolean = false;
  showFeedbackComment: boolean = false;
  patientDetailsCollapsed: boolean = true;
  isInvalidSearch: boolean = false;
  ClinicalContent: boolean = false;
  isParityPatient: boolean = true;

  sourcePage: any = '';

  lookup: any = '';

  question1: any = "Did you find all the information you needed to complete the task?";
  question2: any = "What information could you not find?";


  showAll: boolean;
  showAllType: string;
  activeTab: string;
  showIndividualPN: boolean;

  allDocumentsLoaded: boolean;
  continue: boolean;
  autoPolling: boolean;
  statusTextMap: any;

  // Automatic polling logic for Demographic search
  //automaticRetryInterval = interval(3000);
  automaticRetryInterval = interval(10000);
  automaticRetryCount: number;

  refresh: boolean = false;
  pollingAfterRefresh: boolean = false;
  initialDelayAfterQueueingPatient = 29000;


  constructor(
    private searchService: SearchService,
    private patientDocService: PatientDocumentService,
    private spinnerService: SpinnerService,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private titleService: Title,
    private patientSummaryService: PatientSummaryService,
    private encryptDecrypt: EncryptDecrypt
  ) {
    this.internalPatientDocumentForm = fb.group({
      searchBar: ['', []]
    });
    this.commentSectionForm = fb.group({
      comments: ['', [Validators.required]],
    });
    this.filterForm = fb.group({
      type: [[]],
      organization: [[]]
    });
    this.statusTextMap = new Map<string, string>();
    this.populateDocs();
    this.titleService.setTitle("Dataviewer - Internal Documents Results");
    if (this.searchService.getShowfeedbackQuestion() !== undefined) {
      this.show = this.searchService.getShowfeedbackQuestion();
    }
    this.sourcePage = this.searchService.getSourceLookupPage();
    this.showAll = false;
    this.activeTab = "clinical-summary";
    // this.activeTab = "additional-documents";
    this.hbsId = this.searchService.retrieveHbsId;
    this.searchService.getResultBannerStatus().subscribe(status => {
      const resultBanner = this.searchService.retrieveResultBanner();
      if (status && resultBanner && resultBanner.display && this.searchService.retrieveLookupOption() === "refresh") {
        this.result = resultBanner;
        this.refresh = true;
        //  this.searchService.storeResultBanner(null);
      }
    });
    if (this.searchService.retrieveLookupOption() !== "refresh") {
      this.searchService.storeResultBanner(null);
    }
  }

  ngOnInit() {
    this.isMPDocsNotFound = JSON.parse(localStorage.getItem('isMPDocsNotFound'));
    this.route.queryParams.subscribe(params => {
      this.statusCode = params['statusCode'];
      this.httpStatusCode = params['httpStatusCode'];
      if (this.sourcePage === undefined && localStorage.getItem("patientLookup") === 'Patient lookup') {
        this.lookup = localStorage.getItem("patientLookup");
        this.sourcePage = this.lookup;
      } else if (this.sourcePage === undefined && localStorage.getItem("quickLookup") === 'Quick lookup') {
        this.lookup = localStorage.getItem("quickLookup");
        this.sourcePage = this.lookup;
      }
    });
    if (!this.patient.srcPatientId || !this.patient.srcPatientId.startsWith("CCD")) {
      this.isParityPatient = false;
      if (this.docList && this.docList.length > 0) {
        this.ClinicalContent = true;
      }
      setTimeout(() => {
        this.dispatchPSV();
      }, 500)
    }

    // Activate auto refresh only for demographic search
    if (this.searchService.retrieveLookupOption() === 'demographic' && this.searchService.retrieveDemographicLookupOption() === 'demographicAddressLookup') {
      console.log("Current search type: ", this.searchService.retrieveLookupOption());
      console.log("Current demographic search type: ", this.searchService.retrieveDemographicLookupOption());
      this.documentsTableAutoRefresh()
    };
    this.allDocumentsLoaded = false;
    this.continue = true;
    this.autoPolling = false;
  }

  dispatchPSV() {
    setTimeout(() => {
      if (this.patient.HBSID) this.getMedicationsData();
      if (this.patient.HBSID) this.getProgressNotesData();
      if (this.patient.HBSID) this.getVitalsData();
      if (this.patient.HBSID) this.getConditionsData();
      if (this.patient.HBSID) this.getAllergiesData();
    }, 10)
  }

  onClickShowDocs() {
    this.ClinicalContent = false;
    this.onClickTab("clinical-summary");
    this.isRefreshClicked = false;
    this.isDisplayPSVOneHrDelay = false;
  }
  onClickShowClinicalSummary() {
    this.ClinicalContent = true;
    this.activeTab = "clinical-summary";
  }

  populateDocs() {
    this.patient = this.searchService.getInternalResourceToPatient();
    const internalResource = this.searchService.getInternalResource();
    let oldHBSID = this.patientDocService.getOldHBSID();

    if (internalResource) {
      let list = this.patientDocService.getDocList();
      this.originalDocList = list;
      if (oldHBSID != this.patient.HBSID) {
        this.docList = internalResource.docRefs ? internalResource.docRefs : [];
        this.docList = this.docList.filter(doc => doc.contentType == "text/xml");
        this.originalDocList = this.docList;
        this.docList = this.sortList(this.docList);
        this.filteredDocuments = this.docList;
        this.patientDocService.setDocList(this.docList);
        this.patientDocService.setOldHBSID(this.patient.HBSID);
        this.prescriber = internalResource.prescriber;
        this.patientDocService.setPrescriber(this.prescriber);
        this.initializeStatusMap(this.filteredDocuments);
      }
      else {
        this.docList = this.sortList(list);
        this.initializeStatusMap(this.docList);
        this.prescriber = this.patientDocService.getPrescriber();
      }
      this.prescriber = this.prescriber ? this.prescriber : {};
      console.log("Displaying prescriber information");
    }
    this.filterForm.valueChanges.subscribe(values => {
      this.filterDocuments(values);
    });
    this.updateFilterValues();
    this.populateMatchedOrgname();
  }

  getPreviousPage() {
    let page = allPaths.quickLookUp.link;
    let ob = sessionStorage.getItem("breadcrumbList");
    let breadcrumbList = (ob && ob != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(ob)) : null;
    if (breadcrumbList.length > 1) {
      return this.getPreviousPath(breadcrumbList[breadcrumbList.length - 2]);
    }
    return page;
  }
  getPreviousPath(breadcrumbName) {
    for (const [key, value] of Object.entries(allPaths)) {
      if (value.label === breadcrumbName.label) {
        return value.link;
      }
    }
  }

  editSearch() {
    if (this.searchService.retrieveLookupOption() === 'demographic') {
      const Demo_VAL = this.searchService.retrieveDemographicsInfo();
      Demo_VAL.addressline1 = null;
      Demo_VAL.city = null;
      Demo_VAL.state = null;
      this.searchService.storeDemographicsInfo(Demo_VAL);
      this.router.navigate([this.getPreviousPage()]);
    } else {
      this.router.navigate([this.getPreviousPage()]);
    }
  }

  startSearch() {
    this.searchService.storeHbsId(null);
    this.searchService.setPatient(null);
    this.searchService.storeDemographicsInfo(null);
    this.router.navigate([this.getPreviousPage()]);
  }

  externalSearch() {
    this.searchService.storeResultBanner(this.result);
    this.searchService.setSourcePage("internalDocs");
    this.router.navigate([allPaths.advancedSearch.link]);
  }

  advancedSearch() {
    this.searchService.setSourcePage("internalDocs");
    this.router.navigate([allPaths.advancedSearch.link]);

  }

  escapeHtml(input) {
    let orgSearchTerm = input;
    let searchTermFirstChar, searchTermLastChar;
    if (input.charAt(0) == '"') { searchTermFirstChar = true; }
    if (orgSearchTerm.length > 1 && input.charAt(input.length - 1) == '"') { searchTermLastChar = true; }
    if (searchTermFirstChar && searchTermLastChar) {
      input = orgSearchTerm.slice(1, orgSearchTerm.length - 1);
    }
    input = input.replaceAll('"', '&quot;');
    if (searchTermFirstChar && searchTermLastChar) { input = '\\"' + input + '\\"' };
    return input.replaceAll('<', '&lt;').replaceAll('>', '&gt;');
  }

  // on click of Enter button in search bar
  EnterSubmit(event) {
    if (event.keyCode === 13) {
      this.sendSearchItem();
    }
  }

  evaluateSearchInput(event?: any) {
    if (this.internalPatientDocumentForm.controls.searchBar.value == '') {
      this.isInvalidSearch = false;
      return;
    }
    var format = /[()<\\]+/;
    this.isInvalidSearch = format.test(this.internalPatientDocumentForm.controls.searchBar.value);
    if (event.keyCode === 13 && !this.isInvalidSearch) {
      this.sendSearchItem();
    }
  }

  // Initiating searchInput service
  sendSearchItem() {
    this.clearFilters();
    this.resetErrorBanner();
    this.isRefreshClicked = false;
    this.isDisplayPSVOneHrDelay = false;
    var ids = this.docList.map(function (docRef) { return docRef.id; });
    console.log("Before SearchInput service call:");
    this.searchService.searchInput(this.internalPatientDocumentForm.controls.searchBar.value, ids, this.patient.HBSID).subscribe((data: any) => {
      this.handleSearchResponse(data)
    }, (error) => {
      if (error.response) {
        this.handleError(error.response, error.response.statusCode);
      }
      else {
        this.handleError(null, null);
      }
    }
    );
  }

  // Handling searchInput Response
  handleSearchResponse(body) {
    this.spinnerService.hide();
    if (body && body.response) {
      console.log("service call submitted successfully")
      if (body.response.statusCode === '0000') {
        const docIds = body.response.resources[0].docIds;
        this.filteredDocuments = this.docList.filter(function (item) {
          return docIds.includes(item.id);
        });
        this.searchedDocuments = this.filteredDocuments.filter(function (item) {
          return docIds.includes(item.id);
        });
        const retrievalDocStat = this.retrievalDocStatus;
        this.relevantDocuments = this.docList.filter(function (item) {
          return retrievalDocStat.includes(item.status);
        });
      }
      else {
        this.searchResultResponse = body.response.statusDesc;
        this.filteredDocuments = [];
        this.searchedDocuments = [];
        this.relevantDocuments = [];
      }
      this.isSearchClicked = true;
      this.checkOpenNoSearchResultsModal();
    }
  }

  handleError(response, statusCode) {
    this.resetErrorBanner();
    this.spinnerService.hide();
    this.result.display = true;
    if (response) {
      console.log("Error response", response);
      this.result.banner = errorBanners.internalPatientSearch[response.statusCode];
      if (!this.result.banner) {
        this.result.banner = errorBanners.internalPatientSearch.default;
      }
    }
    else {
      this.result.banner = errorBanners.internalPatientSearch[1111];
    }
    if (!this.result.banner) {
      let code = statusCode ? statusCode : 'default';
      this.result.banner = errorBanners.internalPatientSearch[code];
    }
    if (this.result.banner && this.result.banner.displayResponseStatus) {
      this.result.banner.info = `${statusCode} - ${response?.statusDesc}`;
    }
  }

  resetErrorBanner() {
    this.result.display = false;
  }
  // call clearSearch function if there is no value in SearchBar
  updateSearchResults() {
    if (!this.internalPatientDocumentForm.controls.searchBar.value) {
      this.clearAll();
    }
  }
  closeBanner() {
    this.result.display = false;
  }

  // Filters logic
  filterDocuments(filter) {
    if (filter === '') {
      this.filteredDocuments = this.docList.filter(item => {
        return true;
      });
    } else {
      this.filteredDocuments = this.docList.filter(item => {
        var isAllowed = true;
        if (filter.type.length) {
          if (filter.type.indexOf(item.type) === -1) {
            isAllowed = false;
          }
        } else {
          isAllowed = true;
        }
        if (isAllowed) {
          if (filter.organization.length) {
            if (filter.organization.indexOf(item.orgName) === -1) {
              isAllowed = false;
            }
          } else {
            isAllowed = true;
          }
        }
        return isAllowed;
      });
    }
  }

  // Update Filter values
  updateFilterValues() {
    this.organizationFilterValues = [];
    this.typeFilterValues = [];
    if (!this.docList) { this.docList = [] };
    this.docList.forEach(doc => {
      //document.organization
      if (this.organizationFilterValues.indexOf(doc.orgName) === -1) {
        this.organizationFilterValues.push(doc.orgName);
      }
      //document.type
      if (this.typeFilterValues.indexOf(doc.type) === -1) {
        this.typeFilterValues.push(doc.type);
      }
    });
    this.filterDocuments(this.filterForm.value);
    this.organizationFilterValues.sort();
    this.typeFilterValues.sort();
    this.initialOrganizationValues = this.organizationFilterValues;
    this.initialTypeValues = this.typeFilterValues;
  }
  filterTypes: any = {};
  initialOrganizationValues: any = [];
  initialTypeValues: any = [];

  isFiltersSelected() {
    return (this.filterTypes.type && this.filterTypes.type.length > 0) || (this.filterTypes.organization && this.filterTypes.organization.length > 0);
  }
  // Apply Filter on values
  applyFilter(attr) {
    this.isRefreshClicked = false;
    this.isDisplayPSVOneHrDelay = false;
    var typeFilter = attr[0];
    var values = attr[1];
    // this.selectedFilterValues = values;
    if ("Type" == typeFilter) {
      var filteredTypes = this.initialTypeValues.filter(item => {
        if (values.indexOf(item) !== -1) {
          return true;
        }
        return false;
      });
      this.filterTypes.type = filteredTypes;
      if (!filteredTypes || filteredTypes.length === 0) {
        this.typeFilterValues = this.initialTypeValues;
      }
      else {
        this.typeFilterValues = [];
        this.typeFilterValues = filteredTypes;
      }
    }
    else if ("Organization" == typeFilter) {
      var filteredOrgs = this.initialOrganizationValues.filter(item => {
        if (values.indexOf(item) !== -1) {
          return true;
        }
        return false;
      });
      this.filterTypes.organization = filteredOrgs;
      if (!filteredOrgs || filteredOrgs.length === 0) {
        this.organizationFilterValues = this.initialOrganizationValues;
      }
      else {
        this.organizationFilterValues = [];
        this.organizationFilterValues = filteredOrgs;
      }
    }
    if ((!this.filterTypes.organization || this.filterTypes.organization.length === 0) && (!this.filterTypes.type || this.filterTypes.type.length === 0)) {
      if (this.internalPatientDocumentForm.controls.searchBar.value && this.isSearchClicked) {
        this.filteredDocuments = this.searchedDocuments;
      }
      else {
        this.filteredDocuments = this.docList;
        this.organizationFilterValues = this.initialOrganizationValues;
        this.typeFilterValues = this.initialTypeValues;
      }
    }
    if (!this.isSearchClicked) {
      this.filteredDocuments = this.docList;
    }
    else if (this.isSearchClicked) {
      this.filteredDocuments = this.searchedDocuments;
    }
    if (this.filterTypes.type && this.filterTypes.type.length > 0) {
      this.filteredDocuments = this.filteredDocuments.filter(item => {

        if (this.filterTypes.type && this.filterTypes.type.indexOf(item.type) !== -1) {
          return true;
        }
        return false;
      });
    }
    if (this.filterTypes.organization && this.filterTypes.organization.length > 0) {
      this.filteredDocuments = this.filteredDocuments.filter(item => {
        if (this.filterTypes.organization && this.filterTypes.organization.indexOf(item.orgName) !== -1) {
          return true;
        }
        return false;
      });
    }
    this.checkOpenNoSearchResultsModal();
  }

  checkOpenNoSearchResultsModal() {
    if (this.isSearchClicked && this.internalPatientDocumentForm.controls.searchBar.value.length != 0 && this.searchedDocuments.length === 0) {
      this.openNoSearchResults(this.noSearchResultsmodal);
    }
  }
  openNoSearchResults(content) {
    var searchBarText = this.internalPatientDocumentForm.controls.searchBar.value;
    this.clearAll();
    if (searchBarText) {
      this.searchBar.setValue(searchBarText);
    }
    this.modalRef = this.modalService.open(content, { centered: true, size: 'lg' }).result.then((result) => {
    }, (reason) => {
      this.close();
    });
  }

  isEligibleToShow() {
    return this.isFiltersSelected()
  }
  isEligibleToShowSearch() {
    let userProfile = this.authService.getUserProfile();
    return (userProfile.groups && userProfile.groups.includes('specialty-expedite-pilot') && !this.isParityPatient)
    // return true;
  }
  isEligibleToShowRelevant() {
    return (this.isSearchClicked && this.internalPatientDocumentForm.controls['searchBar'].value.length > 0)
  }
  // Clear applied filters
  clearFilters() {
    this.selectedFilters = [];
    if (this.internalPatientDocumentForm.controls['searchBar'].value.length === 0) {
      this.filteredDocuments = this.docList;
    }
    this.organizationFilterValues = this.initialOrganizationValues;
    this.typeFilterValues = this.initialTypeValues;
    this.filterTypes = [];
  }

  clearAll() {
    this.internalPatientDocumentForm.reset();
    this.searchBar.setValue("");
    this.resetErrorBanner();
    this.isInvalidSearch = false;
    if (this.isSearchClicked) {
      this.populateDocs();
    }
    this.searchedDocuments = [];
    this.isSearchClicked = false;
    this.selectedFilters = [];
    this.internalPatientDocumentForm.controls['searchBar'].value == '';
    this.filteredDocuments = this.docList;
    this.organizationFilterValues = this.initialOrganizationValues;
    this.typeFilterValues = this.initialTypeValues;
    this.filterTypes = {};
  }

  // Display Matched Orgname from the original doclist
  populateMatchedOrgname() {
    if (!this.filteredDocuments || this.filteredDocuments.length === 0) return;
    var ids = this.filteredDocuments.map(function (docRef) { return docRef.id; });
    this.originalDocList.some(doc => {
      if (ids.includes(doc.id) && this.isRelaventSuccessDoc(doc.status)) {
        this.matchedOrgname = doc.orgName;
        return true;
      }
    });
  }

  isRelaventSuccessDoc(status) {
    return status === 'Relevant CCD Retrieval Success' || status === 'Relevant Document Retrieval Success';
  }

  isRelevantURLRealTimeCall(status) {
    return status === 'Relevant CCD Retrieval Success' || status === 'Relevant Document Retrieval Success' || status === 'CCD Retrieval Success';
  }

  openDocument(document) {
    let sDoc = Object.assign({}, document);
    document.viewStatus = "loading";
    // update view status
    this.statusTextMap.set(document.id, document.viewStatus);
    this.patientDocService.getInternalDocumentList(this.patient, document).subscribe((data: any) => {
      if (data && data.response.statusCode === '0000') {
        document.viewStatus = "viewed";
        // update view status
        this.statusTextMap.set(document.id, document.viewStatus);
        if (document.contentType == "text/xml") {
          var htmlContent = window.atob(data.response.resources[0].content);
          const newWindow = window.open(document.id + '.html');
          newWindow.document.title = document.title;
          newWindow.document.write(htmlContent);
        } else if (document.contentType == "application/pdf") {
          var pdfContent = data.response.resources[0].content;
          let blob = this.base64ToBlob(pdfContent, 'application/pdf');
          const blobURL = URL.createObjectURL(blob);
          const theWindow = window.open("");
          theWindow.document.write("<iframe width='100%' height='100%' src='" + blobURL + "'></iframe>");
        }
      } else {
        this.handleRetry(document);
      }
    }, error => {
      this.handleRetry(document);
    });
  }

  //converts base64 to blob type
  base64ToBlob(base64: string, contentType: string) {
    const binStr = window.atob(base64);
    const len = binStr.length;
    const arr = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      arr[i] = binStr.charCodeAt(i);
    }
    return new Blob([arr], { type: contentType });
  }

  handleRetry(document) {
    document.viewStatus = "retry";
    // update view status
    this.statusTextMap.set(document.id, document.viewStatus);
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 3) {
      document.viewStatus = "error";
      // update view status
      this.statusTextMap.set(document.id, document.viewStatus);
    }
  }

  sortList(list) {
    if (list) {
      let sortOrder = {
        1: ["Continuity of Care Document", "Summarization of episode note", "Ambulatory Summary", "Summary of episode note"],
        2: "Encounter Summary",
        3: "Location Summary"
      };//Keep all the order in lower case.
      let ccdList = list.filter(function (item) {
        return item.typeCode === '34133-9' && item.type &&
          (
            item.type.includes(sortOrder[1][0]) ||
            item.type.includes(sortOrder[1][1]) ||
            item.type.includes(sortOrder[1][2]) ||
            item.type.includes(sortOrder[1][3])
          );
      });
      if (ccdList) {
        ccdList = ccdList.sort(function (a, b) {

          return a.orgName > b.orgName ? 1 : a.orgName < b.orgName ? -1 : 0;
        });
      }
      let encounterSumList = list.filter(function (item) {
        return (item.typeCode === '11506-3') || (item.typeCode === '34133-9' && item.type && item.type.includes(sortOrder[2]));
      });
      encounterSumList = this.sortByEncounterDate(encounterSumList);
      let ssLSumList = list.filter(function (item) {
        return item.typeCode === '34133-9' && item.type && item.type.includes(sortOrder[3]);
      });
      var ids = ccdList.map(function (docRef) { return docRef.id; });
      encounterSumList.forEach(docRef => { ids.push(docRef.id) });
      ssLSumList.forEach(docRef => { ids.push(docRef.id); });

      let typeCodeNullList = list.filter(function (item) {
        return (item.typeCode == "") || !(ccdList.includes(item) || encounterSumList || ssLSumList.includes(item))
      });
      var nullListIds = typeCodeNullList.map(function (docRef) { return docRef.id });
      ids = [].concat(ids, nullListIds);
      let otherList = list.filter(function (item) {
        return !ids.includes(item.id);
      });
      let dateList = [].concat(typeCodeNullList, encounterSumList, otherList);
      dateList = this.sortByEncounterDate(dateList);
      ccdList = this.sortByEncounterDate(ccdList);
      ssLSumList = this.sortByEncounterDate(ssLSumList);
      list = [].concat(ccdList, dateList, ssLSumList);
    }
    return list;
  }
  sortByEncounterDate(list) {
    if (list) {
      list = list.sort(function (a, b) {
        let aDate = a.encounterDate;
        let bDate = b.encounterDate;
        aDate = !aDate || aDate == '' ? '01/01/1888' : aDate;
        bDate = !bDate || bDate == '' ? '01/01/1888' : bDate;
        return <any>new Date(bDate) - <any>new Date(aDate);
      });
    }
    return list;
  }

  // Hide feedback modal when user submits the answer
  hideFeedbackModal() {
    this.show = false;
  }

  toggle() {
    this.show = !this.show;
    this.searchService.setShowfeedbackQuestion(this.show);
    this.showFeedback = !this.showFeedback;
    setTimeout(() => {
      this.showFeedback = !this.showFeedback;
    }, 3000);
  }

  // capture feedback - service call when user clicks "YES"
  feedbackAnswerYes() {
    this.searchService.captureFeedback(this.patient.HBSID, "Yes", null).subscribe(data => { console.log("yes", data) });
  }

  // open modal when user clicks "No" to display comment section
  open(content) {
    this.showFeedbackComment = true;
    this.modalRef = this.modalService.open(content, { centered: true, size: 'lg' }).result.then((result) => {
    }, (reason) => {
      this.close();
    });
  }

  // capture feedback - service call when user clicks "NO"
  feedbackAnswerComment() {
    if (this.commentSectionForm.valid) {
      this.hideFeedbackModal();
      this.searchService.captureFeedback(this.patient.HBSID, "No", this.commentSectionForm.value).subscribe(data => {
        this.spinnerService.hide();
        this.showFeedbackComment = false;
        this.searchService.setShowfeedbackQuestion(false);
        setTimeout(() => {
          this.close();
        }, 3000);
      }, error => this.errorResponse(error))
    }
    else {
      this.validateAllFormFields(this.commentSectionForm);
    }
  }

  errorResponse(data) {

  }

  // close the modal when user clicks cross button in the modal
  close() {
    this.modalService.dismissAll();
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        if (!control.valid && !control.value) {
          control.markAsTouched();
        }
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngOnDestroy() {
    if (this.modalService.hasOpenModals()) {
      this.close();
    }
  }

  get searchBar() { return this.internalPatientDocumentForm.get('searchBar'); }
  get comments() { return this.commentSectionForm.get('comments'); }

  reloadAllWidgets() {
    if (!this.patient.srcPatientId || !this.patient.srcPatientId.startsWith("CCD")) {
      this.isParityPatient = false;
      if (this.patient.HBSID) this.getMedicationsData();
      if (this.patient.HBSID) this.getProgressNotesData();
      if (this.patient.HBSID) this.getVitalsData();
      if (this.patient.HBSID) this.getConditionsData();
      if (this.patient.HBSID) this.getAllergiesData();
    }
  }

  getMedicationsData(refresh?: boolean) {
    this.isMedicationsDataLoading = true;
    // setTimeout(() => {
    this.patientSummaryService.medicationsList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.medicationsData = response;
        if (this.medicationsData && this.medicationsData.response.statusCode === '7000') {
          this.isMedRecordsNotFound = true;
        } else {
          this.isMedRecordsNotFound = false;
        }
        this.isMedicationsDataLoading = false;
        this.medicationsErrorBlock = {
          medicationsErrTitle: '',
          medicationsErrMsg: '',
          isMedicationsErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showMedErrorMsg(error.status, refresh);
        }
        this.isMedicationsDataLoading = false;
      }
    );
    //  }, 50000)

  }

  getProgressNotesData(refreshStatus?: boolean) {
    this.isProgressNotesDataLoading = true;
    // setTimeout(() => {
    this.patientSummaryService.progressNotesList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.progressNotesData = response;
        if (this.progressNotesData && this.progressNotesData.response.statusCode === '7000') {
          this.isPNRecordsNotFound = true;
        } else {
          this.isPNRecordsNotFound = false;
        }
        this.isProgressNotesDataLoading = false;
        this.pnErrorBlock = {
          progressNotesErrTitle: '',
          progressNotesErrMsg: '',
          isProgressNotesErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showPNErrorMsg(error.status, refreshStatus);
        }
        this.isProgressNotesDataLoading = false;
      }
    );
    // }, 50000)

  }

  getVitalsData(refreshStatus?: boolean) {
    this.isVitalsDataLoading = true;
    //  setTimeout(() => {
    this.patientSummaryService.vitalsList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.vitalsData = response;
        if (this.vitalsData && this.vitalsData.response.statusCode === '7000') {
          this.isVitalsRecordsNotFound = true;
        } else {
          this.isVitalsRecordsNotFound = false;
        }
        this.isVitalsDataLoading = false;
        this.vitalsErrorBlock = {
          vitalsErrTitle: '',
          vitalsErrMsg: '',
          isVitalsErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showVitalsErrorMsg(error.status, refreshStatus);
        }
        this.isVitalsDataLoading = false;
      }
    );
    // }, 50000)

  }

  getConditionsData(refreshStatus?: boolean) {
    this.isConditionsDataLoading = true;
    //  setTimeout(() => {
    this.patientSummaryService.conditionsList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.conditionsData = response;
        if (this.conditionsData && this.conditionsData.response.statusCode === '7000') {
          this.isConditionsRecordsNotFound = true;
        } else {
          this.isConditionsRecordsNotFound = false;
        }
        this.isConditionsDataLoading = false;
        this.conditionsErrorBlock = {
          conditionsErrTitle: '',
          conditionsErrMsg: '',
          isConditionsErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showConditionsErrorMsg(error.status, refreshStatus);
        }
        this.isConditionsDataLoading = false;
      }
    );
    // }, 50000)

  }

  getAllergiesData(refreshStatus?: boolean) {
    this.isAllergiesDataLoading = true;
    //  setTimeout(() => {
    this.patientSummaryService.allergiesList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.allergiesData = response;
        if (this.allergiesData && this.allergiesData.response.statusCode === '7000') {
          this.isAllergiesRecordsNotFound = true;
        } else {
          this.isAllergiesRecordsNotFound = false;
        }
        this.isAllergiesDataLoading = false;
        this.allergiesErrorBlock = {
          allergiesErrTitle: '',
          allergiesErrMsg: '',
          isAllergiesErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showAllergiesErrorMsg(error.status, refreshStatus);
        }
        this.isAllergiesDataLoading = false;
      }
    );
    // }, 50000)

  }

  showMedErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.medicationsErrorBlock.isMedicationsErr = true
      this.medicationsErrorBlock.medicationsErrMsg = "We couldn't load the appropriate information at this time."
      this.medicationsErrorBlock.medicationsErrTitle = title;
    } else if (status === 404) {
      this.medicationsErrorBlock.isMedicationsErr = true
      this.medicationsErrorBlock.medicationsErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.medicationsErrorBlock.medicationsErrTitle = title;
    } else if (status === 500) {
      this.medicationsErrorBlock.isMedicationsErr = true
      this.medicationsErrorBlock.medicationsErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh medications and try again."
      this.medicationsErrorBlock.medicationsErrTitle = 'A server error occured.';
      this.medicationsErrorBlock.statusRetry = refreshStatus;
    } else {
      this.medicationsErrorBlock.isMedicationsErr = true
      this.medicationsErrorBlock.medicationsErrMsg = "We couldn't load the appropriate information at this time."
      this.medicationsErrorBlock.medicationsErrTitle = title;
    }
    this.medicationsErrorBlock.status = status;
  }

  showCompleteMedicationsErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.completeMedErrorBlock.isCompleteMedicationsErr = true
      this.completeMedErrorBlock.completeMedicationsErrMsg = "We couldn't load the appropriate information at this time."
      this.completeMedErrorBlock.completeMedicationsErrTitle = title;
    } else if (status === 404) {
      this.completeMedErrorBlock.isCompleteMedicationsErr = true
      this.completeMedErrorBlock.completeMedicationsErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.completeMedErrorBlock.completeMedicationsErrTitle = title;
    } else if (status === 500) {
      this.completeMedErrorBlock.isCompleteMedicationsErr = true
      this.completeMedErrorBlock.completeMedicationsErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh Medications and try again."
      this.completeMedErrorBlock.completeMedicationsErrTitle = "A server error occured.";
      this.completeMedErrorBlock.statusRetry = refreshStatus;
    } else {
      this.completeMedErrorBlock.isCompleteMedicationsErr = true
      this.completeMedErrorBlock.completeMedicationsErrMsg = "We couldn't load the appropriate information at this time."
      this.completeMedErrorBlock.completeMedicationsErrTitle = title;
    }
    this.completeMedErrorBlock.status = status;
  }

  showPNErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.pnErrorBlock.isProgressNotesErr = true
      this.pnErrorBlock.progressNotesErrMsg = "We couldn't load the appropriate information at this time."
      this.pnErrorBlock.progressNotesErrTitle = title;
    } else if (status === 404) {
      this.pnErrorBlock.isProgressNotesErr = true
      this.pnErrorBlock.progressNotesErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.pnErrorBlock.progressNotesErrTitle = title;
    } else if (status === 500) {
      this.pnErrorBlock.isProgressNotesErr = true
      this.pnErrorBlock.progressNotesErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh encounter notes and try again."
      this.pnErrorBlock.progressNotesErrTitle = "A server error occured.";
      this.pnErrorBlock.statusRetry = refreshStatus;
    } else {
      this.pnErrorBlock.isProgressNotesErr = true
      this.pnErrorBlock.progressNotesErrMsg = "We couldn't load the appropriate information at this time."
      this.pnErrorBlock.progressNotesErrTitle = title;
    }
    this.pnErrorBlock.status = status;
  }

  showCompletePNErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.completePNErrorBlock.isCompletePNErr = true
      this.completePNErrorBlock.completePNErrMsg = "We couldn't load the appropriate information at this time."
      this.completePNErrorBlock.completePNErrTitle = title;
    } else if (status === 404) {
      this.completePNErrorBlock.isCompletePNErr = true
      this.completePNErrorBlock.completePNErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.completePNErrorBlock.completePNErrTitle = title;
    } else if (status === 500) {
      this.completePNErrorBlock.isCompletePNErr = true
      this.completePNErrorBlock.completePNErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh Encounter Notes and try again."
      this.completePNErrorBlock.completePNErrTitle = "A server error occured.";
      this.completePNErrorBlock.statusRetry = refreshStatus;
    } else {
      this.completePNErrorBlock.isCompletePNErr = true
      this.completePNErrorBlock.completePNErrMsg = "We couldn't load the appropriate information at this time."
      this.completePNErrorBlock.completePNErrTitle = title;
    }
    this.completePNErrorBlock.status = status;
  }

  showVitalsErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.vitalsErrorBlock.isVitalsErr = true
      this.vitalsErrorBlock.vitalsErrMsg = "We couldn't load the appropriate information at this time."
      this.vitalsErrorBlock.vitalsErrTitle = title;
    } else if (status === 404) {
      this.vitalsErrorBlock.isVitalsErr = true
      this.vitalsErrorBlock.vitalsErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.vitalsErrorBlock.vitalsErrTitle = title;
    } else if (status === 500) {
      this.vitalsErrorBlock.isVitalsErr = true
      this.vitalsErrorBlock.vitalsErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh Vitals and try again."
      this.vitalsErrorBlock.vitalsErrTitle = "A server error occured.";
      this.vitalsErrorBlock.statusRetry = refreshStatus;
    } else {
      this.vitalsErrorBlock.isVitalsErr = true
      this.vitalsErrorBlock.vitalsErrMsg = "We couldn't load the appropriate information at this time."
      this.vitalsErrorBlock.vitalsErrTitle = title;
    }
    this.vitalsErrorBlock.status = status;
  }

  showCompleteVitalsErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.completeVitalsErrorBlock.isCompleteVitalsErr = true
      this.completeVitalsErrorBlock.completeVitalsErrMsg = "We couldn't load the appropriate information at this time."
      this.completeVitalsErrorBlock.completeVitalsErrTitle = title;
    } else if (status === 404) {
      this.completeVitalsErrorBlock.isCompleteVitalsErr = true
      this.completeVitalsErrorBlock.completeVitalsErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.completeVitalsErrorBlock.completeVitalsErrTitle = title;
    } else if (status === 500) {
      this.completeVitalsErrorBlock.isCompleteVitalsErr = true
      this.completeVitalsErrorBlock.completeVitalsErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh Vitals and try again."
      this.completeVitalsErrorBlock.completeVitalsErrTitle = "A server error occured.";
      this.completeVitalsErrorBlock.statusRetry = refreshStatus;
    } else {
      this.completeVitalsErrorBlock.isCompleteVitalsErr = true
      this.completeVitalsErrorBlock.completeVitalsErrMsg = "We couldn't load the appropriate information at this time."
      this.completeVitalsErrorBlock.completeVitalsErrTitle = title;
    }
    this.completeVitalsErrorBlock.status = status;
  }

  showConditionsErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.conditionsErrorBlock.isConditionsErr = true
      this.conditionsErrorBlock.conditionsErrMsg = "We couldn't load the appropriate information at this time."
      this.conditionsErrorBlock.conditionsErrTitle = title;
    } else if (status === 404) {
      this.conditionsErrorBlock.isConditionsErr = true
      this.conditionsErrorBlock.conditionsErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.conditionsErrorBlock.conditionsErrTitle = title;
    } else if (status === 500) {
      this.conditionsErrorBlock.isConditionsErr = true
      this.conditionsErrorBlock.conditionsErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh Active Conditions and try again."
      this.conditionsErrorBlock.conditionsErrTitle = "A server error occured.";
      this.conditionsErrorBlock.statusRetry = refreshStatus;
    } else {
      this.conditionsErrorBlock.isConditionsErr = true
      this.conditionsErrorBlock.conditionsErrMsg = "We couldn't load the appropriate information at this time."
      this.conditionsErrorBlock.conditionsErrTitle = title;
    }
    this.conditionsErrorBlock.status = status;
  }

  showCompleteConditionsErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.completeConditionsErrorBlock.isCompleteConditionsErr = true
      this.completeConditionsErrorBlock.completeConditionsErrMsg = "We couldn't load the appropriate information at this time."
      this.completeConditionsErrorBlock.completeConditionsErrTitle = title;
    } else if (status === 404) {
      this.completeConditionsErrorBlock.isCompleteConditionsErr = true
      this.completeConditionsErrorBlock.completeConditionsErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.completeConditionsErrorBlock.completeConditionsErrTitle = title;
    } else if (status === 500) {
      this.completeConditionsErrorBlock.isCompleteConditionsErr = true
      this.completeConditionsErrorBlock.completeConditionsErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh Active Conditions and try again."
      this.completeConditionsErrorBlock.completeConditionsErrTitle = "A server error occured.";
      this.completeConditionsErrorBlock.statusRetry = refreshStatus;
    } else {
      this.completeConditionsErrorBlock.isCompleteConditionsErr = true
      this.completeConditionsErrorBlock.completeConditionsErrMsg = "We couldn't load the appropriate information at this time."
      this.completeConditionsErrorBlock.completeConditionsErrTitle = title;
    }
    this.completeConditionsErrorBlock.status = status;
  }

  showAllergiesErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.allergiesErrorBlock.isAllergiesErr = true
      this.allergiesErrorBlock.allergiesErrMsg = "We couldn't load the appropriate information at this time."
      this.allergiesErrorBlock.allergiesErrTitle = title;
    } else if (status === 404) {
      this.allergiesErrorBlock.isAllergiesErr = true
      this.allergiesErrorBlock.allergiesErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.allergiesErrorBlock.allergiesErrTitle = title;
    } else if (status === 500) {
      this.allergiesErrorBlock.isAllergiesErr = true
      this.allergiesErrorBlock.allergiesErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh Allergies and try again."
      this.allergiesErrorBlock.allergiesErrTitle = "A server error occured.";
      this.allergiesErrorBlock.statusRetry = refreshStatus;
    } else {
      this.allergiesErrorBlock.isAllergiesErr = true
      this.allergiesErrorBlock.allergiesErrMsg = "We couldn't load the appropriate information at this time."
      this.allergiesErrorBlock.allergiesErrTitle = title;
    }
    this.allergiesErrorBlock.status = status;
  }

  showCompleteAllergiesErrorMsg(status: number, refreshStatus: boolean) {
    let title = 'We ran into some technical issues.'
    if (status === 400) {
      this.completeAllergiesErrorBlock.isCompleteAllergiesErr = true
      this.completeAllergiesErrorBlock.completeAllergiesErrMsg = "We couldn't load the appropriate information at this time."
      this.completeAllergiesErrorBlock.completeAllergiesErrTitle = title;
    } else if (status === 404) {
      this.completeAllergiesErrorBlock.isCompleteAllergiesErr = true
      this.completeAllergiesErrorBlock.completeAllergiesErrMsg = "The page or content you are trying to reach is doesn't exist."
      this.completeAllergiesErrorBlock.completeAllergiesErrTitle = title;
    } else if (status === 500) {
      this.completeAllergiesErrorBlock.isCompleteAllergiesErr = true
      this.completeAllergiesErrorBlock.completeAllergiesErrMsg = "We couldn’t connect with the server to retrieve the data. Refresh allergies and try again."
      this.completeAllergiesErrorBlock.completeAllergiesErrTitle = "A server error occured.";
      this.completeAllergiesErrorBlock.statusRetry = refreshStatus;
    } else {
      this.completeAllergiesErrorBlock.isCompleteAllergiesErr = true
      this.completeAllergiesErrorBlock.completeAllergiesErrMsg = "We couldn't load the appropriate information at this time."
      this.completeAllergiesErrorBlock.completeAllergiesErrTitle = title;
    }
    this.completeAllergiesErrorBlock.status = status;
  }




  onShowAllMedications(type: string) {
    this.showAll = type === "show" ? true : false;
    this.showAllType = type === "show" ? "medications" : null;
    this.activeTab = type === "show" ? "medications" : this.activeTab;
    if (this.showAll) {
      this.getCompleteMedicationsData();
    }
  }

  onShowAllContent(result) {
    this.showAll = result.showAll;
    this.viewAll = result.viewAll;
    this.showPN = result.showPN;
    this.individualProgressNotes = result.individualProgressNotes;
    this.showAllType = result.showAll ? result.type : null;
    this.activeTab = result.showAll ? result.type : this.activeTab;
    if (this.viewAll && this.showAll) {
      this.getCompletePNData();
    }

  }

  onShowAllVitals(type: string) {
    this.showAll = type === "show" ? true : false;
    this.showAllType = type === "show" ? "vitals" : null;
    this.activeTab = type === "show" ? "vitals" : this.activeTab;
    this.getCompleteVitalsData();
  }

  onShowAllConditions(type: string) {
    this.showAll = type === "show" ? true : false;
    this.showAllType = type === "show" ? "conditions" : null;
    this.activeTab = type === "show" ? "conditions" : this.activeTab;
    this.getCompleteConditionsData();
  }

  onShowAllAllergies(type: string) {
    this.showAll = type === "show" ? true : false;
    this.showAllType = type === "show" ? "allergies" : null;
    this.activeTab = type === "show" ? "allergies" : this.activeTab;
    this.getCompleteAllergiesData();
  }

  getCompleteMedicationsData(refreshStatus?: boolean) {
    this.isCompleteMedicationsDataLoading = true;
    // setTimeout(() => {
    this.patientSummaryService.completeMedicationsList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.completeMedicationsData = response;
        this.isCompleteMedicationsDataLoading = false;
        this.completeMedErrorBlock = {
          completeMedicationsErrTitle: '',
          completeMedicationsErrMsg: '',
          isCompleteMedicationsErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showCompleteMedicationsErrorMsg(error.status, refreshStatus);
        }
        this.isCompleteMedicationsDataLoading = false;
      }
    );
    //  }, 50000)
  }

  getCompletePNData(refreshStatus?: boolean) {
    this.isCompletePNDataLoading = true;
    // setTimeout(() => {
    this.patientSummaryService.completeProgressNotesList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.completePNData = response;
        this.isCompletePNDataLoading = false;
        this.completePNErrorBlock = {
          completePNErrTitle: '',
          completePNErrMsg: '',
          isCompletePNErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showCompletePNErrorMsg(error.status, refreshStatus);
        }
        this.isCompletePNDataLoading = false;
      }
    );
    //  }, 50000)
  }

  getCompleteVitalsData(refreshStatus?: boolean) {
    this.isCompleteVitalsDataLoading = true;
    // setTimeout(() => {
    this.patientSummaryService.completeVitalsList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.completeVitalsData = response;
        this.isCompleteVitalsDataLoading = false;
        this.completeVitalsErrorBlock = {
          completeVitalsErrTitle: '',
          completeVitalsErrMsg: '',
          isCompleteVitalsErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showCompleteVitalsErrorMsg(error.status, refreshStatus);
        }
        this.isCompleteVitalsDataLoading = false;
      }
    );
    //  }, 50000)
  }

  getCompleteConditionsData(refreshStatus?: boolean) {
    this.isCompleteConditionsDataLoading = true;
    // setTimeout(() => {
    this.patientSummaryService.completeConditionsList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.completeConditionsData = response;
        this.isCompleteConditionsDataLoading = false;
        this.completeConditionsErrorBlock = {
          completeConditionsErrTitle: '',
          completeConditionsErrMsg: '',
          isCompleteConditionsErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showCompleteConditionsErrorMsg(error.status, refreshStatus);
        }
        this.isCompleteConditionsDataLoading = false;
      }
    );
    //  }, 50000)
  }

  getCompleteAllergiesData(refreshStatus?: boolean) {
    this.isCompleteAllergiesDataLoading = true;
    // setTimeout(() => {
    this.patientSummaryService.completeAllergiesList(this.patient.HBSID, this.patient.docSearchDate).subscribe(
      (response: any) => {
        this.completeAllergiesData = response;
        this.isCompleteAllergiesDataLoading = false;
        this.completeAllergiesErrorBlock = {
          completeAllergiesErrTitle: '',
          completeAllergiesErrMsg: '',
          isCompleteAllergiesErr: false,
          status: -1,
          statusRetry: false
        }
      },
      error => {
        if (error.status) {
          this.showCompleteAllergiesErrorMsg(error.status, refreshStatus);
        }
        this.isCompleteAllergiesDataLoading = false;
      }
    );
    //  }, 50000)
  }

  onClickTab(tabName: string) {
    this.activeTab = tabName;
    switch (tabName) {
      case "additional-documents": {
        this.ClinicalContent = false;
        this.onClickShowDocs();
        break;
      }
      case "clinical-summary": {
        this.onShowAllMedications("hide");
        let pnOutput = { type: "progressNotes" }
        this.onShowAllContent(pnOutput);
        break;
      }
      case "medications": {
        this.onShowAllMedications("show");
        break;
      }
      case "progressNotes": {
        let pnOutput = { type: "progressNotes", showAll: true, viewAll: true }
        this.onShowAllContent(pnOutput);
        break;
      }
      case "vitals": {
        this.onShowAllVitals("show");
        break;
      }
      case "conditions": {
        this.onShowAllConditions("show");
        break;
      }
      case "allergies": {
        this.onShowAllAllergies("show");
        break;
      }
    }
  }

  documentsTableAutoRefresh() {
    this.automaticRetryCount = 6;
    this.patient = this.searchService.getInternalResourceToPatient();
    const internalResource = this.searchService.getInternalResource();
    let oldHBSID = this.patientDocService.getOldHBSID();
    const lookupOption = this.searchService.retrieveLookupOption();
    console.log("Current lookup option: ", lookupOption);
    // We have to update existing internalResource by calling service asynchronously
    if (internalResource) {
      const logic = this.automaticRetryInterval.pipe(
        take(this.automaticRetryCount),
        map(x => {
          this.autoPolling = true;
          // We have added one more iteration so that we can do any clean up work in last iteration
          if (x < this.automaticRetryCount - 1) {
            console.log("Current iteration: ", x);
            console.log('Current value of internalResource', internalResource)
            const hbsId = internalResource.id;
            console.log('HBS id for which documentsTableAutoRefresh() is called: ', hbsId);
            let transactionId = this.searchService.retrieveTransactionIdForPolling();
            this.searchService.searchInternalPatientWithTransactionId(hbsId, transactionId).subscribe(data => {
              if (data && data.response && data.response.statusCode === '0000' && this.continue) {
                console.log('Data fetched from automated quicklookup call: ', data);
                const resource = data.response.resources[0];
                this.searchService.setInternalResource(resource);
                if (data.response.resources && data.response.resources.length > 0) {
                  let list = data.response.resources[0].docRefs;
                  list = list.filter(doc => doc.contentType == "text/xml");
                  this.patientDocService.setDocList(list);
                  this.patientDocService.setPrescriber(data.response.resources[0].prescriber);
                }
                // update page as usual
                this.continue = false;
                this.allDocumentsLoaded = true;
                this.populateDocs();
                this.searchService.storeDemographicLookupOption('');
                this.searchService.storeTransactionIdForPolling('');
                // stop processing if status 0000
                this.automaticRetryCount = -1;
              }
              if (data && data.response && data.response.statusCode === '7701') {
                console.log('Data fetched from automated quicklookup call: ', data);
                console.log("Value of x withing 7701 status: ", x);
                const resource = data.response.resources[0];
                this.searchService.setInternalResource(resource);
                if (data.response.resources && data.response.resources.length > 0) {
                  let list = data.response.resources[0].docRefs;
                  list = list.filter(doc => doc.contentType == "text/xml");
                  this.patientDocService.setDocList(list);
                  this.patientDocService.setPrescriber(data.response.resources[0].prescriber);
                }
                // update page as usual
                this.continue = true;
                this.allDocumentsLoaded = false;
                this.populateDocs();
                // Max retry count exceeded but all documents are not downloaded
                if (x === 4) {
                  this.continue = false;
                  this.allDocumentsLoaded = true;
                  this.searchService.storeDemographicLookupOption('');
                  this.searchService.storeTransactionIdForPolling('');
                }
              }
            }, (error) => {
              // We are not updating the UI in case of any api call failure
              // since the data will be updated in next iteration
              if (error) {
                console.log("errorResponse", error);
              } else {
                console.log("Some error happeded during automated api call");
              }
            });
          } else {
            console.log('This is the last iteration. We can some cleanup work here.');
          }
        })
      );
      logic.subscribe();
    }
  }

  initializeStatusMap(documentList) {
    console.log("Document list: ", documentList);
    if (documentList) {
      documentList.forEach(entry => {
        //console.log("Current document entry: ", entry);
        if (this.statusTextMap.has(entry.id)) {
          console.log("Map has id: ", entry.id);
        } else {
          this.statusTextMap.set(entry.id, entry.viewStatus);
        }
      })
    }
    console.log("Current map size: ", this.statusTextMap.size);
  }

  refreshCurrentView() {
    if (this.isEligibleToShowSearch()) {
      this.isRefreshClicked = true;
      this.isDisplayPSVOneHrDelay = false;
    }
    else {
      this.refreshAdditionalDocumentsPage();
    }
  }

  refreshCurrentViewNo() {
    this.isRefreshClicked = false;
  }

  closeRefresh() {
    this.isDisplayPSVOneHrDelay = false;
  }

  refreshAdditionalDocumentsPage() {
    this.allDocumentsLoaded = false;
    this.autoPolling = false;
    this.searchService.setSourcePage("internalDocs");
    this.searchService.storeLookupOption('refresh');
    let internalResource = this.searchService.getInternalResource();
    console.log("Refresh page link clicked. refreshAdditionalDocumentsPage() function executing.");
    console.log("Current internalResource: ", internalResource);
    this.searchService.searchPatientByDemoRefresh(internalResource).subscribe(data => { this.handleDemographicSearchRefreshResponse(data) }, (error) => {
      if (error.response) {
        this.handleRefreshError(error.response, error.response.statusCode, error.status);
      }
      else {
        this.handleRefreshError(null, null, null);
      }
    });
  }

  handleDemographicSearchRefreshResponse(body) {
    if (body && body.response) {
      if (body.response.statusCode === '0000') {
        console.log("response", body.response);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        if (this.isEligibleToShowSearch()) {
          this.isRefreshClicked = false;
          this.isDisplayPSVOneHrDelay = true;
        }
        if (body.response.resources && body.response.resources.length > 0) {
          let list = body.response.resources[0].docRefs;
          list = list.filter(doc => doc.contentType == "text/xml");
          this.patientDocService.setDocList(list);
          this.patientDocService.setPrescriber(body.response.resources[0].prescriber);
          this.router.navigate([allPaths.internalPatientDocuments.link]);
        } else {
          this.result.display = true;
          this.result.banner = errorBanners.lookupPatient[7004];
        }
      } else if (body.response.statusCode === '7028') {
        console.log("response", body.response);
        let hbsId = body.response.resources[0].id;
        let transactionId = body.response.resources[0].transId;
        // Initial delay before first quick lookup call
        this.sleep(this.initialDelayAfterQueueingPatient);
        // Save transactionId in the context for background polling
        this.searchService.storeTransactionIdForPolling(transactionId);
        this.searchService.searchInternalPatientFromDemographicLookup(hbsId, transactionId).subscribe(data => { this.handleHbsIdSearchResponse(data) }, (error) => {
          if (error.response) {
            this.handleRefreshError(error.response, error.response.statusCode, error.status);
            console.log("errorResponse", error.response);
          }
          else {
            this.handleRefreshError(null, null, null);
          }
        });
      }
      else {
        console.log("Api response: ", body.response);
        this.handleRefreshError(body.response, body.response.statusCode, null);
      }
    }
    else {
      let body = {
        statusCode: "Unknown",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleRefreshError(body, body.statusCode, null);
    }
  }

  handleHbsIdSearchResponse(body) {
    if (body && body.response) {
      if (body.response.statusCode === '0000' || body.response.statusCode === '7701') {
        console.log("response", body.response);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        // if(this.isEligibleToShowSearch()) {
        //   this.isRefreshClicked = false;
        //   this.isDisplayPSVOneHrDelay = true;
        // }
        if (body.response.resources && body.response.resources.length > 0) {
          let list = body.response.resources[0].docRefs;
          list = list.filter(doc => doc.contentType == "text/xml");
          this.patientDocService.setDocList(list);
          this.patientDocService.setPrescriber(body.response.resources[0].prescriber);
          this.populateDocs();

          // Start second polling only
          this.pollingAfterRefresh = true;
          setTimeout(() => { this.pollingOnRefresh(this.pollingAfterRefresh) }, 5000);
          if (this.isEligibleToShowSearch()) {
            this.isRefreshClicked = false;
            this.isDisplayPSVOneHrDelay = true;
            if (this.patient.HBSID) this.getMedicationsData();
            if (this.patient.HBSID) this.getProgressNotesData();
            if (this.patient.HBSID) this.getVitalsData();
            if (this.patient.HBSID) this.getConditionsData();
            if (this.patient.HBSID) this.getAllergiesData();
          }
        }
      } else if (body.response.statusCode === '7003' || body.response.statusCode === '7700' || body.response.statusCode === '7000') {
        this.searchService.storeDemographicLookupOption(''); // Disable background auto polling
        this.searchService.setShowfeedbackQuestion(false);
        this.spinnerService.hide();
        if (this.isEligibleToShowSearch() && (body.response.statusCode !== '7000' && body.response.statusCode !== '7003')) {
          this.isRefreshClicked = false;
          this.isDisplayPSVOneHrDelay = true;
        } else {
          this.isRefreshClicked = false;
          this.isDisplayPSVOneHrDelay = false;
        }
        this.refresh = true;
        // Making docList to empty array to remove the table
        this.docList = [];
        this.patientDocService.setDocList(this.docList);
        this.filteredDocuments = [];
        this.router.navigate([allPaths.internalPatientDocuments.link]);
        this.result.display = true;
        this.result.banner = errorBanners.internalPatientSearch[7777];
      }
      else {
        this.handleRefreshError(body.response, body.response.statusCode, null);
      }
    }
    else {
      let body = {
        statusCode: "Unknown",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleRefreshError(body, body.statusCode, null);
    }
  }

  handleRefreshError(response, statusCode, httpStatusCode) {
    this.resetErrorBanner();
    this.spinnerService.hide();
    this.result.display = true;
    if (response) {
      console.log("Error response", response);
      this.result.banner = JSON.parse(JSON.stringify(errorBanners.internalPatientSearch[response.statusCode]));
    } else {
      this.result.banner = JSON.parse(JSON.stringify(errorBanners.internalPatientSearch[1111]));
    }
    if (!this.result.banner) {
      let code = statusCode ? statusCode : 'default';
      this.result.banner = errorBanners.internalPatientSearch[code];
    }
    if (statusCode) {
      if (this.result.banner && this.result.banner.displayResponseStatus) {
        this.result.banner.info = '';
        if (httpStatusCode) {
          this.result.banner.info = httpStatusCode + ' - ';
        }
        this.result.banner.info += `${statusCode} - ${response?.statusDesc}`;
      } else if (this.result.banner && this.result.banner.displayResponseStatusQueueingError) {
        const message = this.result.banner.info;
        this.result.banner.info = '';
        if (httpStatusCode) {
          this.result.banner.info = httpStatusCode + ' - ';
        }
        this.result.banner.info += `${statusCode}` + " - " + message;
      }
      else {
        this.handleDisplayError(statusCode);
      }
    }
  }

  handleDisplayError(statusCode) {
    if (this.searchService.retrieveLookupOption() === 'refresh') {
      this.result.displayDemosError = true;
    }
  }

  pollingOnRefresh(pollingAfterRefresh) {
    console.log("pollingAfterRefresh flag: ", pollingAfterRefresh);
    if (pollingAfterRefresh && this.docList.length > 0) {
      console.log("refresh flag true, starting background polling");
      this.allDocumentsLoaded = false;
      this.autoPolling = true;
      this.continue = true;
      this.documentsTableAutoRefresh();
      this.pollingAfterRefresh = false;
      console.log("pollingAfterRefresh flag false, background polling for refresh link ends.");
    } else {
      console.log("pollingAfterRefresh flag false, no background polling");
    }
  }

  callAdvancedSearch() {
    console.log("Going to Advanced Search");
    this.searchService.setSourcePage('lookupPatientPage');
    this.router.navigate([allPaths.advancedSearch.link]);
    this.close();
  }

  sleep(milliseconds) {
    console.log("Delay start");
    var start = new Date().getTime();
    var end = start;
    while (end < start + milliseconds) {
      end = new Date().getTime();
    }
    console.log("Delay end");
  }

}

