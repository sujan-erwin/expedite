import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { IPatientSummary } from 'src/app/patient-summary/store/patient-summary.interface';
import { PatientSummaryService } from 'src/app/patient-summary/store/patient-summary.service';
import { errorBlockCompleteConditions, errorBlockConditions } from '../../internal-patient-documents.component';


export interface errorBlockStatusCode {
  conditionsErrTitle: string;
  conditionsErrMsg: string;
  isConditionsErr: boolean;
}

export enum OpenDocumentStatus {
  OPEN_DOCUMENT = 'open document',
  LOADING = 'loading',
  DOCUMENT_VIEWED = 'viewed',
  REPORT_ISSUE = 'report issue',
  RETRY = 'retry',
  SYSTEM_ERROR = 'system error'
}

@Component({
  selector: 'app-conditions',
  templateUrl: './conditions.component.html',
  styleUrls: ['./conditions.component.scss']
})
export class ConditionsComponent implements OnInit {
  @Output() showAllConditions: EventEmitter<any> = new EventEmitter();
  @Output() showAdditionalDocs: EventEmitter<any> = new EventEmitter();
  @Output() refreshConditions: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() refreshCompleteConditions: EventEmitter<boolean> = new EventEmitter<boolean>();

  ipatientSummary: IPatientSummary;
  ipatientSummaryObserv: Observable<IPatientSummary>;
  conditionsToRender = [];
  completeConditionsToRender: [];
  errorBlockStatusCode: errorBlockStatusCode;
  statusTextMap = new Map<string, string>();
  noPatientRecords: boolean = false;
  noPatientRecordsOnViewAll: boolean = false;
  public openDocumentStatus = OpenDocumentStatus;
  refreshCompleteConditionsFlag: boolean = false;
  isReadMore = true;
  eventFromSortDirective: any;

  public conditionsHdrs: any = {
    dateReported: { id: 'date-reported', title: 'Date' },
    icd10: { id: 'ICD-10', title: 'ICD-10' },
    description: { id: 'description', title: 'Description' },
    institution: { id: 'institution', title: 'Institution' }
  };

  @Input() isLoading: boolean = false;
  @Input() isViewAllLoading: boolean = false;
  @Input() showConditions: boolean = false;
  @Input() showAll: boolean = false;
  @Input() conditionsErrorBlock: errorBlockConditions;
  @Input() completeConditionsErrorBlock: errorBlockCompleteConditions;

  @Input() set conditionsData(conditions: any) {
    this.constructConditionsData(conditions);
  };

  @Input() set completeConditionsData(conditions: any) {
    this.constructCompleteConditionsData(conditions);
  };

  constructor(private patientSummaryService: PatientSummaryService) {
    this.conditionsToRender = [];
    this.completeConditionsToRender = [];
    this.statusTextMap = new Map<string, string>();
  }

  ngOnInit(): void {
    this.constructConditionsData(this.conditionsData);
  }

  showText(conditions) {
    conditions.isReadMore = !conditions.isReadMore;
  }

  constructConditionsData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecords = false;
      const resources = body.response.resource.icdCodes;
      this.conditionsToRender = resources.map((conditions) => {
        conditions['isReadMore'] = true;
        return conditions;
      });
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecords = true;
    }
  }

  constructCompleteConditionsData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecordsOnViewAll = false;
      const resources = body.response.resources;
      this.completeConditionsToRender = resources.map((conditions, index) => {
        conditions['id'] = index + 1;
        conditions['isReadMore'] = true;
        this.statusTextMap.set(conditions.id, OpenDocumentStatus.OPEN_DOCUMENT);
        return conditions;
      });
      this.completeConditionsToRender = resources;
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecordsOnViewAll = true;
    }
  }

  onClickViewAllConditions() {
    this.showAll = true;
    this.showAllConditions.emit("show");
    this.constructCompleteConditionsData(this.completeConditionsData);
  }

  onClickviewFullConditions(document) {
    document.viewStatus = OpenDocumentStatus.LOADING;
    this.statusTextMap.set(document.id, document.viewStatus);
    this.patientSummaryService.getProgressNoteFullDocument(document.documentRef).subscribe((res: any) => {
      if (res && res.response && res.response.statusCode === "0000") {
        document.viewStatus = OpenDocumentStatus.DOCUMENT_VIEWED;
        this.statusTextMap.set(document.id, document.viewStatus);
        var htmlContent = window.atob(res.response.resources[0].content);
        const length = htmlContent.length;
        const newWindow = window.open(res.response.resources[0].id + '.html');
        newWindow.document.title = res.response.resources[0].description;
        newWindow.document.write(htmlContent);
      } else if (res && res.response && res.response.statusCode === "7003") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.REPORT_ISSUE);
      } else if (res && res.response && res.response.statusCode === "7017") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
      }
    }, error => {
      // document.viewStatus = "error";
      this.handleError(document);
    });
  }

  handleError(document) {
    // update view status
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
      this.statusTextMap.set(document.id, OpenDocumentStatus.RETRY);
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 1) {
      // update view status
      this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
    }
  }

  onClickShowaddDocs() {
    this.showAdditionalDocs.emit(true);
  }
  onClickRefreshConditions() {
    this.refreshConditions.emit(true);
  }
  onClickRefreshCompleteConditions() {
    this.refreshCompleteConditions.emit(true);
  }
  sortEvent(event: any) {
    this.eventFromSortDirective = event;
    // console.log('sortEvent:', event);
  }
}
