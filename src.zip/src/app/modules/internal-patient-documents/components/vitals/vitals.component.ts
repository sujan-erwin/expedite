import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { IPatientSummary } from 'src/app/patient-summary/store/patient-summary.interface';
import { PatientSummaryService } from 'src/app/patient-summary/store/patient-summary.service';
import { errorBlockCompleteVitals, errorBlockVitals } from '../../internal-patient-documents.component';

export interface errorBlockStatusCode {
  vitalsErrTitle: string;
  vitalsErrMsg: string;
  isVitalsErr: boolean;
}

export enum OpenDocumentStatus {
  OPEN_DOCUMENT = 'open document',
  LOADING = 'loading',
  DOCUMENT_VIEWED = 'viewed',
  REPORT_ISSUE = 'report issue',
  RETRY = 'retry',
  SYSTEM_ERROR = 'system error'
}

@Component({
  selector: 'app-vitals',
  templateUrl: './vitals.component.html',
  styleUrls: ['./vitals.component.scss']
})
export class VitalsComponent implements OnInit {
  @Output() showAllVitals: EventEmitter<any> = new EventEmitter();
  @Output() showAdditionalDocs: EventEmitter<any> = new EventEmitter();
  @Output() refreshVitals: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() refreshCompleteVitals: EventEmitter<boolean> = new EventEmitter<boolean>();

  ipatientSummary: IPatientSummary;
  ipatientSummaryObserv: Observable<IPatientSummary>;
  vitalsToRender: any;
  completeVitalsToRender = [];
  errorBlockStatusCode: errorBlockStatusCode;
  statusTextMap = new Map<string, string>();
  noPatientRecords: boolean = false;
  noPatientRecordsOnViewAll: boolean = false;
  public openDocumentStatus = OpenDocumentStatus;
  refreshCompleteVitalsFlag: boolean = false;
  eventFromSortDirective: any;

  public vitalsHdrs: any = {
    dateReported: { id: 'date', title: 'Date' },
    vitInstitution: { id: 'institution', title: 'Institution' },
    weight: { id: 'weight', title: 'Weight' },
    height: { id: 'height', title: 'Height' },
    bsa: { id: 'bsa', title: 'BSA' },
  };

  @Input() isLoading: boolean = false;
  @Input() isViewAllLoading: boolean = false;
  @Input() showVitals: boolean = false;
  @Input() showAll: boolean = false;
  @Input() vitalsErrorBlock: errorBlockVitals;
  @Input() completeVitalsErrorBlock: errorBlockCompleteVitals;
  @Input() set vitalsData(vitals: any) {
    this.constructVitalsData(vitals);
  };

  @Input() set completeVitalsData(vitals: any) {
    this.constructCompleteVitalsData(vitals);
  };

  constructor(private patientSummaryService: PatientSummaryService) {
    this.vitalsToRender = '';
    this.completeVitalsToRender = [];
    this.statusTextMap = new Map<string, string>();
  }

  ngOnInit(): void {
    this.constructVitalsData(this.vitalsData);
  }

  constructVitalsData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecords = false;
      const resources = body.response.resource;
      this.vitalsToRender = resources;
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecords = true;
      this.vitalsToRender = body.response.resource;
    }
  }

  constructCompleteVitalsData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecordsOnViewAll = false;
      const resources = body.response.resources;
      this.completeVitalsToRender = resources.map((vitals, index) => {
        vitals['id'] = index + 1;
        vitals['isReadMore'] = true;
        this.statusTextMap.set(vitals.id, OpenDocumentStatus.OPEN_DOCUMENT);
        return vitals;
      });
      this.completeVitalsToRender = resources;
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecordsOnViewAll = true;
    }
  }

  onClickViewAllVitals() {
    this.showAll = true;
    this.showAllVitals.emit("show");
    this.constructCompleteVitalsData(this.completeVitalsData);
  }

  onClickviewFullVitals(document) {
    document.viewStatus = OpenDocumentStatus.LOADING;
    this.statusTextMap.set(document.id, document.viewStatus);
    this.patientSummaryService.getProgressNoteFullDocument(document.documentRef).subscribe((res: any) => {
      if (res && res.response && res.response.statusCode === "0000") {
        document.viewStatus = OpenDocumentStatus.DOCUMENT_VIEWED;
        this.statusTextMap.set(document.id, document.viewStatus);
        var htmlContent = window.atob(res.response.resources[0].content);
        const length = htmlContent.length;
        const newWindow = window.open(res.response.resources[0].id + '.html');
        newWindow.document.title = res.response.resources[0].description;
        newWindow.document.write(htmlContent);
      } else if (res && res.response && res.response.statusCode === "7003") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.REPORT_ISSUE);
      } else if (res && res.response && res.response.statusCode === "7017") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
      }
    }, error => {
      // document.viewStatus = "error";
      this.handleError(document);
    });
  }

  handleError(document) {
    // update view status
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
      this.statusTextMap.set(document.id, OpenDocumentStatus.RETRY);
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 1) {
      // update view status
      this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
    }
  }

  onClickShowaddDocs() {
    this.showAdditionalDocs.emit(true);
  }
  onClickRefreshVitals() {
    this.refreshVitals.emit(true);
  }
  onClickRefreshCompleteVitals() {
    this.refreshCompleteVitals.emit(true);
  }
  sortEvent(event: any) {
    this.eventFromSortDirective = event;
    // console.log('sortEvent:', event);
  }

}
