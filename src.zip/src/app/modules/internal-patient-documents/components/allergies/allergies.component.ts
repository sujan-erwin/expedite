
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { IPatientSummary } from 'src/app/patient-summary/store/patient-summary.interface';
import { PatientSummaryService } from 'src/app/patient-summary/store/patient-summary.service';
import { errorBlockAllergies, errorBlockCompleteAllergies } from '../../internal-patient-documents.component';


export interface errorBlockStatusCode {
  allergiesErrTitle: string;
  allergiesErrMsg: string;
  isAllergiesErr: boolean;
}

export enum OpenDocumentStatus {
  OPEN_DOCUMENT = 'open document',
  LOADING = 'loading',
  DOCUMENT_VIEWED = 'viewed',
  REPORT_ISSUE = 'report issue',
  RETRY = 'retry',
  SYSTEM_ERROR = 'system error'
}

@Component({
  selector: 'app-allergies',
  templateUrl: './allergies.component.html',
  styleUrls: ['./allergies.component.scss']
})
export class AllergiesComponent implements OnInit {
  @Output() showAllAllergies: EventEmitter<any> = new EventEmitter();
  @Output() showAdditionalDocs: EventEmitter<any> = new EventEmitter();
  @Output() refreshAllergies: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() refreshCompleteAllergies: EventEmitter<boolean> = new EventEmitter<boolean>();

  ipatientSummary: IPatientSummary;
  ipatientSummaryObserv: Observable<IPatientSummary>;
  allergiesToRender = [];
  allergiesSliced = [];
  completeAllergiesToRender: [];
  errorBlockStatusCode: errorBlockStatusCode;
  statusTextMap = new Map<string, string>();
  noPatientRecords: boolean = false;
  noPatientRecordsOnViewAll: boolean = false;
  public openDocumentStatus = OpenDocumentStatus;
  refreshCompleteAllergiesFlag: boolean = false;
  isReadMore = false;
  isShowAll = false;
  eventFromSortDirective: any;

  public allergiesHdrs: any = {
    date: { id: 'date-reported', title: 'Date' },
    institution: { id: 'institution-allergies', title: 'Institution' },
    allergen: { id: 'allergen', title: 'Allergen' },
    reaction: { id: 'reaction-type', title: 'Reaction Type' },
    severity: { id: 'severity', title: 'Severity' }
  };

  @Input() isLoading: boolean = false;
  @Input() isViewAllLoading: boolean = false;
  @Input() showAllergies: boolean = false;
  @Input() showAll: boolean = false;
  @Input() allergiesErrorBlock: errorBlockAllergies;
  @Input() completeAllergiesErrorBlock: errorBlockCompleteAllergies;

  @Input() set allergiesData(allergies: any) {
    this.constructAllergiesData(allergies);
  };

  @Input() set completeAllergiesData(allergies: any) {
    this.constructCompleteAllergiesData(allergies);
  };

  constructor(
    private patientSummaryService: PatientSummaryService
  ) {
    this.allergiesToRender = [];
    this.completeAllergiesToRender = [];
    this.statusTextMap = new Map<string, string>();
  }

  ngOnInit(): void {
    this.constructAllergiesData(this.allergiesData);
  }

  showText(allergies) {
    allergies.isReadMore = !allergies.isReadMore;
  }

  constructAllergiesData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecords = false;
      const resources = body.response.resources;
      this.allergiesToRender = resources;
      this.allergiesSliced = this.allergiesToRender;
      this.allergiesSliced = resources.map((allergies) => {
        allergies['isReadMore'] = true;
        return allergies;
      });

      if (!this.isShowAll) {
        this.allergiesSliced = this.allergiesToRender.slice(0, 6);
      }
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecords = true;
    }
  }

  showItems() {
    this.isShowAll = !this.isShowAll;
    if (this.isShowAll) {
      this.allergiesSliced = this.allergiesToRender;
    } else {
      this.allergiesSliced = this.allergiesToRender.slice(0, 6);
    }
  }

  constructCompleteAllergiesData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecordsOnViewAll = false;
      const resources = body.response.resources;
      this.completeAllergiesToRender = resources.map((allergies, index) => {
        allergies['id'] = index + 1;
        allergies['isReadMore'] = true;
        this.statusTextMap.set(allergies.id, OpenDocumentStatus.OPEN_DOCUMENT);
        return allergies;
      });
      this.completeAllergiesToRender = resources;
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecordsOnViewAll = true;
    }
  }

  onClickViewAllAllergies() {
    this.showAll = true;
    this.showAllAllergies.emit("show");
    this.constructCompleteAllergiesData(this.completeAllergiesData);
  }

  onClickviewFullAllergies(document) {
    document.viewStatus = OpenDocumentStatus.LOADING;
    this.statusTextMap.set(document.id, document.viewStatus);
    this.patientSummaryService.getProgressNoteFullDocument(document.documentRef).subscribe((res: any) => {
      if (res && res.response && res.response.statusCode === "0000") {
        document.viewStatus = OpenDocumentStatus.DOCUMENT_VIEWED;
        this.statusTextMap.set(document.id, document.viewStatus);
        var htmlContent = window.atob(res.response.resources[0].content);
        const length = htmlContent.length;
        const newWindow = window.open(res.response.resources[0].id + '.html');
        newWindow.document.title = res.response.resources[0].description;
        newWindow.document.write(htmlContent);
      } else if (res && res.response && res.response.statusCode === "7003") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.REPORT_ISSUE);
      } else if (res && res.response && res.response.statusCode === "7017") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
      }
    }, error => {
      // document.viewStatus = "error";
      this.handleError(document);
    });
  }

  handleError(document) {
    // update view status
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
      this.statusTextMap.set(document.id, OpenDocumentStatus.RETRY);
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 1) {
      // update view status
      this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
    }
  }

  onClickShowaddDocs() {
    this.showAdditionalDocs.emit(true);
  }
  onClickRefreshAllergies() {
    this.refreshAllergies.emit(true);
  }
  onClickRefreshCompleteAllergies() {
    this.refreshCompleteAllergies.emit(true);
  }
  sortEvent(event: any) {
    this.eventFromSortDirective = event;
    // console.log('sortEvent:', event);
  }
}
