import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";

import { PrintConfig } from 'src/app/util/print-config';
import { IPatientSummary } from 'src/app/patient-summary/store/patient-summary.interface';
import { errorBlock, errorBlockCompleteMed } from '../../internal-patient-documents.component';
import { PatientSummaryService } from 'src/app/patient-summary/store/patient-summary.service';


export enum OpenDocumentStatus {
  OPEN_DOCUMENT = 'open document',
  LOADING = 'loading',
  DOCUMENT_VIEWED = 'viewed',
  REPORT_ISSUE = 'report issue',
  RETRY = 'retry',
  SYSTEM_ERROR = 'system error'
}

@Component({
  selector: 'app-medications',
  templateUrl: './medications.component.html',
  styleUrls: ['./medications.component.scss'],
})
export class MedicationsComponent implements OnInit {

  @Output() showAllMedications: EventEmitter<any> = new EventEmitter();
  @Output() showAdditionalDocs: EventEmitter<any> = new EventEmitter();
  @Output() refreshMedications: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() refreshCompleteMedications: EventEmitter<boolean> = new EventEmitter<boolean>();

  ipatientSummary: IPatientSummary;
  ipatientSummaryObserv: Observable<IPatientSummary>;
  medicationsToRender = [];
  completeMedicationsToRender = [];
  medicationsSliced: any;
  public openDocumentStatus = OpenDocumentStatus;
  statusTextMap = new Map<string, string>();
  noPatientRecords: boolean = false;
  noPatientRecordsOnViewAll: boolean = false;
  eventFromSortDirective: any;
  notAvailable: string = 'Not available';

  public medHdrs: any = {
    medName: { id: 'medication-name', title: 'Medications' },
    medStartDate: { id: 'start-date', title: 'Start Date' },
    medEndDate: { id: 'end-date', title: 'End Date' },
    prescriber: { id: 'prescriber-name', title: 'Prescriber' },
    instructions: { id: 'instructions', title: 'Instructions' },
    status: { id: 'status', title: 'Status' }
  };

  @Input() isLoading: boolean = false;
  @Input() isViewAllLoading: boolean = false;
  @Input() showAll: boolean;
  @Input() medicationsErrorBlock: errorBlock;
  @Input() completeMedicationsErrorBlock: errorBlockCompleteMed;
  @Input() set medicationsData(medications: any) {
    //this._medicationsData = medications;
    this.constructMedicationsData(medications);
  };
  @Input() set completeMedicationsData(medications: any) {
    this.constructCompleteMedicationsData(medications);
  };
  @Input() patientInfo: any;

  constructor(
    private patientSummaryService: PatientSummaryService,
    private datePipe: DatePipe) {
    this.medicationsToRender = [];
    this.completeMedicationsToRender = [];
    this.statusTextMap = new Map<string, string>();
  }

  ngOnInit(): void {
    this.constructMedicationsData(this.medicationsData);
    //custom styles on print
    pdfMake.vfs = pdfFonts.pdfMake.vfs;

  }

  constructMedicationsData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecords = false;
      const resources = body.response.resources;
      this.medicationsToRender = resources;
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecords = true;
    }
  }

  constructCompleteMedicationsData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecordsOnViewAll = false;
      const resources = body.response.resources;
      this.completeMedicationsToRender = resources.map((medication, index) => {
        medication['id'] = index + 1;
        this.statusTextMap.set(medication.id, OpenDocumentStatus.OPEN_DOCUMENT);
        return (medication);
      });
      this.completeMedicationsToRender = resources;
    } else if (body?.response?.statusCode === '7000') {
      this.noPatientRecordsOnViewAll = true;
    }

  }

  onClickviewFullMedicationDoc(document) {
    document.viewStatus = OpenDocumentStatus.LOADING;
    this.statusTextMap.set(document.id, document.viewStatus);
    this.patientSummaryService.getProgressNoteFullDocument(document.documentRef).subscribe((res: any) => {
      if (res && res.response && res.response.statusCode === "0000") {
        document.viewStatus = OpenDocumentStatus.DOCUMENT_VIEWED;
        this.statusTextMap.set(document.id, document.viewStatus);
        var htmlContent = window.atob(res.response.resources[0].content);
        const length = htmlContent.length;
        const newWindow = window.open(res.response.resources[0].id + '.html');
        newWindow.document.title = res.response.resources[0].description;
        newWindow.document.write(htmlContent);
      } else if (res && res.response && res.response.statusCode === "7003") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.REPORT_ISSUE);
      } else if (res && res.response && res.response.statusCode === "7017") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
      }
    }, error => {
      this.handleError(document);
    });
  }

  handleError(document) {
    // update view status
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
      this.statusTextMap.set(document.id, OpenDocumentStatus.RETRY);
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 1) {
      // update view status
      this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
    }
  }

  onClickViewAllMedications() {
    this.constructCompleteMedicationsData(this.completeMedicationsData);
    this.showAllMedications.emit("show");
    setTimeout(() => {
      this.showAll = true;
    }, 500);
  }
  onClickShowaddDocs() {
    this.showAdditionalDocs.emit(true);
  }
  onClickRefreshMedications() {
    this.refreshMedications.emit(true);
  }
  onClickRefreshCompleteMedications() {
    this.refreshCompleteMedications.emit(true);
  }
  sortEvent(event: any) {
    this.eventFromSortDirective = event;
    // console.log('sortEvent:', event);
  }
  printDocument() {
    let docDefinition = {
      pageSize: PrintConfig.PAGE_SIZE,
      pageMargins: PrintConfig.PAGE_MARGINS,
      info: {
        title: 'Medications',
      },
      content: [
        {
          columns: [
            [
              {
                text: PrintConfig.CURRENT_DATE,
                fontSize: 10,
                margin: [0, 2, 0, 20],
              }
            ],
            [
              {
                text: `${PrintConfig.PATIENT_TITLE}: ${this.patientInfo?.lastName} ${this.patientInfo?.firstName}`,
                alignment: 'right',
                fontSize: 10,
                margin: [0, 0, 0, 20],
              }
            ]
          ]
        },
        {
          image: PrintConfig.CVS_LOGO_IMG,
          width: 150,
          margin: [-15, 0, 0, 30],
        },
        {
          columns: [
            [
              {
                text: PrintConfig.MEDICATION_VIEW,
                fontSize: 14,
                bold: true,
                margin: [0, 0, 0, 20],
              }
            ],
            [
              {
                text: `${PrintConfig.TOTAL_RECORDS}: ${this.completeMedicationsToRender.length}`,
                alignment: 'right',
                fontSize: 10,
                margin: [0, 0, 0, 20],

              }
            ]
          ]
        },
        {
          layout: 'lightHorizontalLines',
          table: {
            headerRows: 1,
            dontBreakRows: true,
            widths: ['24%', '18%', '18%', '19%', '21%'],
            body: [
              [{ text: 'Medications', style: 'tableHeader' }, { text: 'Start Date', style: 'tableHeader' },
              { text: 'End Date', style: 'tableHeader' }, { text: 'Prescriber', style: 'tableHeader' },
              { text: 'Instructions', style: 'tableHeader' }],
              ...this.completeMedicationsToRender.map(p => ([{ text: p.medicationName ? p.medicationName : this.notAvailable, style: 'medicationName' },
              { text: p.medicationStartDate ? this.datePipe.transform(p.medicationStartDate, 'MM/dd/yyyy') : this.notAvailable, style: 'dataCell' },
              { text: p.medicationEndDate ? this.datePipe.transform(p.medicationEndDate, 'MM/dd/yyyy') : this.notAvailable, style: 'dataCell' },
              { text: p.prescriber && (p.prescriber.firstName || p.prescriber.lastName) ? `${p.prescriber.firstName} ${p.prescriber.lastName}` : this.notAvailable, style: 'dataCell' },
              { text: p.instruction ? p.instruction.toLowerCase() : this.notAvailable, style: 'dataCell' }])),
            ]
          },
        }
      ],
      styles: {
        tableHeader: {
          color: '#000000',
          fontSize: 10,
          bold: true,
          margin: [0, 0, 0, 10],
        },
        medicationName: {
          fontSize: 10,
          bold: true,
          margin: [0, 10, 0, 10],
        },
        dataCell: {
          color: '#000000',
          fontSize: 10,
          margin: [0, 10, 0, 10],
        }
      }
    };
    pdfMake.createPdf(docDefinition).open();
  }
}
