
import { Component, EventEmitter, OnInit, Output, Input, SimpleChanges, OnChanges } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { DatePipe } from '@angular/common';

import { PrintConfig } from 'src/app/util/print-config';
import { IPatientSummary } from 'src/app/patient-summary/store/patient-summary.interface';
import { errorBlockCompletePN, errorBlockPN } from '../../internal-patient-documents.component';
import { PatientSummaryService } from 'src/app/patient-summary/store/patient-summary.service';


export enum OpenDocumentStatus {
  OPEN_DOCUMENT = 'open document',
  LOADING = 'loading',
  DOCUMENT_VIEWED = 'viewed',
  REPORT_ISSUE = 'report issue',
  RETRY = 'retry',
  SYSTEM_ERROR = 'system error'
}

@Component({
  selector: 'app-progress-notes',
  templateUrl: './progress-notes.component.html',
  styleUrls: ['./progress-notes.component.scss']
})
export class ProgressNotesComponent implements OnInit, OnChanges {

  @Output() showAllContent: EventEmitter<any> = new EventEmitter();
  @Output() showAdditionalDocs: EventEmitter<any> = new EventEmitter();
  @Output() refreshProgressNotes: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() refreshCompletePN: EventEmitter<boolean> = new EventEmitter<boolean>();

  ipatientSummary: IPatientSummary;
  ipatientSummaryObserv: Observable<IPatientSummary>;
  progressNotesToRender = [];
  completePNToRender = [];
  textVal: any;
  viewStatus: any;
  public openDocumentStatus = OpenDocumentStatus;
  statusTextMap = new Map<string, string>();
  isReadMore = true;
  noPatientRecords: boolean = false;
  noPatientRecordsOnViewAll: boolean = false;
  previousElementId: string;
  notAvailable: string = 'Not available';

  @Input() isLoading: boolean = false;
  @Input() isViewAllLoading: boolean = false;
  @Input() individualProgressNotes: any;
  @Input() showPN: boolean = false;
  @Input() viewAll: boolean;
  @Input() pnErrorBlock: errorBlockPN;
  @Input() completePNErrorBlock: errorBlockCompletePN;
  @Input() patientInfo: any;
  @Input() set progressNotesData(progress: any) {
    this.constructProgressNotesData(progress);
  };

  @Input() set completePNData(progressNote: any) {
    this.constructCompleteProgressNotesData(progressNote);
  };

  constructor(
    private patientSummaryService: PatientSummaryService,
    private datePipe: DatePipe
  ) {
    this.progressNotesToRender = [];
    this.completePNToRender = [];
    this.statusTextMap = new Map<string, string>();
  }

  ngOnInit(): void {
    this.constructProgressNotesData(this.progressNotesData);
    //custom styles on print
    pdfMake.vfs = pdfFonts.pdfMake.vfs;
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.individualProgressNotes && this.individualProgressNotes) {
      this.statusTextMap.set(this.individualProgressNotes.id, OpenDocumentStatus.OPEN_DOCUMENT);
    }
  }
  showText(progressNote) {
    progressNote.isReadMore = !progressNote.isReadMore;
  }

  constructProgressNotesData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecords = false;
      const resources = body.response.resources;
      this.progressNotesToRender = resources.map((progressNote, index) => {
        progressNote['id'] = index + 1;
        progressNote['isReadMore'] = true;
        return progressNote;
      });
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecords = true;
    }
  }

  constructCompleteProgressNotesData(body) {
    if (!body && !body?.response) return;
    if (body?.response?.statusCode === '0000') {
      this.noPatientRecordsOnViewAll = false;

      const resources = body.response.resources;
      this.completePNToRender = resources.map((progressNote, index) => {
        progressNote['id'] = index + 1;
        progressNote['isReadMore'] = true;
        this.statusTextMap.set(progressNote.id, OpenDocumentStatus.OPEN_DOCUMENT);
        return progressNote;
      });
    }
    else if (body?.response?.statusCode === '7000') {
      this.noPatientRecordsOnViewAll = true;
    }
    this.scrollToView();
  }

  scrollToView() {
    setTimeout(() => {
      if (this.previousElementId) {
        const element = document.getElementById(this.previousElementId);
        element.scrollIntoView({ behavior: 'smooth', block: "start" });
      }
    }, 10)
  }

  onClickViewAllProgressNotes() {
    this.viewAll = true;
    let output = { type: "progressNotes", showAll: true, viewAll: true }
    this.showAllContent.emit(output);
  }
  onClickViewIndividualProgressNotes(progressNotes, id: string) {
    let output = { type: "progressNotes", showAll: true, viewAll: false, showPN: true, individualProgressNotes: progressNotes }
    this.previousElementId = id;
    this.showAllContent.emit(output);
  }

  onViewProgressNotes() {

  }
  onClickviewFullProgressNotes(document) {
    document.viewStatus = OpenDocumentStatus.LOADING;
    this.statusTextMap.set(document.id, document.viewStatus);
    this.patientSummaryService.getProgressNoteFullDocument(document.documentRef).subscribe((res: any) => {
      if (res && res.response && res.response.statusCode === "0000") {
        document.viewStatus = OpenDocumentStatus.DOCUMENT_VIEWED;
        this.statusTextMap.set(document.id, document.viewStatus);
        var htmlContent = window.atob(res.response.resources[0].content);
        const length = htmlContent.length;
        const newWindow = window.open(res.response.resources[0].id + '.html');
        newWindow.document.title = res.response.resources[0].description;
        newWindow.document.write(htmlContent);
      } else if (res && res.response && res.response.statusCode === "7003") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.REPORT_ISSUE);
      } else if (res && res.response && res.response.statusCode === "7017") {
        this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
      }
    }, error => {
      // document.viewStatus = "error";
      this.handleError(document);
    });
  }

  handleError(document) {
    // update view status
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
      this.statusTextMap.set(document.id, OpenDocumentStatus.RETRY);
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 1) {
      // update view status
      this.statusTextMap.set(document.id, OpenDocumentStatus.SYSTEM_ERROR);
    }
  }

  convertToPlain(html) {

    // Create a new div element
    var tempDivElement = document.createElement("div");

    // Set the HTML content with the given value
    tempDivElement.innerHTML = html;

    // Retrieve the text property of the element
    return tempDivElement.textContent || tempDivElement.innerText || "";
  }
  onClickShowaddDocs() {
    this.showAdditionalDocs.emit(true);
  }

  onClickRefreshProgressNotes() {
    this.refreshProgressNotes.emit(true);
  }

  onClickRefreshCompletePN() {
    this.refreshCompletePN.emit(true);
  }

  checkNotesAvailable(): boolean {
    const keys: Array<string> = Object.keys(this.individualProgressNotes.notesTypeToNotes);
    return keys.length > 0;
  }

  getAllnotesTypeToNotes(): Array<string> {
    return Object.keys(this.individualProgressNotes.notesTypeToNotes);
  }
  printDocument() {
    let docDefinition = {
      pageSize: PrintConfig.PAGE_SIZE,
      pageMargins: PrintConfig.PAGE_MARGINS,
      info: {
        title: 'Encounter Notes',
      },
      content: [
        {
          columns: [
            [
              {
                text: PrintConfig.CURRENT_DATE,
                fontSize: 10,
                margin: [0, 2, 0, 20],
              }
            ],
            [
              {
                text: `${PrintConfig.PATIENT_TITLE}: ${this.patientInfo?.lastName} ${this.patientInfo?.firstName}`,
                alignment: 'right',
                fontSize: 10,
                margin: [0, 0, 0, 20],
              }
            ]
          ]
        },
        {
          image: PrintConfig.CVS_LOGO_IMG,
          width: 150,
          margin: [-15, 0, 0, 30],
        },
        {
          columns: [
            [
              {
                text: PrintConfig.ENCOUNTER_VIEW,
                fontSize: 14,
                bold: true,
                margin: [0, 0, 0, 20],
              }
            ],
          ]
        },
        {
          columns: [
            {
              text: `${this.individualProgressNotes.encounterType}`,
              alignment: 'left',
              fontSize: 12,
              bold: true,
              margin: [0, 0, 0, 5],
            }
          ],
        },
        {
          canvas:
            [
              {
                type: 'line',
                x1: 0,
                y1: 5,
                x2: 535,
                y2: 5,
                lineWidth: 1
              },
            ]
        },
        {
          layout: 'noBorders',
          table: {
            dontBreakRows: true,
            widths: ['15%', 'auto'],
            lineHeight: 1.5,
            body: [
              [{ text: 'Date', style: 'encounterType' }, { text: `${this.individualProgressNotes.encounterDate}` ? this.datePipe.transform(`${this.individualProgressNotes.encounterDate}`, 'MM/dd/yyyy') : this.notAvailable, style: 'dataCell' }],
              [{ text: 'Specialty', style: 'encounterType' }, { text: `${this.individualProgressNotes.speciality}` ? `${this.individualProgressNotes.speciality}` : this.notAvailable, style: 'dataCell' }],
              [{ text: 'Provider', style: 'encounterType' }, { text: this.individualProgressNotes.prescriber && (this.individualProgressNotes.prescriber.firstName || this.individualProgressNotes.prescriber.lastName) ? `${this.individualProgressNotes.prescriber.firstName} ${this.individualProgressNotes.prescriber.lastName}` : this.notAvailable, style: 'dataCell' }],
              [{ text: 'Institution', style: 'encounterType' }, { text: `${this.individualProgressNotes.institutionName}` ? `${this.individualProgressNotes.institutionName}` : this.notAvailable, style: 'dataCell' }],
              [{ text: 'Description', style: 'encounterType' }, { text: `${this.individualProgressNotes.description}` ? `${this.individualProgressNotes.description.toLowerCase()}` : this.notAvailable, style: 'description' }],
            ],
          },
        },
        {
          columns: [
            [
              {
                text: `Notes`,
                alignment: 'left',
                fontSize: 12,
                bold: true,
                margin: [0, 0, 0, 10]
              }
            ],
          ]
        },
        {
          canvas:
            [
              {
                type: 'line',
                x1: 0,
                y1: 5,
                x2: 535,
                y2: 5,
                lineWidth: 1,
              },
            ]
        },
        {
          columns: [
            [
              ...Object.keys(this.individualProgressNotes.notesTypeToNotes).map(p => ([{
                text: p,
                bold: true,
                fontSize: 12,
                margin: [0, 10, 0, 0]
              }, {
                text: this.individualProgressNotes.notesTypeToNotes[p],
                fontSize: 10,
                margin: [0, 10, 0, 0],
                lineHeight: 1.5
              }])),
            ]
          ]
        },
      ],
      styles: {
        encounterType: {
          fontSize: 10,
          bold: true,
          margin: [0, 10, 0, 0],
        },
        description: {
          fontSize: 10,
          color: '#000000',
          lineHeight: 1.5,
          margin: [0, 10, 0, 10],
        },
        dataCell: {
          color: '#000000',
          fontSize: 10,
          margin: [0, 10, 0, 0],
        }
      },

    };
    pdfMake.createPdf(docDefinition).open();
  }
}

/* To add or remove the focus box incase of mouse and with [TAB] key*/
document.body.addEventListener('mousedown', (event) => {
  document.body.classList.add('using-mouse');
});
document.body.addEventListener('keydown', function (event) {
  if (event.keyCode === 9) {
    document.body.classList.remove('using-mouse');
  }
});
