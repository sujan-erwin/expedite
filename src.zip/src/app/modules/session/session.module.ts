import { NgModule } from "@angular/core";
import { SessionExpiryModalComponent } from './components/session-expiry-modal/session-expiry-modal.component';

@NgModule({
    declarations: [SessionExpiryModalComponent],
    entryComponents: [SessionExpiryModalComponent],
    exports: [SessionExpiryModalComponent],
})
export class SessionModule {

}