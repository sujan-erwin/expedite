import { NgModel } from "@angular/forms";
import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
    styleUrls: ['./session-expiry-modal.component.scss'],
    templateUrl: "./session-expiry-modal.component.html"
})
export class SessionExpiryModalComponent {
    constructor(public activeModal: NgbActiveModal
    ) {
    }
    continue() {
        //close the modal
        this.activeModal.close('Close click');
    }
    signOut() {
        this.activeModal.close('Sign out');
    }
}
document.body.addEventListener('mousedown', (event) => {

    document.body.classList.add('using-mouse');
  });
  document.body.addEventListener('keydown', function(event) {
    if (event.keyCode === 9) {
      document.body.classList.remove('using-mouse');
    }
  });