import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorComponent } from './components/error/error.component';
import { AuthGuard } from './guards/auth/auth-guard';

const routes: Routes = [
  {
    path: 'past-search',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/past-search/past-search.module').then(m => m.PastSearchModule),
  },
  {
    path: 'patient-documents',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/patient-documents/patient-documents.module').then(m => m.PatientDocumentsModule),
  },
  {
    path: 'quick-lookup',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/quick-lookup/quick-lookup.module').then(m => m.QuickLookupModule),
  },
  {
    path: 'advanced-search',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/external-patient-search/external-patient-search.module').then(m => m.ExternalPatientSearchModule),
  },
  {
    path: 'externalPatientSearch',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/external-patient-search/external-patient-search.module').then(m => m.ExternalPatientSearchModule),

  },
  {
    path: 'Patient-documents',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/internal-patient-documents/internal-patient-documents.module').then(m => m.InternalPatientDocumentsModule),
  },
  {
    path: 'lookup-patient',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/lookup-patient/lookup-patient.module').then(m => m.LookupPatientModule),
  },
  {
    path: '**',
    component: ErrorComponent,
    canActivate: [AuthGuard]
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { useHash: true, scrollPositionRestoration: 'enabled', relativeLinkResolution: 'legacy' })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
