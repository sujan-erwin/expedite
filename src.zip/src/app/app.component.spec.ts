import { TestBed, ComponentFixture, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import {By} from "@angular/platform-browser";
import { HttpClientModule } from '@angular/common/http';
import { SpinnerService } from './spinner/spinner.service';
import { AuthService } from '../app/services/auth.service';
import { Router, RouterLinkActive } from '@angular/router';
import { BreadCrumbComponent } from './bread-crumb/bread-crumb.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';


// class AuthServiceMock {
//   getUserProfile(): any {
//     var userProfile = { "firstName": "Mike", "lastName": "Jane" };
//     return userProfile;
//   }
// } 
describe('AppComponent', () => {
  let component: AppComponent
  let router: Router;
  let authService: AuthService;
  let spinnerService: SpinnerService;
  let fixture: ComponentFixture<AppComponent>;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientModule,
      ],
      declarations: [
        AppComponent, 
        BreadCrumbComponent
      ],schemas:      [ NO_ERRORS_SCHEMA ],
      providers: [AuthService]
    }).compileComponents();
  }));

  beforeEach(() => {

    router = TestBed.get(Router);
    authService = TestBed.get(AuthService);
    // spyOn(authService, 'getUser').and.returnValue({ "firstName": "Mike", "lastName": "def", "userName": "9025804" });
    spyOn(router, 'navigate');

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
});

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  // it('should render title in a h4 tag', () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   fixture.detectChanges();
  //   const compiled = fixture.debugElement.nativeElement;
  //   expect(compiled.querySelector('h4').textContent).toContain('Speciality Expedite™ Data Viewer');
  // });
});
