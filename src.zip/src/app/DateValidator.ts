import { AbstractControl } from '@angular/forms';
import { DatePipe } from '@angular/common';

export function DateValidator(control: AbstractControl) {
    let pattern = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/((19[2-9][0-9])|(20)\d{2})$/;
    let mandatory ='mandatory';
    if(!control.pristine){
        if(control.value !=='') {
            let invalidDate =  !(pattern.test(control.value));
            invalidDate =  !invalidDate? new DatePipe('en').transform(new Date(control.value), 'MM/dd/yyyy')!==control.value: true;
            invalidDate = !invalidDate?new Date(control.value)>=new Date(): true;
            if(invalidDate){
                return {invalidDate};
            }
        }else {
            return {mandatory};
        }
    }
    return null;
    
}