import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { LookupPatientComponent } from './lookup-patient.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { By } from "@angular/platform-browser";
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { SpinnerService } from '../spinner/spinner.service';
import { SearchService } from '../services/search.service';
import { AuthService } from '../services/auth.service';
import { PatientDocumentService } from '../services/patientDocument.service';
import { errorBanners } from '../error-messages';
const mockData = {"response":{"resources":[{"id":"5000000","requestId":null,"gender":"Male","dateOfBirth":"1935-04-08","phNumber":"2075554443","surescriptsId":null,"assigningAuthority":null,"docSearchDate":"05/06/2020","name":{"firstName":"Test","lastName":"Patient","middleName":"M","prefix":null,"suffix":null},"address":{"addressLine1":"100 Roy Hill Rd","addressLine2":"","city":"Chebeague Island","state":"ME","zipCode":"04017"},"prescriber":{"npi":"1922052919","firstName":"George","lastName":"Rivera","zipCode":"92765","expediteFlag":"Y","accountName":"NE Cancer Specialists  -  Scarborough","globalAccountName":"UCHealth"},"docRefs":[{"id":"468","title":"Office Visit","status":"Relevant Document Retrieval Success","type":"Office Visit","typeCode":"34133-9","orgName":"UCLA Medical Center","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200676441&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","providerName":"Rivera","encounterDate":"2019-10-15T00:00","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"469","title":"Phone Encounter","status":"Relevant Document Retrieval Success","type":"Phone Encounter","typeCode":"34133-9","orgName":"UCLA Medical Center","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200675811&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","providerName":"Smith","encounterDate":"2019-08-02T00:00","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"467","title":"Orders Only","status":"Filter Not Matched","type":"Orders Only","typeCode":"34133-9","orgName":"Keck Medical USC","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200675751&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","providerName":"Jones","encounterDate":"2020-01-12T00:00","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"466","title":"Office Visit","status":"Relevant Document Retrieval Success","type":"Office Visit","typeCode":"34133-9","orgName":"UCLA Medical Center","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200675761&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","providerName":"Rivera","encounterDate":"2020-03-05T00:00","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"465","title":"Office Visit","status":"Filter Not Matched","type":"Office Visit","typeCode":"34133-9","orgName":"Keck Medical USC","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200676321&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","providerName":"Jones","encounterDate":"2020-04-15T00:00","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"464","title":"Phone Encounter","status":"Relevant Document Retrieval Success","type":"Phone Encounter","typeCode":"34133-9","orgName":"UCLA Medical Center","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200675661&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","providerName":"Smith","encounterDate":"2020-05-01T00:00","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"463","title":"Office Visit","status":"Relevant Document Retrieval Success","type":"Office Visit","typeCode":"34133-9","orgName":"UCLA Medical Center","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200676251&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","providerName":"Rivera","encounterDate":"2020-05-05T00:00","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"462","title":"Continuity of Care Document","status":"CCD Retrieval Success","type":"Continuity of Care Document","typeCode":"34133-9","orgName":"Keck Medical USC","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200676531&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"461","title":"Continuity of Care Document","status":"CCD Retrieval Success","type":"Continuity of Care Document","typeCode":"34133-9","orgName":"UCLA Medical Center","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200676511&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"},{"id":"470","title":"Location Summary","status":"Filter Not Matched","type":"Location Summary","typeCode":"34133-9","orgName":"Surescripts","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.200675911&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","data":null,"sourceType":null,"orgId":"2.16.840.1.113883.3.2054.2.1"}],"docFilters":null,"identifiers":null}],"statusDesc":"Success","statusCode":"0000","requestedBy":"9308198"}}
fdescribe('LookupPatientComponent', () => {
  let component: LookupPatientComponent;
  let fixture: ComponentFixture<LookupPatientComponent>;
  let form: DebugElement;
  let hbsID: DebugElement;
  let searchButton: DebugElement;
  let clearButton: DebugElement;
  let fb: FormBuilder;

  let firstName: DebugElement;
  let lastName: DebugElement;
  let dob: DebugElement;
  let male: DebugElement;
  let female: DebugElement;
  let notSpecified: DebugElement;
  let address1: DebugElement;
  let address2: DebugElement;
  let city: DebugElement;
  let state: DebugElement;
  let zip: DebugElement;
  let phone: DebugElement;
  let gender: DebugElement;
  let maleLabel: DebugElement;
  let femaleLabel: DebugElement;
  let notSpecifiedLabel: DebugElement;
  let yesdemo: DebugElement;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [LookupPatientComponent],
      imports: [RouterTestingModule, ReactiveFormsModule, FormsModule, HttpClientModule],
      providers: [DatePipe, SpinnerService, AuthService, PatientDocumentService,
        {
          provide: SearchService, useValue: jasmine.createSpyObj('SearchService',
            { retrieveHbsId: '1234567',
            retrieveDemographicsInfo: {
              "gender":"Male",
              "dateOfBirth":"1935-04-08",
              "phNumber":"2075554443",
              "firstName":"Test",
              "lastName":"Patient",
              "middleName":"M",
              "prefix":null,
              "suffix":null,
              "addressLine1":"100 Roy Hill Rd",
              "addressLine2":"",
              "city":"Chebeague Island",
              "state":"ME",
              "zipCode":"04017"
            },
           storeLookupOption: 'HBS',
           retrieveLookupOption: 'HBS'
         })
        }]
    })
      .compileComponents();
  }));
   beforeEach(() => {

   });
  beforeEach(() => {
    fixture = TestBed.createComponent(LookupPatientComponent);
    component = fixture.componentInstance;
    fb = TestBed.inject(FormBuilder);
    fixture.detectChanges();
    form = fixture.debugElement.query(By.css('#patientLookupForm'));
    clearButton = fixture.debugElement.query(By.css('#reset'));


    firstName = fixture.debugElement.query(By.css('#firstName'));
    lastName = fixture.debugElement.query(By.css('#lastName'));
    dob = fixture.debugElement.query(By.css('#dob'));
    male = fixture.debugElement.query(By.css('#male'));
    maleLabel = fixture.debugElement.query(By.css('#maleLabel'));
    female = fixture.debugElement.query(By.css('#female'));
    yesdemo = fixture.debugElement.query(By.css('#yes-demo'));

    femaleLabel = fixture.debugElement.query(By.css('#femaleLabel'));
    notSpecified = fixture.debugElement.query(By.css('#notSpecified'));
    notSpecifiedLabel = fixture.debugElement.query(By.css('#notSpecifiedLabel'));
    address1 = fixture.debugElement.query(By.css('#addressline1'));
    address2 = fixture.debugElement.query(By.css('#addressline2'));
    city = fixture.debugElement.query(By.css('#city'));
    state = fixture.debugElement.query(By.css('#state'));
    zip = fixture.debugElement.query(By.css('#zipCode'));
    phone = fixture.debugElement.query(By.css('#phone'));
    searchButton = fixture.debugElement.query(By.css('#searchButton'));
    clearButton = fixture.debugElement.query(By.css('#reset'));
    gender = fixture.debugElement.query(By.css('#gender'));
    component.patientLookupForm = fb.group({
      patientLookUpOption: ['HBS'],
      HBSID: [''],
      firstName: [''],
      lastName: [''],
      dob: [''],
      zipCode: [''],
      gender: [''],
      addressline1: [''],
      addressline2: [''],
      city: [''],
      state: [''],
      phone: [''],
      NPI: ['']
    });
    fixture.detectChanges();
  });

  it('should set Validator For DemographicFields', () => {
    let errors = {};
    let firstName = component.patientLookupForm.controls['firstName'];
    expect(firstName.valid).toBeFalsy();
    errors = firstName.errors || {};
    expect(errors['required']).toBeTruthy();
    expect(component.patientLookupForm.valid).toBeFalsy();
  })

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should form object exist', () => {
    form = fixture.debugElement.query(By.css('#patientLookupForm'))
    expect(form).toBeTruthy();
  });

  it('should form has all the fileds', () => {

    hbsID = fixture.debugElement.query(By.css('#hbs'));
    searchButton = fixture.debugElement.query(By.css('#search'));
    clearButton = fixture.debugElement.query(By.css('#reset'));
    expect(hbsID).toBeTruthy();
    expect(searchButton).toBeTruthy();
    expect(clearButton).toBeTruthy();

  });

  it('should allow us to set a value input field patient HBS ID', () => {
    const hbsID = component.patientLookupForm.controls.HBSID;
    hbsID.setValue('1234567890');
    expect(component.HBSID.value).toEqual('1234567890');
    expect(hbsID.valid).toBeTruthy();
  });

  it('should allow us to enter only 10 characters for the field patient HBS ID', () => {
    const hbsID = component.patientLookupForm.controls.HBSID;
    hbsID.setValue('12345678909');
    expect(component.HBSID.value).toEqual('12345678909');
    expect(hbsID.valid).toBeFalsy();

  });
  it('Should have called onSubmit function on click of the button', () => {
    spyOn(component, 'onSubmit');
    form = fixture.debugElement.query(By.css('form'));
    form.triggerEventHandler('submit', null);
    fixture.detectChanges();
    expect(component.onSubmit).toHaveBeenCalled();
  });
  it('Should have called clearSearch function on click of the button', () => {
    clearButton = fixture.debugElement.query(By.css('#reset'));
    form = fixture.debugElement.query(By.css('#patientLookupForm'));
    spyOn(component, 'clearSearch');
    clearButton.nativeElement.click();
    form.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.clearSearch).toHaveBeenCalled();
  });

  it('first name text box should be present in default', () => {
    changeOption(yesdemo);
    expect(firstName).toBeDefined();
  });
  it('last name text box should be present in default', () => {
    expect(lastName).toBeDefined();
  });
  it('dob text box should be present in default', () => {
    expect(dob).toBeDefined();
  });
  it('male select component should present', () => {
    expect(male).toBeDefined();
  });
  it('female select component should present', () => {
    expect(female).toBeDefined();
  });
  it('not specified select component should present', () => {
    expect(notSpecified).toBeDefined();
  });
  it('Address line1 text box should be present', () => {
    expect(address1).toBeDefined();
  });
  it('Address line2 text box should be present', () => {
    expect(address2).toBeDefined();
  });
  it('City text box should be present', () => {
    expect(city).toBeDefined();
  });
  it('State text box should be present', () => {
    expect(state).toBeDefined();
  });
  it('Zip code text box should be present', () => {
    expect(zip).toBeDefined();
  });
  it('Phone text box should be present', () => {
    expect(phone).toBeDefined();
  });
  it('search button should be present', () => {
    expect(searchButton).toBeDefined();
  });
  it('clear link should be present', () => {
    expect(clearButton).toBeDefined();
  });

  fdescribe('onSubmit method', () => {
    it('should call HBSID', () => {
      spyOn(component, 'resetErrorBanner');

      component.onSubmit();
    });
  });


  function changeOption(field: DebugElement) {
    fixture.detectChanges();
    field.nativeElement.checked = true;
    field.nativeElement.dispatchEvent(new Event('change'));
    fixture.detectChanges();
  }
});
