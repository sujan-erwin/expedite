import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss']
})
export class ErrorComponent  {

  constructor( private router: Router, public route: ActivatedRoute) { }

  goBack() {
    window.history.back();
  }
}
