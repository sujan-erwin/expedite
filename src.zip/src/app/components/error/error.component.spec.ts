import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Location } from '@angular/common';
import { ErrorComponent } from './error.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('ErrorComponent', () => {
  let component: ErrorComponent;
  let fixture: ComponentFixture<ErrorComponent>;
  let location: any;

  beforeEach(waitForAsync(() => {
    location = { back: jasmine.createSpy('back') };

    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [ErrorComponent],
      providers: [{ provide: Location, useValue: location }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('go-back button should go back to previous page', () => {
  //   component.goBack();
  //   expect(location.back).toHaveBeenCalled();
  // });

});
