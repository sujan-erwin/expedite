import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule} from '@angular/common/http';
import { QuickLookUpComponent } from './quickLookup.component';
import { DatePipe } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {By} from "@angular/platform-browser";
import { DebugElement } from '@angular/core';
import { SpinnerService } from '../spinner/spinner.service';
import { errorBanners } from '../error-messages';

describe('QuickLookUpComponent', () => {
  
  let component: QuickLookUpComponent;
  let fixture: ComponentFixture<QuickLookUpComponent>;


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ QuickLookUpComponent ],
      imports:[RouterTestingModule, ReactiveFormsModule, FormsModule, HttpClientModule],
      providers:[DatePipe, SpinnerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuickLookUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should form object exist', () => {
   const form = fixture.debugElement.query(By.css('#quickLookUpForm'))
    expect(form).toBeTruthy();
  });

  it('should form has all the fileds', () => {
    
    const hbsID = fixture.debugElement.query(By.css('#hbs'));
    const searchButton = fixture.debugElement.query(By.css('#search'));
    const clearButton = fixture.debugElement.query(By.css('#reset'));
    const advSearchButton = fixture.debugElement.query(By.css('.advanced-search'));
    expect(hbsID).toBeTruthy();
    expect(searchButton).toBeTruthy();
    expect(clearButton).toBeTruthy();
    expect(advSearchButton).toBeTruthy();

  });
  
  it('should allow us to set a value input field patient HBS ID', () => {
    
    const  hbsID =  component.quickLookUpForm.controls.HBSID;
    hbsID.setValue('1234567890');
    expect(component.HBSID.value).toEqual('1234567890');
    expect(hbsID.valid).toBeTruthy();
  });
 
  it('should allow us to enter only 10 characters for the field patient HBS ID', () => {
   const  hbsID =  component.quickLookUpForm.controls.HBSID;
    hbsID.setValue('12345678909');
    expect(component.HBSID.value).toEqual('12345678909');
    expect(hbsID.valid).toBeFalsy();
    
  });
 


  it('Should have called onSubmit function on click of the button', () => {
    spyOn(component, 'onSubmit');
    let form = fixture.debugElement.query(By.css('form'));
    form.triggerEventHandler('submit', null);
    fixture.detectChanges();
    expect(component.onSubmit).toHaveBeenCalled();
  });
  it('Should have called clearSearch function on click of the button', () => {
    const clearButton = fixture.debugElement.query(By.css('#reset'));
   const form =  fixture.debugElement.query(By.css('#quickLookUpForm'));
    spyOn(component, 'clearSearch');
    clearButton.nativeElement.click();
    form.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.clearSearch).toHaveBeenCalled();
  });
  // it('should allow us to set a value input field patient first name', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   firstName = fixture.debugElement.query(By.css('#firstName'));
  //   expect(firstName).toBeTruthy();
  //   setInputValue(firstName, 'Mike');
  //   expect(component.firstName.value).toEqual('Mike');
  //   expect(firstName.nativeElement.classList).not.toContain('error');
  // });
  // it('should allow us to set 36 characters for input field patient first name', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   firstName = fixture.debugElement.query(By.css('#firstName'));
  //   expect(firstName).toBeTruthy();
  //   setInputValue(firstName, 'KeihanaikukauakahihuliheekahaunaeleKeihanaikukauakahihuliheekahaunaele');
  //   expect(component.firstName.value).toEqual('KeihanaikukauakahihuliheekahaunaeleKeihanaikukauakahihuliheekahaunaele');
  //   expect(firstName.nativeElement.classList).toContain('error');
  // });
  // it('should allow us to set a value input field patient last name', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   lastName = fixture.debugElement.query(By.css('#lastName'));
  //   expect(lastName).toBeTruthy();
  //   setInputValue(lastName, 'Douglar');
  //   expect(component.lastName.value).toEqual('Douglar');
  //   expect(lastName.nativeElement.classList).not.toContain('error');
  // });
  // it('should allow us to set 36 characters for input field patient last name', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   lastName = fixture.debugElement.query(By.css('#lastName'));
  //   expect(lastName).toBeTruthy();
  //   setInputValue(lastName, 'KeihanaikukauakahihuliheekahaunaeleKeihanaikukauakahihuliheekahaunaele');
  //   expect(component.lastName.value).toEqual('KeihanaikukauakahihuliheekahaunaeleKeihanaikukauakahihuliheekahaunaele');
  //   expect(lastName.nativeElement.classList).toContain('error');
  // });
  // it('should allow us to set a value input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '02/26/2020');
  //   expect(component.dob.value).toEqual('02/26/2020');
  //   expect(dob.nativeElement.classList).not.toContain('error');
  // });
  // it('should allow us to enter valid date without leading zeros such as 1/1/2000 for input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '1/1/2000');
  //   expect(component.dob.value).toEqual('01/01/2000');
  //   expect(dob.nativeElement.classList).not.toContain('error');
  // });
  // it('should allow us to enter valid date without leading zeros on date such as 01/1/2000 for input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '01/1/2000');
  //   expect(component.dob.value).toEqual('01/01/2000');
  //   expect(dob.nativeElement.classList).not.toContain('error');
  // });
  // it('should allow us to enter valid date without leading zeros on month such as  1/01/2000 for input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '1/01/2000');
  //   expect(component.dob.value).toEqual('01/01/2000');
  //   expect(dob.nativeElement.classList).not.toContain('error');
  // });
  // it('should allow us to enter leap year and feb month with 29 days such as 02/29/2000 for input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '02/29/2000');
  //   expect(component.dob.value).toEqual('02/29/2000');
  //   expect(dob.nativeElement.classList).not.toContain('error');
  // });
  // it('should display invalid date if user enters invalid month such as 13/30/2000 for input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '13/30/2000');
  //   expect(component.dob.value).toEqual('13/30/2000');
  // });
  // it('should display invalid date if user enters invalid day such as 12/91/2000 for input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '12/91/2000');
  //   expect(component.dob.value).toEqual('12/91/2000');
  // });
  // it('should display invalid date if user enters before year 1920 such as 12/30/1919 for input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '12/30/1919');
  //   expect(component.dob.value).toEqual('12/30/1919');
  // });
  // it('should display invalid date if user enters day as 31 for the month have only 30 days such as 04/31/2000 for input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '04/31/2000');
  //   expect(component.dob.value).toEqual('04/31/2000');
  // });
  // it('should display invalid date if user enters invalid day for feb month such as 02/30/2000 input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '02/30/2000');
  //   expect(component.dob.value).toEqual('02/30/2000');
  // });
  // it('should display invalid date if user enters future date such as 04/27/2100 input field patient dob', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   dob = fixture.debugElement.query(By.css('#dob'));
  //   expect(dob).toBeTruthy();
  //   setInputValue(dob, '04/27/2100');
  //   expect(component.dob.value).toEqual('04/27/2100');
  // });
  // it('should allow us to set a value input field patient zipcode', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   zip = fixture.debugElement.query(By.css('#zipCode'));
  //   expect(zip).toBeTruthy();
  //   setInputValue(zip, '60070');
  //   expect(component.zipCode.value).toEqual('60070');
  //   expect(zip.nativeElement.classList).not.toContain('error');
  // });

  // it('shouldnt allow us to set zipcode more than 5 chars for input field patient zipcode', () => {
  //   changeOption();
  //   expect(component.quickLookUpOption.value).toEqual('demographic');
  //   zip = fixture.debugElement.query(By.css('#zipCode'));
  //   expect(zip).toBeTruthy();
  //   setInputValue(zip, '600704');
  //   expect(component.zipCode.value).toEqual('600704');
  //   expect(zip.nativeElement.classList).toContain('error');
  // });

  it('error Banner should displayed when service returns error', () => {
    component.result.display = true;
    component.result.banner = errorBanners.internalPatientSearch['default'];
    fixture.detectChanges();
    let banner = fixture.nativeElement.querySelector('#msgBanner');
    expect(banner.classList).toContain(component.result.banner.type);
  });

  it('Infor Banner should displayed when No paties Found from server', () => {

    component.result.display = true;
    component.result.banner = errorBanners.internalPatientSearch['7000'];
    fixture.detectChanges();
    let banner = fixture.nativeElement.querySelector('#msgBanner');
    expect(banner.classList).toContain(component.result.banner.type);
    
  });


  it('error Banner should have title as server error when service returns error', () => {
    component.result.display = true;
    component.result.banner = errorBanners.internalPatientSearch['default'];
    fixture.detectChanges();
    const title = fixture.nativeElement.querySelector('#title');
    expect(title.innerHTML).toContain(component.result.banner.title);
  });

  it('error Banner should clear when clear button is clicked', () => {
  
    const clearButton = fixture.debugElement.query(By.css('#reset'));
    component.result.display = true;
    component.result.banner = errorBanners.internalPatientSearch['default'];
    fixture.detectChanges();
    let banner = fixture.debugElement.query(By.css('#msgBanner'));
    expect(banner.nativeElement.classList).toContain(component.result.banner.type);
    clearButton.nativeElement.click();
    clearButton.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.result.display).toBeFalsy();
    expect(banner).toBeNull;
  });


});
