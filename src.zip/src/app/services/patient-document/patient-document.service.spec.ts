import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common';

import { PatientDocumentService } from './patient-document.service';
import { SpinnerService } from '../spinner/spinner.service';
import { AuthService } from '../auth/auth.service';


describe('patiendDocumentService', () => {
  let service: PatientDocumentService;
  let httpClient: HttpTestingController;
  beforeEach(() => {

    TestBed.configureTestingModule({
      providers: [
        AuthService,
        DatePipe,
        HttpClientModule,
        SpinnerService
      ],
      imports: [
        HttpClientTestingModule
      ]
    });
    service = TestBed.get(PatientDocumentService);

  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // it('should be get dashboard details as expected', () => {
  //   const firstName = 'firstName', lastName = 'lastBame', dateOfBirth = 'dateOfBirth', ssId = "ssId",
  //     assigningAuthority = 'assigningAuthority', id = 'id';
  //   const testUserName = '9025804';
  //   const httpClient: HttpClient = TestBed.get(HttpClient);
  //   const authService: AuthService = TestBed.get(AuthService);

  //   spyOn(authService, 'getUser').and.returnValue({ userName: testUserName });
  //   const request = {
  //       "name": {
  //         "firstName": firstName,
  //         "lastName": lastName,
  //       },
  //       "id": id,
  //       "dateOfBirth": dateOfBirth,
  //       "surescriptsId": ssId,
  //       "assigningAuthority": assigningAuthority
  //   };
  //   spyOn(httpClient, 'post').and.returnValue(of({}));

  //   expect(service).toBeTruthy();
  //   service.getDocumentList(request);

  //   const response = {
  //     "patient": {
  //       "name": {
  //         "firstName": firstName,
  //         "lastName": lastName,
  //       },
  //       "id": id,
  //       "dateOfBirth": dateOfBirth,
  //       "surescriptsId": ssId,
  //       "assigningAuthority": assigningAuthority
  //     },
  //     "requestedBy": testUserName
  //   };

  //   expect(httpClient.post).toHaveBeenCalledWith(environment.config.serverEndPoint + environment.config.path.documentSearch, JSON.stringify(response));
  // });
  it('setDocumentList should set documentList', () => { const documents = [{ id: 1, name: 'name' }]; service.setDocList(documents); expect(service.documentList).toBe(documents); })
});
