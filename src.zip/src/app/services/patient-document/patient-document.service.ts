import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SearchService } from '../search/search.service';
import { AuthService } from '../auth/auth.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PatientDocumentService {
  documentList: any;
  prescriber: any;
  user: any;
  oldHBSID: any;
  externalDocList: any;

  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  constructor(private httpClient: HttpClient,
    private searchService: SearchService,
    private authService: AuthService
    ) { }

  getDocument(patient) {
    this.user = this.authService.getUser();
    patient.requestedBy = this.user.userName;
    return this.httpClient.post(environment.config.serverEndPoint + environment.config.path.retrieveDocument,
      JSON.stringify(patient));
  }

  getInternalDocumentList(patient: any, docRef: any) {
    this.user = this.authService.getUser();
    const data = {
      "patient": {
        "id": patient.HBSID,
        "dateOfBirth": patient.dob,
        "gender": patient.gender,
        "address": {
          "addressLine1": patient.addressline1,
          "addressLine2": patient.addressline2,
          "city": patient.city,
          "state": patient.state,
          "zipCode": patient.zipCode
        },
        "name": {
          "firstName": patient.firstName,
          "lastName": patient.lastName,
        },
        "docRefs": [docRef],
      },
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"
    };
    let url = this.getRelevantUrl(docRef.status);
    return this.httpClient.post(url,
      JSON.stringify(data))
  }
  getRelevantUrl(status) {
    if (status === 'CCD Retrieval Success' || status === 'Relevant CCD Retrieval Success' || status === 'Relevant Document Retrieval Success') {
      return this.searchService.getInternalServerEndPoint() + environment.config.path.documentRetrieval;
    } else {
      return environment.config.serverEndPoint + environment.config.path.retrieveDocument;
    }
  }

  setOldHBSID(id: any) {
    this.oldHBSID = id;
  }

  getOldHBSID() {
    return this.oldHBSID;
  }

  setDocList(docList) {
    if (docList) {
      let i = 1;
      docList.forEach(element => {
        element.viewStatus = "view";
        element.digitalId = i;
        i++
      });
    }
    this.documentList = docList;
  }
  getDocList() {
    return this.documentList;
  }

  setExternalDocList(docList){
    if (docList) {
      let i = 1;
      docList.forEach(element => {
        element.viewStatus = "view";
        element.digitalId = i;
        i++
      });
    }
    this.externalDocList = docList;
  }
  getExternalDocList() {
    return this.externalDocList;
  }

  setPrescriber(prescriber) {
    this.prescriber = prescriber;
  }

  getPrescriber() {
    return this.prescriber;
  }
}


