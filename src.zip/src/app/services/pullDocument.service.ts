import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SearchService } from './search.service';
import { PatientDocumentService } from './patientDocument.service';
import { AuthService } from './auth.service';
import { map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PullDocumentService {
  user: any;
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };

  constructor(private httpClient: HttpClient,
    private patientDocumentService: PatientDocumentService,
    private searchService: SearchService, private authService: AuthService) { }

  pullDocumentList(documents, resource) {
    this.user = this.authService.getUser();
    
    const request = {
      "cvsPatient": {
        "id": null,
        "gender": resource.gender,
        "dateOfBirth": resource.dateOfBirth,
        "phNumber": null,
        "surescriptsId": resource.surescriptsId,
        "assigningAuthority": resource.assigningAuthority,
        "name": {
          "firstName": resource.name.firstName,
          "lastName": resource.name.lastName,
          "middleName": null,
          "prefix": null,
          "suffix": null
        },
        "address": null,
        "docRefs": documents
      },
      "requestedBy": this.user.userName
    };
    
    return this.httpClient.post(
      // "http://localhost:8080/specialtyexpedite/documents/save",
      environment.config.serverEndPoint + environment.config.path.pullDocument,
      JSON.stringify(request))
  }
}
