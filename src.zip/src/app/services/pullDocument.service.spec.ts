import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';
import { Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { PatientDocumentService } from './patientDocument.service';
import { PullDocumentService } from './pullDocument.service';
import { DatePipe } from '@angular/common';
import { SpinnerService } from '../spinner/spinner.service';

describe('PullDocumentService', () => {
  let service: PullDocumentService;
  let httpClient: HttpTestingController;
  beforeEach(() => TestBed.configureTestingModule({
    providers: [AuthService, PullDocumentService, DatePipe, SpinnerService],
    imports: [HttpClientTestingModule]
  }));

  it('should be created', () => {
    const service: PullDocumentService = TestBed.get(PullDocumentService);
    expect(service).toBeTruthy();
  });

  it('should be able to pull documents for new patient', () => {
    const testUserName = '9326570';
    const httpClient: HttpClient = TestBed.get(HttpClient);
    const authService: AuthService = TestBed.get(AuthService);
    const service: PullDocumentService = TestBed.get(PullDocumentService);
    // spyOn(authService, 'getUser').and.returnValue({ userName: testUserName });
    const resource = {
      gender: "gender",
      dateOfBirth: "dateOfBirth",
      surescriptsId: "surescriptsId",
      assigningAuthority: "assigningAuthority",
      name: {
        firstName: "firstName",
        lastName: "lastName",
      },
      documents: "documents"
    };
    const data = {
      "cvsPatient": {
        "id": null,
        "gender": "gender",
        "dateOfBirth": "dateOfBirth",
        "phNumber": null,
        "surescriptsId": "surescriptsId",
        "assigningAuthority": "assigningAuthority",
        "name": {
          "firstName": "firstName",
          "lastName": "lastName",
          "middleName": null,
          "prefix": null,
          "suffix": null
        },
        "address": null
      },
      "requestedBy": "9326570"
    };
    spyOn(httpClient, 'post').and.returnValue(of({}));
    expect(service).toBeTruthy();
    //spyOn(service, 'searchPatient').and.returnValue('{"response":{"resources":[{"id":null,"gender":"female","dateOfBirth":"1991-01-12","phNumber":null,"surescriptsId":"34001201","assigningAuthority":"2.16.840.1.113883.3.2054.2.1","name":{"firstName":"PEGGY","lastName":"PONCE","middleName":null,"prefix":null,"suffix":null},"address":{"addressLine1":"9522 CODY DR","addressLine2":null,"city":"OLIVETTE","state":"MO","zipCode":"63132"},"docRefs":null}],"statusDesc":"Success","statusCode":"0000","requestedBy":"9025804"}}');
    // spyOn(service, 'searchPatient').and.returnValue({});
    service.pullDocumentList(Document, resource);
    expect(httpClient.post).toHaveBeenCalledWith(environment.config.serverEndPoint + environment.config.path.pullDocument, JSON.stringify(data));
    
  });
});
