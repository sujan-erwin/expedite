import { Injectable } from '@angular/core';
import * as CryptoJS from "crypto-js";

let key = '6fa979f20126cb08aa645a8f495f6d85';
let iv = 'I8zyA4lVhMCaJ5Kg';

@Injectable({
    providedIn: 'root'
})
export class EncryptDecrypt {

    aesEncrypt(data) {
        if (data) {
            let encrypted = CryptoJS.AES.encrypt(data, key, { iv: iv });
            return encrypted.toString();
        } else {
            return null;
        }
    }

    aesDecrypt(data) {
        if (data) {
            let decrypted = CryptoJS.AES.decrypt(data, key, { iv: iv });
            return decrypted.toString(CryptoJS.enc.Utf8);
        } else {
            return null;
        }
    }

}
