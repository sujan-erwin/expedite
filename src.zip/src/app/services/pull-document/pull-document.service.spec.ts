import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';

import { environment } from 'src/environments/environment';
import { PullDocumentService } from './pull-document.service';
import { SpinnerService } from '../spinner/spinner.service';
import { AuthService } from '../auth/auth.service';

describe('PullDocumentService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [AuthService, PullDocumentService, DatePipe, SpinnerService],
    imports: [HttpClientTestingModule]
  }));

  it('should be created', () => {
    const service: PullDocumentService = TestBed.get(PullDocumentService);
    expect(service).toBeTruthy();
  });

  it('should be able to pull documents for new patient', () => {
    const testUserName = '9326570';
    const httpClient: HttpClient = TestBed.get(HttpClient);
    const authService: AuthService = TestBed.get(AuthService);
    const service: PullDocumentService = TestBed.get(PullDocumentService);
    spyOn(authService, 'getUser').and.returnValue({ userName: testUserName });
    const resource = {
      gender: "gender",
      dateOfBirth: "dateOfBirth",
      surescriptsId: "surescriptsId",
      assigningAuthority: "assigningAuthority",
      name: {
        firstName: "firstName",
        lastName: "lastName",
      },
      documents: "documents"
    };
    const data = {
      "cvsPatient": {
        "id": null,
        "gender": "gender",
        "dateOfBirth": "dateOfBirth",
        "phNumber": null,
        "surescriptsId": "surescriptsId",
        "assigningAuthority": "assigningAuthority",
        "name": {
          "firstName": "firstName",
          "lastName": "lastName",
          "middleName": null,
          "prefix": null,
          "suffix": null
        },
        "address": null
      },
      "requestedBy": "9326570"
    };
    spyOn(httpClient, 'post').and.returnValue(of({}));
    expect(service).toBeTruthy();
    service.pullDocumentList(Document, resource);
    expect(httpClient.post).toHaveBeenCalledWith(environment.config.serverEndPoint + environment.config.path.pullDocument, JSON.stringify(data));

  });
});

