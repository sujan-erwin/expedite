import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { PatientDocumentService } from '../patient-document/patient-document.service';
import { SearchService } from '../search/search.service';
import { AuthService } from '../auth/auth.service';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class PullDocumentService {
  user: any;
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };

  constructor(
    private httpClient: HttpClient,
    private patientDocumentService: PatientDocumentService,
    private searchService: SearchService,
    private authService: AuthService,
  ) { }

  pullDocumentList(documents, resource) {
    this.user = this.authService.getUser();

    const request = {
      "cvsPatient": {
        "id": null,
        "gender": resource.gender,
        "dateOfBirth": resource.dateOfBirth,
        "phNumber": null,
        "surescriptsId": resource.surescriptsId,
        "assigningAuthority": resource.assigningAuthority,
        "name": {
          "firstName": resource.name.firstName,
          "lastName": resource.name.lastName,
          "middleName": null,
          "prefix": null,
          "suffix": null
        },
        "address": null,
        "docRefs": documents
      },
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"
    };

    return this.httpClient.post(
      // "http://localhost:8080/specialtyexpedite/documents/save",
      environment.config.serverEndPoint + environment.config.path.pullDocument,
      JSON.stringify(request))
  }
}
