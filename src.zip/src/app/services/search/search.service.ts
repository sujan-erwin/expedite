import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { Observable, of, throwError, iif, BehaviorSubject } from 'rxjs';
import { map, retryWhen, delay, concatMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { SpinnerService } from '../spinner/spinner.service';
import { AuthService } from '../auth/auth.service';
import { EncryptDecrypt } from 'src/app/services/crypto-js/crypto-js.encrypt.decrypt';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  sourcePage: string;
  patient: any;
  user: any;
  resource: any;
  internalResource: any;
  sourcelookupPage: any;

  retryCount: number;
  currentRetry: number;
  //delay: number = 30000;
  delay: number = 20000;
  automaticDocumentsUpdate: boolean = false;
  isClearDisableReqFields: boolean = false;
  // using behavioral subject to hide Addressline fields
  private _enableDemoFields = new BehaviorSubject<boolean>(false);
  private _enableDemoFields$ = this._enableDemoFields.asObservable();
  private _enableResultBanner = new BehaviorSubject<boolean>(false);
  private _enableResultBanner$ = this._enableResultBanner.asObservable();

  setShowfeedbackQuestion(show: boolean) {
    sessionStorage.setItem('showFeedbackQuestion', JSON.stringify(show));
  }

  getShowfeedbackQuestion() {
    let showFeedbackQuestion = sessionStorage.getItem('showFeedbackQuestion');
    return showFeedbackQuestion ? JSON.parse(showFeedbackQuestion) : undefined;
  }

  storeHbsId(hbsId) {
    if (hbsId) {
      sessionStorage.setItem('hbsId', this.encryptDecrypt.aesEncrypt(JSON.stringify(hbsId)));
    } else {
      sessionStorage.removeItem('hbsId');
    }
  }

  retrieveHbsId() {
    const hbsId = sessionStorage.getItem('hbsId');
    return (hbsId && hbsId != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(hbsId)) : null;
  }
  storeDemographicsInfo(demo) {
    sessionStorage.setItem('demographicInfo', demo ? this.encryptDecrypt.aesEncrypt(JSON.stringify(demo)) : JSON.stringify(demo));
  }

  retrieveDemographicsInfo() {
    const demographicInfo = sessionStorage.getItem('demographicInfo');
    return (demographicInfo && demographicInfo != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(demographicInfo)) : null;
  }
  storeLookupOption(option) {
    sessionStorage.setItem('lookUpOption', option ? this.encryptDecrypt.aesEncrypt(JSON.stringify(option)) : JSON.stringify(option));
  }
  retrieveLookupOption() {
    const lookUpOption = sessionStorage.getItem('lookUpOption');
    return (lookUpOption && lookUpOption != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(lookUpOption)) : null;
  }

  setSourcePage(sourcePage: string) {
    this.sourcePage = sourcePage;
  }
  getSourcePage() {
    return this.sourcePage;
  }

  setPatient(patient) {
    sessionStorage.setItem('patientInfo', patient ? this.encryptDecrypt.aesEncrypt(JSON.stringify(patient)) : JSON.stringify(patient));
    this.patient = patient;
  }

  getPatient() {
    if (!this.patient) {
      let obj = sessionStorage.getItem('patientInfo');
      this.patient = (obj && obj != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(obj)) : {};
    }
    return this.patient;
  }

  constructor(
    private httpClient: HttpClient,
    private datePipe: DatePipe,
    private spinnerService: SpinnerService,
    private authService: AuthService,
    private encryptDecrypt: EncryptDecrypt
  ) { }

  searchPatient(searchDetails) {
    this.user = this.authService.getUser();
    var data = {
      "patient": {
        "address": {
          "addressLine1": searchDetails.addressLine1,
          "city": searchDetails.city,
          "state": searchDetails.state,
          "zipCode": searchDetails.Zipcode
        },
        "dateOfBirth": `${searchDetails.dob.YYYY}-${searchDetails.dob.MM}-${searchDetails.dob.DD}`, //searchDetails.dob
        "gender": searchDetails.gender,
        "id": searchDetails.HBSID,
        "name": {
          "firstName": searchDetails.frstName,
          "lastName": searchDetails.lstName,
        },
        "phNumber": searchDetails.Phone,
      },
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"
    }

    return this.httpClient.post(
      environment.config.serverEndPoint + environment.config.path.patientSearch,
      // 'https://httpbin.org/status/500'
      JSON.stringify(data));
  }

  getInternalServerEndPoint() {
    let serverEndPoint = environment.config.serverEndPoint;
    console.log("env:", environment.env);
    if (environment.env === 'prod') {
      serverEndPoint = environment.config.serverEndPointWest;
    }
    return serverEndPoint;
  }

  searchPatientByDemo(searchDetails) {
    this.spinnerService.show();
    this.user = this.authService.getUser();
    const states: Array<any> = this.getStateList();
    const stateValue = states.find(state => state.name === searchDetails.state);
    var data = {
      "patient": {
        "dateOfBirth": this.datePipe.transform(new Date(searchDetails.dob), 'yyyy-MM-dd'),
        "gender": searchDetails.gender,
        "id": "1234",
        "name": {
          "firstName": searchDetails.firstName,
          "lastName": searchDetails.lastName,
        },
        "address": {
          "zipCode": searchDetails.zipCode
        },
      },
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.lookupPatientByDemo,
      JSON.stringify(data));
  }

  searchPatientByAddressDemo(searchDetails) {
    this.storeDemographicLookupOption('demographicAddressLookup');
    this.spinnerService.show();
    this.user = this.authService.getUser();
    const states: Array<any> = this.getStateList();
    const stateValue = states.find(state => state.name === searchDetails.state);
    var data = {
      "patient": {
        "address": {
          "addressLine1": searchDetails.addressline1,
          "addressLine2": searchDetails.addressline2, // should it send in a request - confirm with services
          "city": searchDetails.city,
          "state": stateValue.abbreviation,
          "zipCode": searchDetails.zipCode
        },
        "dateOfBirth": this.datePipe.transform(new Date(searchDetails.dob), 'yyyy-MM-dd'),
        "gender": searchDetails.gender,
        "id": "1234",
        "name": {
          "firstName": searchDetails.firstName,
          "lastName": searchDetails.lastName,
        },
        "prescriber": {
          "npi": searchDetails.NPI
        },
        "phNumber": searchDetails.phone,
      },
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"

    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.lookupPatientByDemo,
      JSON.stringify(data));
  }

  searchInput(term, docIds: any[], hbsId) {
    this.spinnerService.show();
    this.user = this.authService.getUser();
    var data = {
      "search": {
        "term": term,
        "docIds": docIds
      },
      "hbsId": hbsId,
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.docSearch,
      JSON.stringify(data));
  }

  /* New ExternalPatientSearch service call */
  advancedPatientSearch(searchDetails) {
    this.spinnerService.show();
    this.user = this.authService.getUser();
    var data = {
      "patient": {
        "address": {
          "addressLine1": searchDetails.addressline1,
          "addressLine2": searchDetails.addressline2,
          "city": searchDetails.city,
          "state": searchDetails.state,
          "zipCode": searchDetails.zipCode
        },
        "dateOfBirth": this.datePipe.transform(new Date(searchDetails.dob), 'yyyy-MM-dd'),
        "gender": searchDetails.gender,
        "id": searchDetails.HBSID,
        "name": {
          "firstName": searchDetails.firstName,
          "lastName": searchDetails.lastName,
          "middleName": searchDetails.middleName,
          "suffix": searchDetails.suffix,

        },
        "phNumber": searchDetails.phone,
        "prescriber": {
          "npi": searchDetails.npi
        }
      },
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"
    }
    return this.httpClient.post(
      environment.config.serverEndPoint + environment.config.path.advancedPatientSearch,
      JSON.stringify(data));
  }

  captureFeedback(hbsId, option, comment) {
    {
      this.user = this.authService.getUser();
      var feedbacks = [];
      var data = { "hbsId": hbsId, "feedbacks": feedbacks, "requestedBy": this.user.userName };
      data.hbsId = hbsId;

      feedbacks.push({ "questionSequence": 1, "questionText": "Did you find all the information you needed to complete the task?", "answerText": option });
      if (option === "No") {
        this.spinnerService.show();
        feedbacks.push({ "questionSequence": 2, "questionText": "What information could you not find?", "answerText": comment.comments });
      }
      return this.httpClient.post(
        this.getInternalServerEndPoint() + environment.config.path.userfeedback,
        JSON.stringify(data));
    }
  }

  setResource(resource) {
    sessionStorage.setItem('resourceInfo', resource ? this.encryptDecrypt.aesEncrypt(JSON.stringify(resource)) : JSON.stringify(resource));
    this.resource = resource;
  }
  getResource() {
    if (!this.resource) {
      let obj = sessionStorage.getItem('resourceInfo');
      this.resource = (obj && obj != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(obj)) : {};
    }
    return this.resource;
  }

  setInternalResource(resource) {
    if (resource) {
      sessionStorage.setItem('internalResourceInfo', this.encryptDecrypt.aesEncrypt(JSON.stringify(resource)));
    } else {
      sessionStorage.removeItem('internalResourceInfo');
    }
    this.internalResource = resource;
  }

  getInternalResource() {
    if (!this.internalResource) {
      let obj = sessionStorage.getItem('internalResourceInfo');
      this.internalResource = (obj && obj != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(obj)) : {};
    }
    return this.internalResource;
  }

  getResourceToPatient() {
    this.getResource();
    return this.generateResourceToPatient(this.resource);
  }

  getInternalResourceToPatient() {
    this.getInternalResource();
    return this.generateResourceToPatient(this.internalResource);
  }

  generateResourceToPatient(resource) {
    let patient;
    if (resource) {
      patient = {
        firstName: resource.name ? resource.name.firstName : "",
        lastName: resource.name ? resource.name.lastName : "",
        middleName: resource.name ? resource.name.middleName : "",
        suffix: resource.name ? resource.name.suffix : "",
        HBSID: resource.id,
        dob: resource.dateOfBirth,
        gender: resource.gender,
        srcPatientId: resource.srcPatientId,
        addressline1: resource.address ? resource.address.addressLine1 : "",
        addressline2: resource.address ? resource.address.addressLine2 : "",
        city: resource.address ? resource.address.city : "",
        state: resource.address ? resource.address.state : "",
        zipCode: resource.address ? resource.address.zipCode : "",
        phone: resource.phNumber,
        docSearchDate: resource.docSearchDate,
        npi: resource.prescriber ? resource.prescriber.npi : ""
      };
    }

    return patient;
  }

  setSourceLookupPage(sourcelookupPage) {
    this.sourcelookupPage = sourcelookupPage;
  }

  getSourceLookupPage() {
    return this.sourcelookupPage;
  }
  public getStateList() {
    var stateList: any = [
      {
        "name": "Alabama",
        "abbreviation": "AL"
      },
      {
        "name": "Alaska",
        "abbreviation": "AK"
      },
      {
        "name": "American Samoa",
        "abbreviation": "AS"
      },
      {
        "name": "Arizona",
        "abbreviation": "AZ"
      },
      {
        "name": "Arkansas",
        "abbreviation": "AR"
      },
      {
        "name": "California",
        "abbreviation": "CA"
      },
      {
        "name": "Colorado",
        "abbreviation": "CO"
      },
      {
        "name": "Connecticut",
        "abbreviation": "CT"
      },
      {
        "name": "Delaware",
        "abbreviation": "DE"
      },
      {
        "name": "District Of Columbia",
        "abbreviation": "DC"
      },
      {
        "name": "Federated States Of Micronesia",
        "abbreviation": "FM"
      },
      {
        "name": "Florida",
        "abbreviation": "FL"
      },
      {
        "name": "Georgia",
        "abbreviation": "GA"
      },
      {
        "name": "Guam",
        "abbreviation": "GU"
      },
      {
        "name": "Hawaii",
        "abbreviation": "HI"
      },
      {
        "name": "Idaho",
        "abbreviation": "ID"
      },
      {
        "name": "Illinois",
        "abbreviation": "IL"
      },
      {
        "name": "Indiana",
        "abbreviation": "IN"
      },
      {
        "name": "Iowa",
        "abbreviation": "IA"
      },
      {
        "name": "Kansas",
        "abbreviation": "KS"
      },
      {
        "name": "Kentucky",
        "abbreviation": "KY"
      },
      {
        "name": "Louisiana",
        "abbreviation": "LA"
      },
      {
        "name": "Maine",
        "abbreviation": "ME"
      },
      {
        "name": "Marshall Islands",
        "abbreviation": "MH"
      },
      {
        "name": "Maryland",
        "abbreviation": "MD"
      },
      {
        "name": "Massachusetts",
        "abbreviation": "MA"
      },
      {
        "name": "Michigan",
        "abbreviation": "MI"
      },
      {
        "name": "Minnesota",
        "abbreviation": "MN"
      },
      {
        "name": "Mississippi",
        "abbreviation": "MS"
      },
      {
        "name": "Missouri",
        "abbreviation": "MO"
      },
      {
        "name": "Montana",
        "abbreviation": "MT"
      },
      {
        "name": "Nebraska",
        "abbreviation": "NE"
      },
      {
        "name": "Nevada",
        "abbreviation": "NV"
      },
      {
        "name": "New Hampshire",
        "abbreviation": "NH"
      },
      {
        "name": "New Jersey",
        "abbreviation": "NJ"
      },
      {
        "name": "New Mexico",
        "abbreviation": "NM"
      },
      {
        "name": "New York",
        "abbreviation": "NY"
      },
      {
        "name": "North Carolina",
        "abbreviation": "NC"
      },
      {
        "name": "North Dakota",
        "abbreviation": "ND"
      },
      {
        "name": "Northern Mariana Islands",
        "abbreviation": "MP"
      },
      {
        "name": "Ohio",
        "abbreviation": "OH"
      },
      {
        "name": "Oklahoma",
        "abbreviation": "OK"
      },
      {
        "name": "Oregon",
        "abbreviation": "OR"
      },
      {
        "name": "Palau",
        "abbreviation": "PW"
      },
      {
        "name": "Pennsylvania",
        "abbreviation": "PA"
      },
      {
        "name": "Puerto Rico",
        "abbreviation": "PR"
      },
      {
        "name": "Rhode Island",
        "abbreviation": "RI"
      },
      {
        "name": "South Carolina",
        "abbreviation": "SC"
      },
      {
        "name": "South Dakota",
        "abbreviation": "SD"
      },
      {
        "name": "Tennessee",
        "abbreviation": "TN"
      },
      {
        "name": "Texas",
        "abbreviation": "TX"
      },
      {
        "name": "Utah",
        "abbreviation": "UT"
      },
      {
        "name": "Vermont",
        "abbreviation": "VT"
      },
      {
        "name": "Virgin Islands",
        "abbreviation": "VI"
      },
      {
        "name": "Virginia",
        "abbreviation": "VA"
      },
      {
        "name": "Washington",
        "abbreviation": "WA"
      },
      {
        "name": "West Virginia",
        "abbreviation": "WV"
      },
      {
        "name": "Wisconsin",
        "abbreviation": "WI"
      },
      {
        "name": "Wyoming",
        "abbreviation": "WY"
      }
    ]

    return stateList;
  }

  searchInternalPatientFromDemographicLookup(hbsId, transactionId): Observable<any> {
    this.currentRetry = 0;
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "searchBy": "HBS_ID",
      "transId": transactionId,
      "requestedBy": this.user.userName,
      // "requestedBy": "testUser"
    }
    console.log("Internal patient search originated from Demographic lookup: HBS Id: " + hbsId + " transId: " + transactionId);

    // Retry count for demographic search
    this.retryCount = 5;
    this.isClearDisableReqFields = false;

    return this.httpClient.post(this.getInternalServerEndPoint() + environment.config.path.internalPatientSearch, JSON.stringify(data))
      .pipe(
        map(response => {
          if (response) {
            this.currentRetry = this.currentRetry + 1;
            console.log('Internal patient search api response: ', response);
            const data = JSON.stringify(response);
            const obj = JSON.parse(data);
            console.log('Internal patient search api response: ', obj.response.statusCode);
            // Return response only if status is 0000(Success) or 7701 (partial success)
            // Else continue retry as per logic
            if (obj.response.statusCode === '7701' || obj.response.statusCode === '0000') {
              console.log("Patient found, atleast one document found. status code: ", obj.response.statusCode);
              return response;
            }
            if (obj.response.statusCode === '7003') {
              console.log("No documents found, status code: ", obj.response.statusCode);
              return response;
            }
            if (obj.response.statusCode === '7000') {
              this.isClearDisableReqFields = true;
              console.log("Patient not found. status code: ", obj.response.statusCode);
              return response;
            }
            if (obj.response.statusCode === '7700' && this.currentRetry === 5) {
              this.isClearDisableReqFields = true;
              console.log("Retry count 5 but Patient search in progress. status code: ", obj.response.statusCode);
              return response;
            }
            throw response;
          }
          throw response;
        }),
        retryWhen(
          errors => {
            console.log('Error happened in calling internal patient search endpoint: ', errors);
            return errors.pipe(
              concatMap((error, iteration) =>
                iif(() => {
                  console.log("Current iteration for Quick lookup originated from Demographic lookup: ", iteration);
                  return iteration >= this.retryCount
                },
                  throwError(error),
                  of(error).pipe(delay(this.delay))
                )
              )
            )
          }
        )
      );

  }

  searchInternalPatient(hbsId, retryCondition): Observable<any> {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "searchBy": "HBS_ID",
      "transId": '',
      // "requestedBy": this.user.userName
      "requestedBy": "testUser"
    }
    if (retryCondition !== 'retryTrue') {
      this.spinnerService.show();
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.internalPatientSearch,
      JSON.stringify(data));
  }

  storeDemographicLookupOption(option) {
    sessionStorage.setItem('demoGraphicLookUpOption', option ? this.encryptDecrypt.aesEncrypt(JSON.stringify(option)) : JSON.stringify(option));
  }
  retrieveDemographicLookupOption() {
    const lookUpOption = sessionStorage.getItem('demoGraphicLookUpOption');
    return (lookUpOption && lookUpOption != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(lookUpOption)) : null;
  }

  storeTransactionIdForPolling(option) {
    sessionStorage.setItem('transactionId', option ? this.encryptDecrypt.aesEncrypt(JSON.stringify(option)) : JSON.stringify(option));
  }
  retrieveTransactionIdForPolling() {
    const transactionId = sessionStorage.getItem('transactionId');
    return (transactionId && transactionId != "null") ? JSON.parse(this.encryptDecrypt.aesDecrypt(transactionId)) : null;
  }

  searchInternalPatientWithTransactionId(hbsId, transId): Observable<any> {
    this.user = this.authService.getUser();
    var data = {
      "hbsId": hbsId,
      "searchBy": "HBS_ID",
      "transId": transId,
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"
    }
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.internalPatientSearch,
      JSON.stringify(data));
  }

  enableDemoFields() {
    const Demo_VAL = this.retrieveDemographicsInfo();
    if (Demo_VAL && Demo_VAL.addressline1) {
      Demo_VAL.addressline1 = null;
    }
    if (Demo_VAL && Demo_VAL.city) {
      Demo_VAL.city = null;
    }
    if (Demo_VAL && Demo_VAL.state) {
      Demo_VAL.state = null;
    }
    this.storeDemographicsInfo(Demo_VAL);
    this.setDemoFieldsStatus(true);
  }

  getDemoFieldsStatus(): Observable<boolean> {
    return this._enableDemoFields$
  }

  setDemoFieldsStatus(status: boolean) {
    return this._enableDemoFields.next(status);
  }

  storeResultBanner(banner) {
    sessionStorage.setItem('resultBanner', JSON.stringify(banner));
  }

  retrieveResultBanner() {
    const resultBanner = sessionStorage.getItem('resultBanner');
    return resultBanner ? JSON.parse(resultBanner) : null;
  }

  getResultBannerStatus(): Observable<boolean> {
    return this._enableResultBanner$;
  }

  setResultBannerStatus(status: boolean) {
    return this._enableResultBanner.next(status);
  }

  searchPatientByDemoRefresh(internalResource) {
    this.user = this.authService.getUser();
    this.spinnerService.show();
    let npi = null;
    let firstName = null;
    let lastName = null;
    let zipCode = null;
    if (internalResource.prescriber !== null) {
      npi = internalResource.prescriber.npi;
      firstName = internalResource.prescriber.firstName;
      lastName = internalResource.prescriber.lastName;
      zipCode = internalResource.prescriber.zipCode;
    }
    let gender = 'unknown';
    if (internalResource.gender === 'Female' || internalResource.gender === 'female') {
      gender = 'F';
    } else if (internalResource.gender === 'Male' || internalResource.gender === 'male') {
      gender = 'M';
    }
    var data = {
      "patient": {
        "address": {
          "addressLine1": internalResource.address.addressLine1,
          "addressLine2": internalResource.address.addressLine2,
          "city": internalResource.address.city,
          "state": internalResource.address.state,
          "zipCode": internalResource.address.zipCode
        },
        "dateOfBirth": internalResource.dateOfBirth,
        "gender": gender,
        "id": internalResource.id,
        "srcPatientId": internalResource.srcPatientId,
        "name": {
          "firstName": internalResource.name.firstName,
          "lastName": internalResource.name.lastName,
        },
        "prescriber": {
          "npi": npi,
          "firstName": firstName,
          "lastName": lastName,
          "zipCode": zipCode
        },
        "phNumber": internalResource.phNumber,
      },
      "requestedBy": this.user.userName
      // "requestedBy": "testUser"
    }
    console.log("New demographic patient search request: ", data);
    return this.httpClient.post(
      this.getInternalServerEndPoint() + environment.config.path.lookupPatientByDemo,
      JSON.stringify(data));
  }

}
