// import { TestBed } from '@angular/core/testing';
// import { environment } from '../../environments/environment';
// import { HttpClientModule } from '@angular/common/http';
// import { HttpClient  } from '@angular/common/http';
// import { SearchService } from './search.service';
// import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
// import { AuthService } from './auth.service';
// import { of } from 'rxjs';
// import { DatePipe } from '@angular/common';
// import { SpinnerService } from '../spinner/spinner.service';

// describe('SearchService', () => {
//     let service: SearchService;
//     let httpClient:HttpClient;
//     let httpMock: HttpTestingController;
//     beforeEach(() => {
//         TestBed.configureTestingModule({
//             imports: [HttpClientModule, HttpClientTestingModule],
//             providers: [ AuthService, SearchService, DatePipe, SpinnerService]
//         });
//         httpClient = TestBed.get(HttpClient);
//         httpMock = TestBed.get(HttpTestingController);
//         const authService: AuthService = TestBed.get(AuthService);
//         service = TestBed.get(SearchService);
//         const testUserName = '9326570';
//         // spyOn(authService, 'getUser').and.returnValue({ userName: testUserName });
//     });
    
//     it('should be created', () => {
//         expect(service).toBeTruthy();
//     });
//     it('should be able to search for new patient', () => {
//         const dateOfBirth = { YYYY: "1991", MM: "01", DD: "01" };
       
//         const searchDetails = {
//             "addressLine1": "1567 addressLine1",
//             "city": "prospect welfare",
//             "state": "MO",
//             "ZipCode": "34567",
//             "dob": dateOfBirth, //searchDetails.dob
//             "gender": "Female",
//             "HBSID": 123456,
//             "frstName": "jane",
//             "lstName": "Doe",
//             "Phone": "1234567890"
//         };
//         const data = {
//             "patient": {
//                 "address": {
//                     "addressLine1": "1567 addressLine1",
//                     "city": "prospect welfare",
//                     "state": "MO",
//                 },
//                 "dateOfBirth": "1991-01-01",
//                 "gender": "Female",
//                 "id": 123456,
//                 "name": {
//                     "firstName": "jane",
//                     "lastName": "Doe"
//                 },
//                 "phNumber": "1234567890"
//             },
//             "requestedBy": "9326570"
//         }
//         spyOn(httpClient, 'post').and.returnValue(of({}));
//         expect(service).toBeTruthy();
//         service.searchPatient(searchDetails);

//         expect(httpClient.post)
//             .toHaveBeenCalledWith(environment.config.serverEndPoint +
//                 environment.config.path.patientSearch,
//                 JSON.stringify(data));
//     });

//     it('should be able to search for new patient with external search service', () => {
//         const request = {
//             "addressLine1": "1567 addressLine1",
//             "city": "prospect welfare",
//             "state": "MO",
//             "ZipCode": "34567",
//             "dob": "12/12/2019", //searchDetails.dob
//             "gender": "Female",
//             "HBSID": 123456,
//             "frstName": "jane",
//             "lstName": "Doe",
//             "Phone": "1234567890"
//         };
//         const resStr = '{"response":{"resources":[{"id":"123456","gender":"female","dateOfBirth":"1992-01-12","phNumber":null,"surescriptsId":"237460442","assigningAuthority":"2.16.840.1.113883.3.2054.2.1","name":{"firstName":"PEGGY","lastName":"PONCE","middleName":null,"prefix":null,"suffix":null},"address":{"addressLine1":"9522 Cody Dr","addressLine2":null,"city":"Saint Louis","state":"MO","zipCode":"63132"},"docRefs":null}],"statusDesc":"Success","statusCode":"0000","requestedBy":"9326539"}}';
        
//         const response =  JSON.parse(resStr);
        
//         service.advancedPatientSearch(request).subscribe((res:any)=>{
            
//             expect(res.response.statusCode).not.toBeNull();
//             expect(res.response.statusCode).toEqual("0000");
//             expect(res.response.statusDesc).toEqual("Success");
//             expect(res.response.requestedBy).toEqual("9326539");
//             expect(res.response.resources[0].name.firstName).toEqual("PEGGY");
//             expect(res.response.resources[0].name.lastName).toEqual("PONCE");
//             expect(res.response.resources[0].gender).toEqual("female");
//             expect(res.response.resources[0].id).toEqual("123456");
//             expect(res.response.resources[0].dateOfBirth).toEqual("1992-01-12");
//             expect(res.response.resources[0].phNumber).toBeNull;
//             expect(res.response.resources[0].surescriptsId).toEqual("237460442");
//             expect(res.response.resources[0].assigningAuthority).toEqual("2.16.840.1.113883.3.2054.2.1");
//             expect(res.response.resources[0].address.addressLine1).toEqual("9522 Cody Dr");
//             expect(res.response.resources[0].address.addressLine2).toBeNull;
//             expect(res.response.resources[0].address.city).toEqual("Saint Louis");
//             expect(res.response.resources[0].address.state).toEqual("MO");
//             expect(res.response.resources[0].address.zipCode).toEqual("63132");

//         }
//         );
//         const postService = httpMock.expectOne(environment.config.serverEndPoint +
//             environment.config.path.patientSearch);
//         expect(postService.request.method).toBe("POST");
//         postService.flush(response);
//     });
// });
