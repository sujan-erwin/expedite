import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';

describe('authService', () => {
  let service: AuthService;
  let httpClient: HttpTestingController;
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      AuthService,
      HttpClient
    ],
    imports:[HttpClientTestingModule]

  }));

  it('should be created', () => {
    const service: AuthService = TestBed.get(AuthService);
    expect(service).toBeTruthy();
  });
});
