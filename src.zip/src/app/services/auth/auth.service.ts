import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn: boolean;
  userProfile: any;
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };

  constructor(
    private httpClient: HttpClient,
  ) {
    this.isLoggedIn = false;
  }

  authenticate(userDetails) {
    var data = {};
    data['authRequest'] = {}
    data['authRequest']['userName'] = userDetails.email;
    data['authRequest']['password'] = userDetails.password;
    var response = this.httpClient.post(
      environment.config.serverEndPoint + environment.config.path.loginAuthentication, JSON.stringify(data), this.options)
    return response;
  }

  updateUserProfile(user: any) {
    this.userProfile = user;
    sessionStorage.setItem('userProfile', btoa(user));
  }

  getUserProfile() {
    this.getUser();
    return this.userProfile;
  }

  getUser(): any {

    let user = sessionStorage.getItem('user');

    try {
      user = JSON.parse(user);
    } catch (e) {
      user = null;
    }

    this.userProfile = user;
    return user;
  }
}
