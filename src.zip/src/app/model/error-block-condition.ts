export interface errorBlockConditions {
  conditionsErrTitle: any,
  conditionsErrMsg: any,
  status: number;
  isConditionsErr: boolean
  statusRetry: boolean;
}
