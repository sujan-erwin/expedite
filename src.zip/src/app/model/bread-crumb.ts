export class BreadCrumb {
    label: string;
    link: string;
    isLink: boolean;
}
