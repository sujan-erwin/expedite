export class MedicationsMapper {
    flattenMedication(medication: any, index: number){
        const result = {
          id: '',
          label: '',
          qty: '',
          instructions: '',
          indications: '',
          unit: '',
          startDate: '',
          endDate: '',
          prescriber: ''
        }
    
        result.id = index.toString();
        result.label = Array.isArray(medication.medicationCodeableConcept?.coding)
          ? medication.medicationCodeableConcept.text
          : '';
          result.qty = medication.dispenseRequest?.quantity
          ? medication.dispenseRequest.quantity.value
          : '';
          result.unit = medication.dispenseRequest?.quantity
          ? medication.dispenseRequest.quantity.unit
          : '';
          result.startDate = Array.isArray(medication.dosageInstruction)
          ? medication.dosageInstruction[0]?.timing?.repeat?.boundsPeriod?.start
          : '';
          result.endDate = Array.isArray(medication.dosageInstruction)
          ? medication.dosageInstruction[0]?.timing?.repeat?.boundsPeriod?.end
          : '';
          result.indications = Array.isArray(medication.reasonCode)
          ? medication.reasonCode[0]?.text
          : '';
          result.prescriber = medication.requester
          ? medication.requester.display 
          : '';
        result.instructions = Array.isArray(medication.dosageInstruction)
          ? medication.dosageInstruction[0]?.text
          : '';
        return result
      }
}
