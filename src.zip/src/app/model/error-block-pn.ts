export interface errorBlockPN {
  progressNotesErrTitle: string;
  progressNotesErrMsg: string;
  isProgressNotesErr: boolean;
  status: number;
  statusRetry: boolean;
}
