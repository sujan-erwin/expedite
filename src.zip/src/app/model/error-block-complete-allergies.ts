export interface errorBlockCompleteAllergies {
  completeAllergiesErrTitle: any,
  completeAllergiesErrMsg: any,
  isCompleteAllergiesErr: boolean,
  status: number;
  statusRetry: boolean;
}
