export interface errorBlockCompleteConditions {
  completeConditionsErrTitle: any,
  completeConditionsErrMsg: any,
  isCompleteConditionsErr: boolean,
  status: number;
  statusRetry: boolean;
}
