export interface errorBlockAllergies {
  allergiesErrTitle: any,
  allergiesErrMsg: any,
  isAllergiesErr: boolean,
  status: number;
  statusRetry: boolean;
}
