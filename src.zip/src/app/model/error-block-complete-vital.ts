export interface errorBlockCompleteVitals {
  completeVitalsErrTitle: any,
  completeVitalsErrMsg: any,
  isCompleteVitalsErr: boolean,
  status: number;
  statusRetry: boolean;
}
