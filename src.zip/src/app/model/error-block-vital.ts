export interface errorBlockVitals {
  vitalsErrTitle: any,
  vitalsErrMsg: any,
  status: number;
  isVitalsErr: boolean
  statusRetry: boolean;
}
