export interface errorBlock {
  medicationsErrTitle: any,
  medicationsErrMsg: any,
  isMedicationsErr: boolean,
  status: number;
  statusRetry: boolean;
}
