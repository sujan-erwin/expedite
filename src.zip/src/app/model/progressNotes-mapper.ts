export class ProgressNotesMapper {
    flattenProgressNotes(progressNotes: any, index: number){
        const result = {
          id: '',
          type: '',
          period: '',
          practitionerName: '',
          institution: '',
          specialty: '',
          description: '',
        }
    
        result.id = index.toString();
        result.type = Array.isArray(progressNotes.type?.type)
          ? progressNotes.type.text
          : '';
          result.practitionerName = progressNotes.practitionerRole?.code
          ? progressNotes.practitionerRole.code.text
          : '';
          result.institution = progressNotes.institution?.name
          ? progressNotes.institution.name
          : '';
          result.specialty = progressNotes.specialty?.name
          ? progressNotes.specialty.name
          : '';
          result.period = progressNotes.period?.start
          ? progressNotes.period.start
          : '';
          result.description = progressNotes.composition?.section
          ? progressNotes.composition.section.text
          : '';
        return result
      }
}
