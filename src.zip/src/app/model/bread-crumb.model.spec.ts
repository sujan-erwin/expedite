import { BreadCrumb } from './bread-crumb.model';

describe('BreadCrumb', () => {
  it('should create an instance', () => {
    expect(new BreadCrumb()).toBeTruthy();
  });
});
