import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { PatientDocumentsComponent } from './patient-documents.component';
import { PatientDocumentService } from '../services/patientDocument.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthService } from '../services/auth.service';
import { DatePipe, CommonModule } from '@angular/common';
import { SpinnerService } from '../spinner/spinner.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { SearchService } from '../services/search.service';
import {Observable } from 'rxjs/Observable';
import { first } from 'rxjs/operators';
import {By} from "@angular/platform-browser";
import { pseudoRandomBytes } from 'crypto';
import { of } from 'rxjs/Observable/of';
import { Component } from '@angular/core';



describe('PatientDocumentsComponent', () => {
  let component: PatientDocumentsComponent;
  let fixture: ComponentFixture<PatientDocumentsComponent>;
  let httpClient: HttpTestingController;
  let dom: HTMLElement;
  const firstName = 'Jon', lastName = 'Doe', dateOfBirth = '12/21/2000', ssId = "ssId", assigningAuthority = 'assigningAuthority', id = 'id';
  const testUserName = '9025804', gender='Female', addressline1="123 Prospect Ln", city="Chicago", zipcode="12345", state="IL"
  let docList = '{"docRefs":[{"id":"2.16.840.1.113883.3.2054.2.1.187635031","title":"Surescripts Location Summary","status":"current","createdDate":"2020-01-22T15:41:38+00:00","encounterDate":"2020-01-22T15:41:38+00:00","type":"Location Summary","orgName":"Surescripts","digitalId":"1", "viewStatus":"view","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.187635031&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","data":null}]}';
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientDocumentsComponent ],
      providers: [AuthService,PatientDocumentService, DatePipe, SpinnerService],
      imports: [FormsModule, ReactiveFormsModule, RouterTestingModule,HttpClientModule,HttpClientTestingModule ],
      
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const searchService: SearchService = TestBed.get(SearchService);
    const pSevice: PatientDocumentService = TestBed.get(PatientDocumentService);
    const httpClient: HttpClient = TestBed.get(HttpClient);
    const authService: AuthService = TestBed.get(AuthService);
    const response = {
        "name": {
          "firstName": firstName,
          "lastName": lastName,
        },
        "id": id,
        "dateOfBirth": dateOfBirth,
        "surescriptsId": ssId,
        "assigningAuthority": assigningAuthority,
      "requestedBy": testUserName
    };
    const patient ={
      "firstName": firstName,
      "lastName": lastName,
      "gender":gender,
      "dob":dateOfBirth,
      "addressline1": addressline1,
      "city":city,
      "zipCode":zipcode,
      "state":state

    }
    //const serResponse = '{"response":{"resources":[{"id":"1234567890","gender":null,"dateOfBirth":"1991-01-12","phNumber":null,"surescriptsId":"34001201","assigningAuthority":"2.16.840.1.113883.3.2054.2.1","name":{"firstName":"PEGGY","lastName":"PONCE","middleName":null,"prefix":null,"suffix":null},"address":null,"docRefs":[{"id":"2.16.840.1.113883.3.2054.2.1.187635031","title":"Surescripts Location Summary","status":"current","createdDate":"2020-01-22T15:41:38+00:00","type":"Location Summary","orgName":"Surescripts","url":"/Binary?documentId=2.16.840.1.113883.3.2054.2.1.187635031&repositoryId=2.16.840.1.113883.3.2054.2.1&homeCommunityId=2.16.840.1.113883.3.2054.2.1","contentType":"text/xml","data":null}]}],"statusDesc":"Success","statusCode":"0000","requestedBy":"8953499"}}';
    // spyOn(authService, 'getUser').and.returnValue({ userName: testUserName });
    spyOn(httpClient, 'post').and.returnValue(of({}));
    spyOn(searchService, 'getPatient').and.returnValue(patient);
    spyOn(searchService, 'getResourceToPatient').and.returnValue(patient);
    spyOn(searchService, 'getResource').and.returnValue(response);
    spyOn(pSevice, 'getExternalDocList').and.returnValue(JSON.parse(docList).docRefs);
   
    //'{"response":{"resources":[{"id":"2.16.840.1.113883.3.2054.2.1.187648871","content":"PCFET0NUWVBFIGh0bWwgUFVCTElDICItLy9XM0MvL0RURCBIVE1MIDQuMDEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvVFIvaHRtbDQvc3RyaWN0LmR0ZCI+CjxodG1sIHhtbG5zOmluPSJ1cm46bGFudGFuYS1jb206aW5saW5lLXZhcmlhYmxlLWRhdGEiIHhtbG5zOm4xPSJ1cm46aGw3LW9yZzp2MyI+PGhlYWQ+PE1FVEEgaHR0cC1lcXVpdj0iQ29udGVudC1UeXBlIiBjb250ZW50PSJ0ZXh0L2h0bWw7IGNoYXJzZXQ9SVNPLTg4NTktMSI+PCEtLSBEbyBOT1QgZWRpdCB0aGlzIEhUTUwgZGlyZWN0bHk6IGl0IHdhcyBnZW5lcmF0ZWQgdmlhIGFuIFhTTFQgdHJhbnNmb3JtYXRpb24gZnJvbSBhIENEQSBSZWxlYXNlIDIgWE1MIGRvY3VtZW50LiAtLT48dGl0bGU+U3VyZXNjcmlwdHMgTG9jYXRpb24gU3VtbWFyeTwvdGl0bGU+PHN0eWxlIHR5cGU9InRleHQvY3NzIj4KYm9keSB7CiAgY29sb3I6ICMwMDMzNjY7CiAgYmFja2dyb3VuZC1jb2xvcjogI0ZGRkZGRjsKICBmb250LWZhbWlseTogVmVyZGFuYSwgVGFob21hLCBzYW5zLXNlcmlmOwogIGZvbnQtc2l6ZTogMTFweDsKfQoKYSB7CiAgY29sb3I6ICMwMDMzNjY7CiAgYmFja2dyb3VuZC1jb2xvcjogI0ZGRkZGRjsKfQoKaDEgewogIGZvbnQtc2l6ZTogMTJwdDsKICBmb250LXdlaWdodDogYm9sZDsKfQoKaDIgewogIGZvbnQtc2l6ZTogMTFwdDsKICBmb250LXdlaWdodDogYm9sZDsKfQoKaDMgewogIGZvbnQtc2l6ZTogMTBwdDsKICBmb250LXdlaWdodDogYm9sZDsKfQoKaDQgewogIGZvbnQtc2l6ZTogOHB0OwogIGZvbnQtd2VpZ2h0OiBib2xkOwp9CgoKdGFibGUgewogIGxpbmUtaGVpZ2h0OiAxMHB0OwogIHdpZHRoOiAxMDAlOwp9Cgp0aCB7CiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZDcwMDsKfQoKdGQgewogIHBhZGRpbmc6IDAuMWNtIDAuMmNtOwogIHZlcnRpY2FsLWFsaWduOiB0b3A7CiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZjYzsKfQoKLmgxY2VudGVyIHsKICBmb250LXNpemU6IDEycHQ7CiAgZm9udC13ZWlnaHQ6IGJvbGQ7CiAgdGV4dC1hbGlnbjogY2VudGVyOwogIHdpZHRoOiA4MCU7Cn0KCi5oZWFkZXJfdGFibGV7CiAgYm9yZGVyOiAxcHQgaW5zZXQgIzAwMDA4YjsKfQoKLnRkX2xhYmVsewogIGZvbnQtd2VpZ2h0OiBib2xkOwogIGNvbG9yOiB3aGl0ZTsKfQoKLnRkX2hlYWRlcl9yb2xlX25hbWV7CiAgd2lkdGg6IDIwJTsKICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzM5OWZmOwp9CgoudGRfaGVhZGVyX3JvbGVfdmFsdWV7CiAgd2lkdGg6IDgwJTsKICBiYWNrZ3JvdW5kLWNvbG9yOiAjY2NjY2ZmOwp9CgouQm9sZHsKICBmb250LXdlaWdodDogYm9sZDsKfQoKLkl0YWxpY3N7CiAgZm9udC1zdHlsZTogaXRhbGljOwp9CgouVW5kZXJsaW5lewogIHRleHQtZGVjb3JhdGlvbjp1bmRlcmxpbmU7Cn0KCiAgICAgICAgICA8L3N0eWxlPjwvaGVhZD48Ym9keT48aDEgY2xhc3M9ImgxY2VudGVyIj5TdXJlc2NyaXB0cyBMb2NhdGlvbiBTdW1tYXJ5PC9oMT48dGFibGUgY2xhc3M9ImhlYWRlcl90YWJsZSI+PHRyPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfbmFtZSI+PHNwYW4gY2xhc3M9InRkX2xhYmVsIj5QYXRpZW50PC9zcGFuPjwvdGQ+PHRkIGNsYXNzPSJ0ZF9oZWFkZXJfcm9sZV92YWx1ZSI+UGVnZ3kgUG9uY2U8L3RkPjwvdHI+PHRyPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfbmFtZSI+PHNwYW4gY2xhc3M9InRkX2xhYmVsIj5EYXRlIG9mIGJpcnRoPC9zcGFuPjwvdGQ+PHRkIGNsYXNzPSJ0ZF9oZWFkZXJfcm9sZV92YWx1ZSI+SmFudWFyeSAxMiwgMTk5MSA8L3RkPjwvdHI+PHRyPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfbmFtZSI+PHNwYW4gY2xhc3M9InRkX2xhYmVsIj5TZXg8L3NwYW4+PC90ZD48dGQgY2xhc3M9InRkX2hlYWRlcl9yb2xlX3ZhbHVlIj5GZW1hbGU8L3RkPjwvdHI+PHRyPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfbmFtZSI+PHNwYW4gY2xhc3M9InRkX2xhYmVsIj5Db250YWN0IGluZm88L3NwYW4+PC90ZD48dGQgY2xhc3M9InRkX2hlYWRlcl9yb2xlX3ZhbHVlIj45NTIyIENvZHkgRHI8YnI+T2xpdmV0dGUsJm5ic3A7TU8mbmJzcDs2MzEzMiwmbmJzcDtVUzxicj48YnI+PC90ZD48L3RyPjx0cj48dGQgY2xhc3M9InRkX2hlYWRlcl9yb2xlX25hbWUiPjxzcGFuIGNsYXNzPSJ0ZF9sYWJlbCI+UGF0aWVudCBJRHM8L3NwYW4+PC90ZD48dGQgY2xhc3M9InRkX2hlYWRlcl9yb2xlX3ZhbHVlIj4zNDAwMTIwMSAyLjE2Ljg0MC4xLjExMzg4My4zLjIwNTQuMi4xPGJyPjwvdGQ+PC90cj48L3RhYmxlPjx0YWJsZSBjbGFzcz0iaGVhZGVyX3RhYmxlIj48dGJvZHk+PHRyPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfbmFtZSI+PHNwYW4gY2xhc3M9InRkX2xhYmVsIj5Eb2N1bWVudCBJZDwvc3Bhbj48L3RkPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfdmFsdWUiPjIuMTYuODQwLjEuMTEzODgzLjMuMjA1NC4yLjEuMTg3NjQ4ODcxIDIuMTYuODQwLjEuMTEzODgzLjMuMjA1NC4yLjE8L3RkPjwvdHI+PHRyPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfbmFtZSI+PHNwYW4gY2xhc3M9InRkX2xhYmVsIj5Eb2N1bWVudCBDcmVhdGVkOjwvc3Bhbj48L3RkPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfdmFsdWUiPkphbnVhcnkgMjksIDIwMjAsIDE1OjQzOjQ3ICA8L3RkPjwvdHI+PC90Ym9keT48L3RhYmxlPjx0YWJsZSBjbGFzcz0iaGVhZGVyX3RhYmxlIj48dGJvZHk+PC90Ym9keT48L3RhYmxlPjx0YWJsZSBjbGFzcz0iaGVhZGVyX3RhYmxlIj48dGJvZHk+PHRyPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfbmFtZSI+PHNwYW4gY2xhc3M9InRkX2xhYmVsIj5BdXRob3I8L3NwYW4+PC90ZD48dGQgY2xhc3M9InRkX2hlYWRlcl9yb2xlX3ZhbHVlIj5TdXJlc2NyaXB0cyBOUkxTPC90ZD48L3RyPjx0cj48dGQgY2xhc3M9InRkX2hlYWRlcl9yb2xlX25hbWUiPjxzcGFuIGNsYXNzPSJ0ZF9sYWJlbCI+Q29udGFjdCBpbmZvPC9zcGFuPjwvdGQ+PHRkIGNsYXNzPSJ0ZF9oZWFkZXJfcm9sZV92YWx1ZSI+OTIwIDJuZCBBdmVudWUgU291dGg8YnI+U3VpdGUgNDAwPGJyPk1pbm5lYXBvbGlzLCZuYnNwO01OJm5ic3A7NTU0MDIsJm5ic3A7VVM8YnI+PGJyPjwvdGQ+PC90cj48L3Rib2R5PjwvdGFibGU+PHRhYmxlIGNsYXNzPSJoZWFkZXJfdGFibGUiPjx0Ym9keT48dHI+PHRkIGNsYXNzPSJ0ZF9oZWFkZXJfcm9sZV9uYW1lIj48c3BhbiBjbGFzcz0idGRfbGFiZWwiPkRvY3VtZW50IG1haW50YWluZWQgYnk8L3NwYW4+PC90ZD48dGQgY2xhc3M9InRkX2hlYWRlcl9yb2xlX3ZhbHVlIj5TdXJlc2NyaXB0czwvdGQ+PC90cj48dHI+PHRkIGNsYXNzPSJ0ZF9oZWFkZXJfcm9sZV9uYW1lIj48c3BhbiBjbGFzcz0idGRfbGFiZWwiPkNvbnRhY3QgaW5mbzwvc3Bhbj48L3RkPjx0ZCBjbGFzcz0idGRfaGVhZGVyX3JvbGVfdmFsdWUiPjkyMCAybmQgQXZlbnVlIFNvdXRoPGJyPlN1aXRlIDQwMDxicj5NaW5uZWFwb2xpcywmbmJzcDtNTiZuYnNwOzU1NDAyLCZuYnNwO1VTPGJyPjxicj48L3RkPjwvdHI+PC90Ym9keT48L3RhYmxlPjxociBhbGlnbj0ibGVmdCIgY29sb3I9InRlYWwiIHNpemU9IjIiPjxoMz5TdXJlc2NyaXB0cyBMb2NhdGlvbiBTdW1tYXJ5PC9oMz48ZGl2PjxwPlRoZSBmb2xsb3dpbmcgaXMgYSBsaXN0IG9mIHBvc3NpYmxlIGxvY2F0aW9ucyB3aGVyZSB0aGlzIHBhdGllbnQgbWF5IGhhdmUgcmVjb3Jkcy4gQ2VydGFpbiBpbmZvcm1hdGlvbiBtYXkgbm90IGJlIGFjY3VyYXRlIG9yIGF2YWlsYWJsZSBpbiB0aGlzIHJlcG9ydCwgaW5jbHVkaW5nIGl0ZW1zIHRoYXQgdGhlIHBhdGllbnQgYXNrZWQgbm90IGJlIGRpc2Nsb3NlZCBkdWUgdG8gcGF0aWVudCBwcml2YWN5IGNvbmNlcm5zLCB2aXNpdHMgbm90IGNvdmVyZWQgYnkgY3VycmVudCBkYXRhIHJpZ2h0cyBjb3ZlcmFnZSwgb3Igb3JnYW5pemF0aW9uIG9yIHByb3ZpZGVyIGluZm9ybWF0aW9uIG5vdCB1cC10by1kYXRlIGluIHRoZSBOYXRpb25hbCBQcm92aWRlciBJZGVudGlmaWVyIGxpc3RpbmcuIFRoZSBwcm92aWRlciBzaG91bGQgaW5kZXBlbmRlbnRseSB2ZXJpZnkgY2xpbmljYWwgdmlzaXQgaGlzdG9yeSB3aXRoIHRoZSBwYXRpZW50LjwvcD48dGFibGU+PHRoZWFkPjx0cj48dGg+RGF0ZTwvdGg+PHRoPk9yZ2FuaXphdGlvbiBOYW1lPC90aD48dGg+TGFzdCBOYW1lPC90aD48dGg+Rmlyc3QgTmFtZTwvdGg+PHRoPlN1ZmZpeDwvdGg+PHRoPlNwZWNpYWx0eTwvdGg+PHRoPkFkZHJlc3M8L3RoPjx0aD5DaXR5PC90aD48dGg+U3RhdGU8L3RoPjx0aD5aaXA8L3RoPjx0aD5QaG9uZTwvdGg+PHRoPlByb3ZpZGVyIE5QSTwvdGg+PC90cj48L3RoZWFkPjx0Ym9keT48dHI+PHRkPjAxLzE0LzIwMTY8L3RkPjx0ZD5FTExFTiBQQUdFPC90ZD48dGQ+UEFHRTwvdGQ+PHRkPkVMTEVOPC90ZD48dGQ+PC90ZD48dGQ+PC90ZD48dGQ+Mzg1OSBNYWluIFN0PC90ZD48dGQ+T2xpdmV0dGU8L3RkPjx0ZD5NTzwvdGQ+PHRkPjYzMTMyPC90ZD48dGQ+KDcxMikgNDQ0LTMzMzM8L3RkPjx0ZD4xOTM0ODcxMjMxPC90ZD48L3RyPjx0cj48dGQ+MTIvMDQvMjAxNTwvdGQ+PHRkPkVMTEVOIFBBR0U8L3RkPjx0ZD5QQUdFPC90ZD48dGQ+RUxMRU48L3RkPjx0ZD48L3RkPjx0ZD48L3RkPjx0ZD4zODU5IE1haW4gU3Q8L3RkPjx0ZD5PbGl2ZXR0ZTwvdGQ+PHRkPk1PPC90ZD48dGQ+NjMxMzI8L3RkPjx0ZD4oNzEyKSA0NDQtMzMzMzwvdGQ+PHRkPjE5MzQ4NzEyMzE8L3RkPjwvdHI+PHRyPjx0ZD4wNy8wNy8yMDE1PC90ZD48dGQ+UHJvdmlkZXIgUGljdHVyZXM8L3RkPjx0ZD5IZXJuYW5kZXo8L3RkPjx0ZD5XaWxtYTwvdGQ+PHRkPjwvdGQ+PHRkPjwvdGQ+PHRkPjMxMDcgUm9kbmV5IFN0cmVldDwvdGQ+PHRkPk9saXZldHRlPC90ZD48dGQ+TU88L3RkPjx0ZD42MzEzMjwvdGQ+PHRkPig2MTcpIDQ1NS00NTU1PC90ZD48dGQ+NDkxODA5MTM1MTwvdGQ+PC90cj48dHI+PHRkPjExLzEwLzIwMTQ8L3RkPjx0ZD5FTExFTiBQQUdFPC90ZD48dGQ+UEFHRTwvdGQ+PHRkPkVMTEVOPC90ZD48dGQ+PC90ZD48dGQ+PC90ZD48dGQ+Mzg1OSBNYWluIFN0PC90ZD48dGQ+T2xpdmV0dGU8L3RkPjx0ZD5NTzwvdGQ+PHRkPjYzMTMyPC90ZD48dGQ+KDcxMikgNDQ0LTMzMzM8L3RkPjx0ZD4xOTM0ODcxMjMxPC90ZD48L3RyPjwvdGJvZHk+PC90YWJsZT48L2Rpdj48YnI+PGJyPjwvYm9keT48L2h0bWw+"}],"statusDesc":"Success","statusCode":"0000"}}'
    fixture = TestBed.createComponent(PatientDocumentsComponent);
    component = fixture.componentInstance;
    dom = fixture.debugElement.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have Patient details', () => {
    let patient = fixture.nativeElement.querySelector('#patient');
    expect(patient).not.toBeNull;
  });
  it('should have Patient first name', () => {
    let patient = dom.querySelector('#patientName').innerHTML
    expect(patient).toContain(firstName);
  });
  it('should have last name', () => {
    let patient = dom.querySelector('#patientName').innerHTML
    expect(patient).toContain(lastName);
  });
  it('should have all patient details', () => {
    let list = dom.querySelector('ul');
  });
  it('should have DOB', () => {
    let patient = dom.querySelector('ul').innerHTML
    expect(patient).toContain(dateOfBirth);
  });
  it('should have gender', () => {
    let patient = dom.querySelector('ul').innerHTML
    expect(patient).toContain(gender);
  });
  it('should have address', () => {
    let patient = dom.querySelector('ul').innerHTML
    expect(patient).toContain(addressline1);
  });
  it('should have city', () => {
    let patient = dom.querySelector('ul').innerHTML
    expect(patient).toContain(city);
  });
  it('should have state', () => {
    let patient = dom.querySelector('ul').innerHTML
    expect(patient).toContain(state);
    expect(patient).toContain(zipcode);
  });

  it('should have List of documents', () => {
    expect(component.docList.length).toEqual(JSON.parse(docList).docRefs.length);
  });

  it('should match document count and table rows', () => {
    let tableRows = fixture.nativeElement.querySelectorAll('tr');
    expect(component.docList.length+1).toEqual(tableRows.length);
  });

  it('Table should have headers', () => {
    let tableRows = fixture.nativeElement.querySelectorAll('tr');
    let headerRow = tableRows[0];
    expect(headerRow.cells[0].innerHTML).toContain('Encounter date');
    expect(headerRow.cells[1].innerHTML).toContain('Organization');
    expect(headerRow.cells[2].innerHTML).toContain('Provider');
    expect(headerRow.cells[3].innerHTML).toContain('Type');
    expect(headerRow.cells[4].innerHTML).toContain('Status');
  });

  it('Table should have values', () => {
    let tableRows = fixture.nativeElement.querySelectorAll('tr');
    let data = JSON.parse(docList).docRefs;
    for(var i = 1;i<tableRows.length;i++){
      let row = tableRows[i];
      let date = data[i-1].createdDate;
      let pipe = new DatePipe('en');
      date = pipe.transform(new Date(date), 'MM/dd/yyyy');
      expect(row.cells[0].innerHTML).toContain(date);
      expect(row.cells[1].innerHTML).toContain(data[i-1].orgName);
      expect(row.cells[2].innerHTML).not.toContain(data[i-1].title);
      expect(row.cells[3].innerHTML).toContain(data[i-1].type);
      expect(row.cells[4].innerHTML).toContain(data[i-1].viewStatus);
    }
    
  });

  it('View link is visible', () => {
    let tableRows = fixture.nativeElement.querySelectorAll('tr');
    for(var i = 1;i<tableRows.length;i++){
      let row = tableRows[i];
      expect(row.cells[4].innerHTML).toContain('View');
      expect(row.cells[4].innerHTML).toContain('<a');
    }
  });

  it('View link is clicked', () => {
    spyOn(component, 'openDocument');
      let ele = fixture.debugElement.nativeElement.querySelector('td a');
      ele.click();
    fixture.detectChanges();
   expect(component.openDocument).toHaveBeenCalled();
  });

 
  it('View link is on failure, view should change to retry', () => {
    const pSevice: PatientDocumentService = TestBed.get(PatientDocumentService);
    spyOn(pSevice, 'getDocument').and.returnValue(
      of({response:{statusCode:'1234'}})
    );
    let tableRows = fixture.nativeElement.querySelectorAll('tr');
    let row = tableRows[1];
    let ele = fixture.debugElement.nativeElement.querySelector('td a');
    ele.click();
  fixture.detectChanges();
  expect(row.cells[4].innerHTML).toContain('retry');
  }); 

  it('View link is on failure, after 3 retry, retry should change to error', () => {
    let tableRows = fixture.nativeElement.querySelectorAll('tr');
    const pSevice: PatientDocumentService = TestBed.get(PatientDocumentService);
    spyOn(pSevice, 'getDocument').and.returnValue(
      of({response:{statusCode:'4545'}})
    );
      let row = tableRows[1];
      let ele = fixture.debugElement.nativeElement.querySelector('td a');
      ele.click();
    fixture.detectChanges();
    ele.click();
    fixture.detectChanges();
    ele.click();
    fixture.detectChanges();
    ele.click();
    fixture.detectChanges();
    expect(row.cells[4].innerHTML).toContain('Error');
  }); 

  it('View link is on success, view should change to viewed', () => {
    const pSevice: PatientDocumentService = TestBed.get(PatientDocumentService);
    spyOn(pSevice, 'getDocument').and.returnValue(
      of({response:{statusCode:'0000'}})
    );
    fixture.whenStable().then(()=>{
      let tableRows = fixture.nativeElement.querySelectorAll('tr');
      let row = tableRows[1];
      let ele = fixture.debugElement.nativeElement.querySelector('td a');
      ele.click();
    fixture.detectChanges();
    expect(row.cells[4].innerHTML).toContain('viewed');
    });  
  });

  it('When no documents are return, show no document found banner', () => {
    
    docList = '{"docRefs":[]}';
    jasmine.getEnv().allowRespy(true);
    const pSevice: PatientDocumentService = TestBed.get(PatientDocumentService);
    spyOn(pSevice, 'getDocList').and.returnValue(JSON.parse(docList).docRefs);
    // spyOn(pSevice, 'getDocumentList').and.returnValue(
    //   of({response:{statusCode:'7003'}})
    // );
    fixture.whenStable().then(() => { 
      
      fixture = TestBed.createComponent(PatientDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    expect(component.docList).toBeNull;
    expect(component.result.display).toBeTruthy;
    });
    
  }); 


});


