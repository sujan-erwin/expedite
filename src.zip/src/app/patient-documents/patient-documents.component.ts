import { Component, OnInit, OnDestroy } from '@angular/core';
import { SearchService } from '../services/search.service';
import { Router } from '@angular/router';
import { allPaths } from '../app-routes';
import { PatientDocumentService } from '../services/patientDocument.service';
import { errorBanners } from '../error-messages';
import { supportsPassiveEventListeners } from '@angular/cdk/platform';
import { DatePipe, LocationStrategy } from '@angular/common';
import { SpinnerService } from '../spinner/spinner.service';
import { Title } from '@angular/platform-browser';


@Component({
  selector: 'app-patient-documents',
  templateUrl: './patient-documents.component.html',
  styleUrls: ['./patient-documents.component.scss']
})
export class PatientDocumentsComponent implements OnInit, OnDestroy {

  patient: any;
  advanceSearchdocList: any;
  docList: any;
  result: any;
  isNotAllDocsAvailable: boolean = false;
  statusCode: any;

  constructor(private searchService: SearchService, private patientDocService: PatientDocumentService, private spinnerService: SpinnerService, private router: Router, private titleService: Title) {
    this.result = {};
    this.result.display = false;
    this.titleService.setTitle("Dataviewer - Patient Documents Results");
    this.handleDocumentsResponse();
  }
  handleDocumentsResponse() {
    this.patient = this.searchService.getResourceToPatient();
    this.getDocList(this.searchService.getResource());
  }
  sortList(list) {
    if (list) {
      let sortOrder = {
        1: ["Continuity of Care Document", "Summarization of episode note", "Ambulatory Summary", "Summary of episode note"],
        2: "Location Summary"
      };//Keep all the order in lower case
      let ccdList = list.filter(function (item) {
        return item.typeCode === '34133-9' &&
          (
            item.type.includes(sortOrder[1][0]) ||
            item.type.includes(sortOrder[1][1]) ||
            item.type.includes(sortOrder[1][2]) ||
            item.type.includes(sortOrder[1][3])
          );
      });
      if (ccdList) {
        ccdList = ccdList.sort(function (a, b) {
          return a.orgName > b.orgName ? 1 : a.orgName < b.orgName ? -1 : 0;
        });
      }
      let ssLSumList = list.filter(function (item) {
        return item.typeCode === '34133-9' && item.type.includes(sortOrder[2]);
      });
      let nonCCDList = list.filter(function (item) {
        return !(ccdList.includes(item) || ssLSumList.includes(item))
      });
      list = [].concat(ccdList, nonCCDList, ssLSumList);
    }
    return list;
  }

  getDocList(resource) {
    if (resource) {
      let list = resource.docRefs;
      if(list && list.length > 0){
      list = list.filter(doc => doc.contentType == "text/xml");
      this.isNotAllDocsAvailable = resource.isNotAllDocsAvailable;
      this.statusCode = resource.statusCode
        this.patientDocService.setExternalDocList(list);
        this.docList = this.sortList(this.patientDocService.getExternalDocList());
        this.result.display = false;
      }else {
        this.result.display = true;
        this.result.banner = errorBanners.externalPatientSearch[7003];
      }
    } else {
      let response = {
        statusCode: "default",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleError(response);
    }

  }

  handleError(response) {
    this.spinnerService.hide();
    this.result.display = true;
    this.result.banner = errorBanners.externalPatientSearch[response.statusCode];
    if (!this.result.banner) {
      this.result.banner = errorBanners.externalPatientSearch['default'];
    }
    var info = this.result.banner.info;
    info = info == '{errorDesc}' ? response.statusDesc : info;
    this.result.banner.info = info;
  }

  openDocument(digitalId) {
    let document = this.docList.find(item => item.digitalId == digitalId);
    let sDoc = Object.assign({}, document);
    document.viewStatus = "loading";
    let resource = Object.assign({}, this.searchService.getResource());
    resource.docRefs = [sDoc];
    let patient = {
      patient: resource
    }

    this.patientDocService.getDocument(patient).subscribe((data: any) => {
      if (data && data.response.statusCode === '0000') {
        document.viewStatus = "viewed";
        var htmlContent = window.atob(data.response.resources[0].content);
        const newWindow = window.open(document.id + '.html');
        newWindow.document.title = document.title;
        newWindow.document.write(htmlContent);
      } else {
        this.handleRetry(document);

      }

    }, error => {
      this.handleRetry(document);
    });
  }

  handleRetry(document) {
    document.viewStatus = "retry";
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 3) {
      document.viewStatus = "error";
    }
  }

  editSearch() {
    this.router.navigate([this.getPreviousPage()]);
  }
  startSearch() {
    this.searchService.setPatient(null);
    this.searchService.setResource(null);
    this.searchService.setSourcePage("externalSearch");
    this.patientDocService.setExternalDocList(null);
    this.router.navigate([this.getPreviousPage()]);
    // this.preventBackButton();
  }

  ngOnInit() {
  }

  getPreviousPage() {
    let page = allPaths.quickLookUp.link;
    let ob = sessionStorage.getItem("breadcrumbList");
    let breadcrumbList = ob ? JSON.parse(ob) : null;
    if (breadcrumbList.length > 1) {
      return this.getPreviousPath(breadcrumbList[breadcrumbList.length - 2]);
    }
    return page;
  }
  getPreviousPath(breadcrumbName) {
    for (const [key, value] of Object.entries(allPaths)) {
      if (value.label === breadcrumbName.label) {
        return value.link;
      }
    }
  }

  ngOnDestroy() {
    this.patientDocService.setExternalDocList(null);
    this.spinnerService.hide();
  }

}

