import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { SpexInterceptor } from './spex-interceptor';
import { environment } from '../../environments/environment';
import { SpinnerService } from '../services/spinner/spinner.service';
import { AuthService } from '../services/auth/auth.service';

describe(`AuthHttpInterceptor`, () => {
  let service: AuthService;
  let httpMock: HttpTestingController;
  let http: HttpClient;
  let router: any;
  let errorResponse : any;

  beforeEach(() => {
    router = { navigate: jasmine.createSpy('navigate') };
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [
        AuthService, SpinnerService,
        {
          provide: HTTP_INTERCEPTORS,
          useClass: SpexInterceptor,
          multi: true,
        }, { provide: Router, useValue: router }, HttpClient
      ],
    });

    service = TestBed.get(AuthService);
    httpMock = TestBed.get(HttpTestingController);
    http = TestBed.get(HttpClient);

  });

  afterEach(() => {
      httpMock.verify();
  });

  it('should add an Accept , Content-Type , verification-token & X-CorrelationID header', () => {
    let request = { "email": '9326539', "password": 'cvshealth' };
    service.authenticate(request).subscribe(response => {
      expect(response).toBeTruthy();
    });
      const httpRequest = httpMock.expectOne(`${environment.config.serverEndPoint}${environment.config.path.loginAuthentication}`);

      expect(httpRequest.request.headers.has('Accept')).toEqual(false);
      expect(httpRequest.request.headers.has('Content-Type')).toEqual(true);
      expect(httpRequest.request.headers.has('verification-token')).toEqual(false);
      expect(httpRequest.request.headers.has('X-CorrelationID')).toEqual(false);




  });

//      it('redirect to error page if service is unavailable', () => {
//       let request = {"email":'9326539', "password":'cvshealth'};

//        service.authenticate(request).subscribe(fail, error  => errorResponse = error);

//     const httpRequest = httpMock.expectOne(`${environment.config.serverEndPoint}${environment.config.path.loginAuthentication}`);
//      httpRequest.flush({ errorMessage: 'Internal Error' }, { status: 404, statusText: 'Server Error' });


//         expect(router.navigate).toHaveBeenCalledWith(['error']);
//    });

  // it('redirect to error page if crede`ntails wrong', () => {
  //       let request = {"email":'', "password":''};

  //         service.authenticate(request).subscribe(fail, error  => errorResponse = error);

  //     const httpRequest = httpMock.expectOne(`${environment.config.serverEndPoint}${environment.config.path.loginAuthentication}`);
  //      httpRequest.flush({ errorMessage: 'UnAuthorized' }, { status: 401, statusText: 'UnAuthorized' });

  //         expect(errorResponse.errorMessage).toBe('UnAuthorized')
  //         expect(router.navigate).toHaveBeenCalledWith(['error']);
  //    });


    // it('redirect to error page if user Unauthorized to accces t resuce', () => {
    //       let request = {"email":'', "password":''};

    //    service.authenticate(request).subscribe(fail, error  => errorResponse = error);

    //     const httpRequest = httpMock.expectOne(`${environment.config.serverEndPoint}${environment.config.path.loginAuthentication}`);
    //      httpRequest.flush({ errorMessage: 'Access Denied' }, { status: 403, statusText: 'Access Denied' });

    //         expect(errorResponse.errorMessage).toBe('Access Denied')
    //         expect(router.navigate).toHaveBeenCalledWith(['error']);
    //    });

    //   it('redirect to error page if user resource not found', () => {
    //         let request = {"email":'', "password":''};

    //      service.authenticate(request).subscribe(fail, error  => errorResponse = error);

    //       const httpRequest = httpMock.expectOne(`${environment.config.serverEndPoint}${environment.config.path.loginAuthentication}`);
    //        httpRequest.flush({ errorMessage: 'Not Found' }, { status: 404, statusText: 'Not Found' });

    //           expect(errorResponse.errorMessage).toBe('Not Found');
    //           expect(router.navigate).toHaveBeenCalledWith(['error']);
    //      });

  });




