const envSettings = {
  prod: {
    env: 'prod',
    config: {
      production: true,
      serverEndPoint: 'https://dsphub-east.corp.cvscaremark.com:2443',
      serverEndPointWest: 'https://dsphub-west.corp.cvscaremark.com:2443',
      baseURL: 'https://digital-specialty-rx-cq-prod-internal.cvshealth.com',
      URLEndPoint: 'https://care.cvsspecialty.com',
      qmURL : 'https://cdn.quantummetric.com/qscripts/quantum-cvs.js',
      path: {
        loginAuthentication: "/login",
        dashboardPage: "/specialtyexpedite/user/dashboard",
        patientSearch: "/specialtyexpedite/patient/",
        documentSearch: "/specialtyexpedite/patient/documents",
        pullDocument: "/specialtyexpedite/documents/save",
        viewDocument: "/specialtyexpedite/documents/view",
        retrieveDocument: "/specialtyexpedite/documents/retrieve",
        viewXMLDocument: "/specialtyexpedite/documents/view/xml",
        internalPatientSearch: "/specialtyexpedite/ql/patient",
        documentRetrieval: "/specialtyexpedite/ql/document/retrieve",
        docSearch: "/specialtyexpedite/textsearch/search",
        userfeedback: "/specialtyexpedite/ql/userfeedback",
        lookupPatientByDemo: "/specialtyexpedite/dl/patient",
        advancedPatientSearch: "/specialtyexpedite/patient/documentList",
        medicationsPatientSummary: "/patientsummarycache/medicationSummary",
        completeMedicationsSummary: "/patientsummarycache/medicationList",
        progressNotesSummary: "/patientsummarycache/progressNotesSummary",
        completeProgressNotesSummary: "/patientsummarycache/progressNotesList",
        progessNotesViewDocument:"/patientSummary/docRef",
        vitalsSummary: "/patientsummarycache/vitalSummary",
        completeVitalsSummary: "/patientsummarycache/vitalList",
        conditionsSummary: "/patientsummarycache/conditionSummary",
        completeConditionsSummary: "/patientsummarycache/conditionList",
        allergiesSummary: "/patientsummarycache/allergySummary",
        completeAllergiesSummary: "/patientsummarycache/allergyList"
      },
      apikey: "3e4d6310-df57-4b9c-aca7-8aeb01fb92ef"
    },
    userIdle: {
      idleTime: 17,
      timeout: 3
    }
  }
}

function getEnvironment() {
  return envSettings['prod'];
}

export const environment = getEnvironment();

