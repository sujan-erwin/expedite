// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const envSettings = {
  sit1: {
    env: 'sit1',
    config: {
      production: false,
      serverEndPoint: 'https://dsphub-sit1.corp.cvscaremark.com:2443',
      URLEndPoint: 'https://sit1.care.cvsspecialty.com',
      qmURL: 'https://cdn.quantummetric.com/qscripts/quantum-cvs-test.js',
      path: {
        loginAuthentication: "/login",
        dashboardPage: "/specialtyexpedite/user/dashboard",
        patientSearch: "/specialtyexpedite/patient/",
        documentSearch: "/specialtyexpedite/patient/documents",
        pullDocument: "/specialtyexpedite/documents/save",
        viewDocument: "/specialtyexpedite/documents/view",
        retrieveDocument: "/specialtyexpedite/documents/retrieve",
        viewXMLDocument: "/specialtyexpedite/documents/view/xml",
        internalPatientSearch: "/specialtyexpedite/ql/patient",
        docSearch: "/specialtyexpedite/textsearch/search",
        documentRetrieval: "/specialtyexpedite/ql/document/retrieve",
        userfeedback: "/specialtyexpedite/ql/userfeedback",
        lookupPatientByDemo: "/specialtyexpedite/dl/patient",
        advancedPatientSearch: "/specialtyexpedite/patient/documentList"
      },
      apikey: "styq-ut68-5rs3-4zb9"
    },
    userIdle: {
      idleTime: 17,
      timeout: 3
    }
  },
  sit2: {
    env: 'sit2',
    config: {
      production: false,
      serverEndPoint: 'https://dsphub-sit2.corp.cvscaremark.com:2443',
      URLEndPoint: 'https://sit2.care.cvsspecialty.com',
      qmURL: 'https://cdn.quantummetric.com/qscripts/quantum-cvs-test.js',
      path: {
        loginAuthentication: "/login",
        dashboardPage: "/specialtyexpedite/user/dashboard",
        patientSearch: "/specialtyexpedite/patient/",
        documentSearch: "/specialtyexpedite/patient/documents",
        pullDocument: "/specialtyexpedite/documents/save",
        viewDocument: "/specialtyexpedite/documents/view",
        retrieveDocument: "/specialtyexpedite/documents/retrieve",
        viewXMLDocument: "/specialtyexpedite/documents/view/xml",
        internalPatientSearch: "/specialtyexpedite/ql/patient",
        docSearch: "/specialtyexpedite/textsearch/search",
        documentRetrieval: "/specialtyexpedite/ql/document/retrieve",
        userfeedback: "/specialtyexpedite/ql/userfeedback",
        lookupPatientByDemo: "/specialtyexpedite/dl/patient",
        advancedPatientSearch: "/specialtyexpedite/patient/documentList"
      },
      apikey: "styq-ut68-5rs3-4zb9"
    },
    userIdle: {
      idleTime: 17,
      timeout: 3,
    },
  },
  10: {
    env: '10',
    config: {
      production: false,
      serverEndPoint: 'https://dsphub-sit1.corp.cvscaremark.com:2443',
      qmURL: 'https://cdn.quantummetric.com/qscripts/quantum-cvs-test.js',
      path: {
        loginAuthentication: "/login",
        dashboardPage: "/specialtyexpedite/user/dashboard",
        patientSearch: "/specialtyexpedite/patient/",
        documentSearch: "/specialtyexpedite/patient/documents",
        pullDocument: "/specialtyexpedite/documents/save",
        viewDocument: "/specialtyexpedite/documents/view",
        retrieveDocument: "/specialtyexpedite/documents/retrieve",
        viewXMLDocument: "/specialtyexpedite/documents/view/xml",
        internalPatientSearch: "/specialtyexpedite/ql/patient",
        docSearch: "/specialtyexpedite/textsearch/search",
        documentRetrieval: "/CCD/ql/document/retrieve",
        userfeedback: "/specialtyexpedite/ql/userfeedback",
        lookupPatientByDemo: "/specialtyexpedite/dl/patient",
        advancedPatientSearch: "/specialtyexpedite/patient/documentList"
      },
      apikey: "styq-ut68-5rs3-4zb9"
    },
    userIdle: {
      idleTime: 17,
      timeout: 3,
    },
  },

  sit3: {
    env: 'sit3',
    config: {
      production: false,
      serverEndPoint: 'https://dsphub-sit3.corp.cvscaremark.com:2443',
      URLEndPoint: 'https://sit3.care.cvsspecialty.com',
      qmURL: 'https://cdn.quantummetric.com/qscripts/quantum-cvs-test.js',
      path: {
        loginAuthentication: "/login",
        dashboardPage: "/specialtyexpedite/user/dashboard",
        patientSearch: "/specialtyexpedite/patient/",
        documentSearch: "/specialtyexpedite/patient/documents",
        pullDocument: "/specialtyexpedite/documents/save",
        viewDocument: "/specialtyexpedite/documents/view",
        retrieveDocument: "/specialtyexpedite/documents/retrieve",
        viewXMLDocument: "/specialtyexpedite/documents/view/xml",
        internalPatientSearch: "/specialtyexpedite/ql/patient",
        docSearch: "/specialtyexpedite/textsearch/search",
        documentRetrieval: "/specialtyexpedite/ql/document/retrieve",
        userfeedback: "/specialtyexpedite/ql/userfeedback",
        lookupPatientByDemo: "/specialtyexpedite/dl/patient",
        advancedPatientSearch: "/specialtyexpedite/patient/documentList"
      },
      apikey: "styq-ut68-5rs3-4zb9"
    },
    userIdle: {
      idleTime: 17,
      timeout: 3,
    },
  },
  stp: {
    env: 'stp',
    config: {
      production: false,
      serverEndPoint: 'https://dsphub-stp.corp.cvscaremark.com:2443',
      URLEndPoint: 'https://stp.care.cvsspecialty.com',
      qmURL: 'https://cdn.quantummetric.com/qscripts/quantum-cvs-test.js',
      path: {
        loginAuthentication: "/login",
        dashboardPage: "/specialtyexpedite/user/dashboard",
        patientSearch: "/specialtyexpedite/patient/",
        documentSearch: "/specialtyexpedite/patient/documents",
        pullDocument: "/specialtyexpedite/documents/save",
        viewDocument: "/specialtyexpedite/documents/view",
        retrieveDocument: "/specialtyexpedite/documents/retrieve",
        viewXMLDocument: "/specialtyexpedite/documents/view/xml",
        internalPatientSearch: "/specialtyexpedite/ql/patient",
        docSearch: "/specialtyexpedite/textsearch/search",
        documentRetrieval: "/specialtyexpedite/ql/document/retrieve",
        userfeedback: "/specialtyexpedite/ql/userfeedback",
        lookupPatientByDemo: "/specialtyexpedite/dl/patient",
        advancedPatientSearch: "/specialtyexpedite/patient/documentList"
      },
      apikey: "styq-ut68-5rs3-4zb9"
    },
    userIdle: {
      idleTime: 17,
      timeout: 3
    }
  },
  local: {
    env: 'local',
    config: {
      production: false,
      serverEndPoint: 'http://localhost:8081',
      URLEndPoint: 'http://localhost:8081',
      qmURL: 'https://cdn.quantummetric.com/qscripts/quantum-cvs-test.js',
      path: {
        loginAuthentication: "/login",
        dashboardPage: "/specialtyexpedite/user/dashboard",
        patientSearch: "/specialtyexpedite/patient/",
        documentSearch: "/specialtyexpedite/patient/documents",
        retrieveDocument: "/specialtyexpedite/documents/retrieve",
        viewXMLDocument: "/specialtyexpedite/documents/view/xml",
        internalPatientSearch: "/specialtyexpedite/ql/patient",
        docSearch: "/specialtyexpedite/textsearch/search",
        documentRetrieval: "/specialtyexpedite/ql/document/retrieve",
        userfeedback: "/specialtyexpedite/ql/userfeedback",
        lookupPatientByDemo: "/specialtyexpedite/dl/patient",
        advancedPatientSearch: "/specialtyexpedite/patient/documentList"
      },
      apikey: "styq-ut68-5rs3-4zb9"
    },
    userIdle: {
      idleTime: 17,
      timeout: 3,
    },

  },
}
function getEnvironment() {
  const env = window.location.hostname;
  if (env === 'localhost' || env === 'local')
    envStr= "local";
  else {
    var envStr = window.location.hostname.split('.')[0];
    envStr = envStr.replace('static', 'www');
    if (envStr.indexOf('fast') > 0) {
      envStr = envStr.replace('fast', 'www');
    }
  }
  return envSettings[envStr];
}

export const environment = getEnvironment();

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
