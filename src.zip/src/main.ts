import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.config.production) {
  enableProdMode();
}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));

/* To add or remove the focus box incase of mouse and with [TAB] key*/  
document.body.addEventListener('mousedown', (event) => {

  document.body.classList.add('using-mouse');
});
document.body.addEventListener('keydown', function (event) {
  if (event.keyCode === 9) {
    document.body.classList.remove('using-mouse');
  }
});
