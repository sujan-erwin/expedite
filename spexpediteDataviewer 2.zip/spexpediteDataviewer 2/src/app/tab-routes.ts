import { allPaths } from './app-routes';

export const tabPaths = {
        patientSearch: [
            allPaths.quickLookUp,
            allPaths.advancedSearch,
            allPaths.patientDocuments,
            allPaths.selectProfile,
            allPaths.internalPatientDocuments,
            allPaths.LookupPatient
        ],
        pastSearches:
            [allPaths.pastSearches]
}
