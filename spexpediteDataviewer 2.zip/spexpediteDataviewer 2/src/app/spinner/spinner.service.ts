import { Injectable, EventEmitter} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SpinnerService {
  showEmitter: EventEmitter<boolean> = new EventEmitter();
  show() {
    this.showEmitter.emit(true);
  }
  hide() {
    this.showEmitter.emit(false);
  }
  getEmitter() {
    return this.showEmitter;
  }
}
