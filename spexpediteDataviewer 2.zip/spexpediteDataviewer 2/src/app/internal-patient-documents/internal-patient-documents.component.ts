import { Component, OnInit, OnDestroy, ViewChild, TemplateRef, SecurityContext, Input } from '@angular/core';
import { SearchService } from '../services/search.service';
import { Router, ActivatedRoute } from '@angular/router';
import { allPaths } from '../app-routes';
import { PatientDocumentService } from '../services/patientDocument.service';
import { SpinnerService } from '../spinner/spinner.service';
import { errorBanners } from '../error-messages';
import { DatePipe } from '@angular/common';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { AuthService } from '../services/auth.service';
import { Title } from '@angular/platform-browser';
import { SpinnerServiceSVP } from '../spinner-svp/spinner-svp.service';
import { PatientSummaryService } from '../patient-summary/store/patient-summary.service';
export interface errorBlock {
  medicationsErrTitle: any,
  medicationsErrMsg: any,
  isMedicationsErr: boolean
 }

@Component({
  selector: 'app-internal-patient-documents',
  templateUrl: './internal-patient-documents.component.html',
  styleUrls: ['./internal-patient-documents.component.scss']
})
export class InternalPatientDocumentsComponent implements OnInit, OnDestroy {
  @ViewChild('noSearchResultsmodal', { read: TemplateRef }) noSearchResultsmodal: TemplateRef<any>;
  // FormGroups
  filterForm: FormGroup;
  internalPatientDocumentForm: FormGroup;
  commentSectionForm: FormGroup;

  // any Type
  patient: any;
  docList: any = [];
  organizationFilterValues: any = [];
  typeFilterValues: any = [];
  filteredDocuments: any = [];
  searchedDocuments: any = [];
  relevantDocuments: any = [];
  prescriber: any;
  matchedOrgname: any;
  originalDocList: any = [];
  result: any = { display: false };
  statusCode: string;
  httpStatusCode: string;
  modalRef: any;
  searchResultResponse: string = "";
  selectedFilters: any = [];
  medicationlistStatus: any;
  retrievalDocStatus = ['CCD Retrieval Success','Relevant Document Retrieval Success', 'Relevant CCD Retrieval Success'];
  hbsId: any;
  medicationsData: any;
  progressNotesData: any;
  viewAll: boolean = false;
  showPN: boolean = false;
  individualProgressNotes: any;
  medicationsErrorBlock: errorBlock = {
    medicationsErrTitle: '',
    medicationsErrMsg: '',
    isMedicationsErr: false
  }

  // Boolean variables
  show: boolean = true;
  showFeedback: boolean = false;
  isSearchClicked: boolean = false;
  showFeedbackComment: boolean = false;
  patientDetailsCollapsed: boolean = true;
  isInvalidSearch: boolean = false;
  ClinicalContent: boolean = true;

  sourcePage: any = '';

  lookup: any = '';

  question1: any = "Did you find all the information you needed to complete the task?";
  question2: any = "What information could you not find?";

  	
  showAll: boolean;
  showAllType: string;
  activeTab: string;
  showIndividualPN: boolean;

  constructor(private searchService: SearchService, private patientDocService: PatientDocumentService,
    private spinnerService: SpinnerService, private router: Router, private route: ActivatedRoute, private authService: AuthService,
    private fb: FormBuilder, private modalService: NgbModal, private titleService:Title, private patientSummaryService: PatientSummaryService, private spinnerServiceSVP: SpinnerServiceSVP) {
    this.internalPatientDocumentForm = fb.group({
      searchBar: ['', []]
    });
    this.commentSectionForm = fb.group({
      comments: ['', [Validators.required]],
    });
    this.filterForm = fb.group({
      type: [[]],
      organization: [[]]
    });
    this.populateDocs();
    this.titleService.setTitle("Dataviewer - Internal Documents Results");
    if (this.searchService.getShowfeedbackQuestion() !== undefined) {
      this.show = this.searchService.getShowfeedbackQuestion();
    }
    this.sourcePage = this.searchService.getSourceLookupPage();
    this.showAll = false;
    this.activeTab = "clinical-summary";
    this.hbsId = this.searchService.retrieveHbsId;
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.statusCode = params['statusCode'];
      this.httpStatusCode = params['httpStatusCode'];
      if (this.sourcePage === undefined && localStorage.getItem("patientLookup") === 'Patient lookup') {
        this.lookup = localStorage.getItem("patientLookup");
        this.sourcePage = this.lookup;
      } else if (this.sourcePage === undefined && localStorage.getItem("quickLookup") === 'Quick lookup') {
        this.lookup = localStorage.getItem("quickLookup");
        this.sourcePage = this.lookup;
      }
    });
    if (this.patient.HBSID) this.getMedicationsData();
    if (this.patient.HBSID) this.getProgressNotesData();
  }
  
  onClickShowDocs() {
    this.ClinicalContent = false;
    this.onClickTab("clinical-summary");
  }
  onClickShowClinicalSummary() {
    this.ClinicalContent = true;
  }

  populateDocs() {
    this.patient = this.searchService.getInternalResourceToPatient();
    const internalResource = this.searchService.getInternalResource();
    let oldHBSID = this.patientDocService.getOldHBSID();

    if (internalResource) {
      let list = this.patientDocService.getDocList();
      this.originalDocList = list;
      if (oldHBSID != this.patient.HBSID) {
        this.docList = internalResource.docRefs ? internalResource.docRefs : [];
        this.docList = this.docList.filter(doc => doc.contentType == "text/xml");
        this.originalDocList = this.docList;
        this.docList = this.sortList(this.docList);
        this.filteredDocuments = this.docList;
        this.patientDocService.setDocList(this.docList);
        this.patientDocService.setOldHBSID(this.patient.HBSID);
        this.prescriber = internalResource.prescriber;
        this.patientDocService.setPrescriber(this.prescriber);
      }
      else {
        this.docList = this.sortList(list);
        this.prescriber = this.patientDocService.getPrescriber();
      }
      this.prescriber = this.prescriber ? this.prescriber : {};
      console.log("Displaying prescriber information");
    }
    this.filterForm.valueChanges.subscribe(values => {
      this.filterDocuments(values);
    });
    this.updateFilterValues();
    this.populateMatchedOrgname();
  }

  getPreviousPage() {
    let page = allPaths.quickLookUp.link;
    let ob = sessionStorage.getItem("breadcrumbList");
    let breadcrumbList = ob ? JSON.parse(ob) : null;
    if (breadcrumbList.length > 1) {
      return this.getPreviousPath(breadcrumbList[breadcrumbList.length - 2]);
    }
    return page;
  }
  getPreviousPath(breadcrumbName) {
    for (const [key, value] of Object.entries(allPaths)) {
      if (value.label === breadcrumbName.label) {
        return value.link;
      }
    }
  }

  editSearch() {
    this.router.navigate([this.getPreviousPage()]);
  }

  startSearch() {
    this.searchService.storeHbsId(null);
    this.searchService.setPatient(null);
    this.searchService.storeDemographicsInfo(null);
    this.router.navigate([this.getPreviousPage()]);
  }

  externalSearch() {
    this.searchService.setSourcePage("internalDocs");
    this.router.navigate([allPaths.advancedSearch.link]);
  }

  advancedSearch() {
    this.searchService.setSourcePage("internalDocs");
    this.router.navigate([allPaths.advancedSearch.link]);

  }

  escapeHtml(input) {
    let orgSearchTerm = input;
    let searchTermFirstChar, searchTermLastChar;
    if (input.charAt(0) == '"') { searchTermFirstChar = true; }
    if (orgSearchTerm.length > 1 && input.charAt(input.length - 1) == '"') { searchTermLastChar = true; }
    if (searchTermFirstChar && searchTermLastChar) {
      input = orgSearchTerm.slice(1, orgSearchTerm.length - 1);
    }
    input = input.replaceAll('"', '&quot;');
    if (searchTermFirstChar && searchTermLastChar) { input = '\\"' + input + '\\"' };
    return input.replaceAll('<', '&lt;').replaceAll('>', '&gt;');
  }

  // on click of Enter button in search bar
  EnterSubmit(event) {
    if (event.keyCode === 13) {
      this.sendSearchItem();
    }
  }

  evaluateSearchInput(event?: any) {
    if (this.internalPatientDocumentForm.controls.searchBar.value == '') {
      this.isInvalidSearch = false;
      return;
    }
    var format = /[()<\\]+/;
    this.isInvalidSearch = format.test(this.internalPatientDocumentForm.controls.searchBar.value);
    if (event.keyCode === 13 && !this.isInvalidSearch) {
      this.sendSearchItem();
    }
  }

  // Initiating searchInput service
  sendSearchItem() {
    this.clearFilters();
    this.resetErrorBanner();
    var ids = this.docList.map(function (docRef) { return docRef.id; });
    console.log("Before SearchInput service call:");
    this.searchService.searchInput(this.internalPatientDocumentForm.controls.searchBar.value, ids, this.patient.HBSID).subscribe((data: any) => {
      this.handleSearchResponse(data)
    }, (error) => {
      if (error.response) {
        this.handleError(error.response, error.response.statusCode);
      }
      else {
        this.handleError(null, null);
      }
    }
    );
  }

  // Handling searchInput Response
  handleSearchResponse(body) {
    this.spinnerService.hide();
    if (body && body.response) {
      console.log("service call submitted successfully")
      if (body.response.statusCode === '0000') {
        const docIds = body.response.resources[0].docIds;
        this.filteredDocuments = this.docList.filter(function (item) {
          return docIds.includes(item.id);
        });
        this.searchedDocuments = this.filteredDocuments.filter(function (item) {
          return docIds.includes(item.id);
        });
        const retrievalDocStat = this.retrievalDocStatus;
        this.relevantDocuments = this.docList.filter(function (item) {
          return retrievalDocStat.includes(item.status);
        });
      }
      else {
        this.searchResultResponse = body.response.statusDesc;
        this.filteredDocuments = [];
        this.searchedDocuments = [];
        this.relevantDocuments = [];
      }
      this.isSearchClicked = true;
      this.checkOpenNoSearchResultsModal();
    }
  }

  handleError(response, statusCode) {
    this.resetErrorBanner();
    this.spinnerService.hide();
    this.result.display = true;
    if (response) {
      console.log("Error response", response);
      this.result.banner = errorBanners.internalPatientSearch[response.statusCode];
      if (!this.result.banner) {
        this.result.banner = errorBanners.internalPatientSearch.default;
      }
    }
    else {
      this.result.banner = errorBanners.internalPatientSearch[1111];
    }
    if (!this.result.banner) {
      let code = statusCode ? statusCode : 'default';
      this.result.banner = errorBanners.internalPatientSearch[code];
    }
    if (this.result.banner && this.result.banner.displayResponseStatus) {
      this.result.banner.info = `${statusCode} - ${response?.statusDesc}`;
    }
  }

  resetErrorBanner() {
    this.result.display = false;
  }
  // call clearSearch function if there is no value in SearchBar
  updateSearchResults() {
    if (!this.internalPatientDocumentForm.controls.searchBar.value) {
      this.clearAll();
    }
  }
  closeBanner() {
    this.result.display = false;
  }

  // Filters logic
  filterDocuments(filter) {
    if (filter === '') {
      this.filteredDocuments = this.docList.filter(item => {
        return true;
      });
    } else {
      this.filteredDocuments = this.docList.filter(item => {
        var isAllowed = true;
        if (filter.type.length) {
          if (filter.type.indexOf(item.type) === -1) {
            isAllowed = false;
          }
        } else {
          isAllowed = true;
        }
        if (isAllowed) {
          if (filter.organization.length) {
            if (filter.organization.indexOf(item.orgName) === -1) {
              isAllowed = false;
            }
          } else {
            isAllowed = true;
          }
        }
        return isAllowed;
      });
    }
  }

  // Update Filter values
  updateFilterValues() {
    this.organizationFilterValues = [];
    this.typeFilterValues = [];
    if (!this.docList) { this.docList = [] };
    this.docList.forEach(doc => {
      //document.organization
      if (this.organizationFilterValues.indexOf(doc.orgName) === -1) {
        this.organizationFilterValues.push(doc.orgName);
      }
      //document.type
      if (this.typeFilterValues.indexOf(doc.type) === -1) {
        this.typeFilterValues.push(doc.type);
      }
    });
    this.filterDocuments(this.filterForm.value);
    this.organizationFilterValues.sort();
    this.typeFilterValues.sort();
    this.initialOrganizationValues = this.organizationFilterValues;
    this.initialTypeValues = this.typeFilterValues;
  }
  filterTypes: any = {};
  initialOrganizationValues: any = [];
  initialTypeValues: any = [];

  isFiltersSelected() {
    return (this.filterTypes.type && this.filterTypes.type.length > 0) || (this.filterTypes.organization && this.filterTypes.organization.length > 0);
  }
  // Apply Filter on values
  applyFilter(attr) {
    var typeFilter = attr[0];
    var values = attr[1];
    // this.selectedFilterValues = values;
    if ("Type" == typeFilter) {
      var filteredTypes = this.initialTypeValues.filter(item => {
        if (values.indexOf(item) !== -1) {
          return true;
        }
        return false;
      });
      this.filterTypes.type = filteredTypes;
      if (!filteredTypes || filteredTypes.length === 0) {
        this.typeFilterValues = this.initialTypeValues;
      }
      else {
        this.typeFilterValues = [];
        this.typeFilterValues = filteredTypes;
      }
    }
    else if ("Organization" == typeFilter) {
      var filteredOrgs = this.initialOrganizationValues.filter(item => {
        if (values.indexOf(item) !== -1) {
          return true;
        }
        return false;
      });
      this.filterTypes.organization = filteredOrgs;
      if (!filteredOrgs || filteredOrgs.length === 0) {
        this.organizationFilterValues = this.initialOrganizationValues;
      }
      else {
        this.organizationFilterValues = [];
        this.organizationFilterValues = filteredOrgs;
      }
    }
    if ((!this.filterTypes.organization || this.filterTypes.organization.length === 0) && (!this.filterTypes.type || this.filterTypes.type.length === 0)) {
      if (this.internalPatientDocumentForm.controls.searchBar.value && this.isSearchClicked) {
        this.filteredDocuments = this.searchedDocuments;
      }
      else {
        this.filteredDocuments = this.docList;
        this.organizationFilterValues = this.initialOrganizationValues;
        this.typeFilterValues = this.initialTypeValues;
      }
    }
    if (!this.isSearchClicked) {
      this.filteredDocuments = this.docList;
    }
    else if (this.isSearchClicked) {
      this.filteredDocuments = this.searchedDocuments;
    }
    if (this.filterTypes.type && this.filterTypes.type.length > 0) {
      this.filteredDocuments = this.filteredDocuments.filter(item => {

        if (this.filterTypes.type && this.filterTypes.type.indexOf(item.type) !== -1) {
          return true;
        }
        return false;
      });
    }
    if (this.filterTypes.organization && this.filterTypes.organization.length > 0) {
      this.filteredDocuments = this.filteredDocuments.filter(item => {
        if (this.filterTypes.organization && this.filterTypes.organization.indexOf(item.orgName) !== -1) {
          return true;
        }
        return false;
      });
    }
    this.checkOpenNoSearchResultsModal();
  }

  checkOpenNoSearchResultsModal() {
    if (this.isSearchClicked && this.internalPatientDocumentForm.controls.searchBar.value.length != 0 && this.searchedDocuments.length === 0) {
      this.openNoSearchResults(this.noSearchResultsmodal);
    }
  }
  openNoSearchResults(content) {
    var searchBarText = this.internalPatientDocumentForm.controls.searchBar.value;
    this.clearAll();
    if (searchBarText) {
      this.searchBar.setValue(searchBarText);
    }
    this.modalRef = this.modalService.open(content, { centered: true, size: 'lg' }).result.then((result) => {
    }, (reason) => {
      this.close();
    });
  }

  isEligibleToShow() {
    return this.isFiltersSelected()
  }
  isEligibleToShowSearch() {
    let userProfile = this.authService.getUserProfile();
    return (userProfile.groups && userProfile.groups.includes('specialty-expedite-pilot'))
  }
  isEligibleToShowRelevant() {
    return (this.isSearchClicked && this.internalPatientDocumentForm.controls['searchBar'].value.length > 0) 
  }
  // Clear applied filters
  clearFilters() {
    this.selectedFilters = [];
    if (this.internalPatientDocumentForm.controls['searchBar'].value.length === 0) {
      this.filteredDocuments = this.docList;
    }
    this.organizationFilterValues = this.initialOrganizationValues;
    this.typeFilterValues = this.initialTypeValues;
    this.filterTypes = [];
  }

  clearAll() {
    this.internalPatientDocumentForm.reset();
    this.searchBar.setValue("");
    this.resetErrorBanner();
    this.isInvalidSearch = false;
    if (this.isSearchClicked) {
      this.populateDocs();
    }
    this.searchedDocuments = [];
    this.isSearchClicked = false;
    this.selectedFilters = [];
    this.internalPatientDocumentForm.controls['searchBar'].value == '';
    this.filteredDocuments = this.docList;
    this.organizationFilterValues = this.initialOrganizationValues;
    this.typeFilterValues = this.initialTypeValues;
    this.filterTypes = {};
  }

  // Display Matched Orgname from the original doclist
  populateMatchedOrgname() {
    if (!this.filteredDocuments || this.filteredDocuments.length === 0) return;
    var ids = this.filteredDocuments.map(function (docRef) { return docRef.id; });
    this.originalDocList.some(doc => {
      if (ids.includes(doc.id) && this.isRelaventSuccessDoc(doc.status)) {
        this.matchedOrgname = doc.orgName;
        return true;
      }
    });
  }

  isRelaventSuccessDoc(status) {
    return status === 'Relevant CCD Retrieval Success' || status === 'Relevant Document Retrieval Success';
  }

  openDocument(document) {
    let sDoc = Object.assign({}, document);
    document.viewStatus = "loading";
    this.patientDocService.getInternalDocumentList(this.patient, document).subscribe((data: any) => {
      if (data && data.response.statusCode === '0000') {
        document.viewStatus = "viewed";
        var htmlContent = window.atob(data.response.resources[0].content);
        const newWindow = window.open(document.id + '.html');
        newWindow.document.title = document.title;
        newWindow.document.write(htmlContent);
      } else {
        this.handleRetry(document);
      }
    }, error => {
      this.handleRetry(document);
    });
  }

  handleRetry(document) {
    document.viewStatus = "retry";
    if (!document.retryCount && document.retryCount != 0) {
      document.retryCount = 0;
    } else {
      document.retryCount++;
    }
    if (document.retryCount && document.retryCount >= 3) {
      document.viewStatus = "error";
    }
  }


  sortList(list) {
    if (list) {
      let sortOrder = {
        1: ["Continuity of Care Document", "Summarization of episode note", "Ambulatory Summary","Summary of episode note"],
        2: "Encounter Summary",
        3: "Location Summary"
      };//Keep all the order in lower case. 
      let ccdList = list.filter(function (item) {
        return item.typeCode === '34133-9' &&
          (
            item.type.includes(sortOrder[1][0]) ||
            item.type.includes(sortOrder[1][1]) ||
            item.type.includes(sortOrder[1][2]) ||
            item.type.includes(sortOrder[1][3])
          );
      });
      if (ccdList) {
        ccdList = ccdList.sort(function (a, b) {

          return a.orgName > b.orgName ? 1 : a.orgName < b.orgName ? -1 : 0;
        });
      }
      let encounterSumList = list.filter(function (item) {
        return (item.typeCode === '11506-3') || (item.typeCode === '34133-9' && item.type.includes(sortOrder[2]));
      });
      encounterSumList = this.sortByEncounterDate(encounterSumList);
      let ssLSumList = list.filter(function (item) {
        return item.typeCode === '34133-9' && item.type.includes(sortOrder[3]);
      });
      var ids = ccdList.map(function (docRef) { return docRef.id; });
      encounterSumList.forEach(docRef => { ids.push(docRef.id) });
      ssLSumList.forEach(docRef => { ids.push(docRef.id); });

      let typeCodeNullList = list.filter(function (item) {
        return (item.typeCode == "") || !(ccdList.includes(item) || encounterSumList || ssLSumList.includes(item))
      });
      var nullListIds = typeCodeNullList.map(function (docRef) { return docRef.id });
      ids = [].concat(ids, nullListIds);
      let otherList = list.filter(function (item) {
        return !ids.includes(item.id);
      });
      let dateList = [].concat(typeCodeNullList, encounterSumList, otherList);
      dateList = this.sortByEncounterDate(dateList);
      ccdList = this.sortByEncounterDate(ccdList);
      ssLSumList = this.sortByEncounterDate(ssLSumList);
      list = [].concat(ccdList, dateList, ssLSumList);
    }
    return list;
  }
  sortByEncounterDate(list) {
    if (list) {
      list = list.sort(function (a, b) {
        let aDate = a.encounterDate;
        let bDate = b.encounterDate;
        aDate = !aDate || aDate == '' ? '01/01/1888' : aDate;
        bDate = !bDate || bDate == '' ? '01/01/1888' : bDate;
        return <any>new Date(bDate) - <any>new Date(aDate);
      });
    }
    return list;
  }

  // Hide feedback modal when user submits the answer
  hideFeedbackModal() {
    this.show = false;
  }

  toggle() {
    this.show = !this.show;
    this.searchService.setShowfeedbackQuestion(this.show);
    this.showFeedback = !this.showFeedback;
    setTimeout(() => {
      this.showFeedback = !this.showFeedback;
    }, 3000);
  }

  // capture feedback - service call when user clicks "YES"
  feedbackAnswerYes() {
    this.searchService.captureFeedback(this.patient.HBSID, "Yes", null).subscribe(data => { console.log("yes", data) });
  }

  // open modal when user clicks "No" to display comment section
  open(content) {
    this.showFeedbackComment = true;
    this.modalRef = this.modalService.open(content, { centered: true, size: 'lg' }).result.then((result) => {
    }, (reason) => {
      this.close();
    });
  }

  // capture feedback - service call when user clicks "NO"
  feedbackAnswerComment() {
    if (this.commentSectionForm.valid) {
      this.hideFeedbackModal();
      this.searchService.captureFeedback(this.patient.HBSID, "No", this.commentSectionForm.value).subscribe(data => {
        this.spinnerService.hide();
        this.showFeedbackComment = false;
        this.searchService.setShowfeedbackQuestion(false);
        setTimeout(() => {
          this.close();
        }, 3000);
      }, error => this.errorResponse(error))
    }
    else {
      this.validateAllFormFields(this.commentSectionForm);
    }
  }

  errorResponse(data) {

  }

  // close the modal when user clicks cross button in the modal
  close() {
    this.modalService.dismissAll();
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        if (!control.valid && !control.value) {
          control.markAsTouched();
        }
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngOnDestroy() {
    if (this.modalService.hasOpenModals()) {
      this.close();
    }
  }

  get searchBar() { return this.internalPatientDocumentForm.get('searchBar'); }
  get comments() { return this.commentSectionForm.get('comments'); }

getMedicationsData() {
  this.spinnerServiceSVP.showorHide(true);
  this.patientSummaryService.medicationsList(this.patient.HBSID).subscribe(
    (response: any) => {
      this.medicationsData = response;
      this.spinnerServiceSVP.showorHide(false);
    },
    error => {
      if (error.status) {
        this.showMedErrorMsg(error.status);
      }
      this.spinnerServiceSVP.showorHide(false);
    }
  );
}

getProgressNotesData() {
  this.spinnerServiceSVP.showorHide(true);
  this.patientSummaryService.progressNotesList(this.patient.HBSID).subscribe(
    (response: any) => {
      this.progressNotesData = response;
      this.spinnerServiceSVP.showorHide(false);
    },
    error => {
      if (error.status) {
        this.showMedErrorMsg(error.status);
      }
      this.spinnerServiceSVP.showorHide(false);
    }
  );
}

showMedErrorMsg(status) {
  let title = 'We ran into some technical issues.'
  if (status === 400) {
    this.medicationsErrorBlock.isMedicationsErr = true
    this.medicationsErrorBlock.medicationsErrMsg = "We couldn't load the appropriate information at this time."
    this.medicationsErrorBlock.medicationsErrTitle = title;
  } else if (status === 404) {
    this.medicationsErrorBlock.isMedicationsErr = true
    this.medicationsErrorBlock.medicationsErrMsg = "The page or content you are trying to reach is doesn't exist."
    this.medicationsErrorBlock.medicationsErrTitle = title;
  } else if (status === 500) {
    this.medicationsErrorBlock.isMedicationsErr = true
    this.medicationsErrorBlock.medicationsErrMsg = "We couldn't load the appropriate information at this time."
    this.medicationsErrorBlock.medicationsErrTitle = title;
  } else {
    this.medicationsErrorBlock.isMedicationsErr = true
    this.medicationsErrorBlock.medicationsErrMsg = "We couldn't load the appropriate information at this time."
    this.medicationsErrorBlock.medicationsErrTitle = title;
  }
}

onShowAllMedications(type: string) {
  this.showAll = type === "show" ? true : false;
  this.showAllType = type === "show" ? "medications" : null;
  this.activeTab = type === "show" ? "medications" : this.activeTab;
}

onShowAllContent(result) {
  this.showAll =  result.showAll;
  this.viewAll = result.viewAll;
  this.showPN = result.showPN;
  this.individualProgressNotes = result.individualProgressNotes;
  this.showAllType = result.showAll ? result.type : null;
  this.activeTab = result.showAll ? result.type : this.activeTab;
}


onClickTab(tabName: string) {
  this.activeTab = tabName;
  switch (tabName) {
    case "clinical-summary":{
      this.onShowAllMedications("hide");
      let pnOutput = {type: "progressNotes"}
      this.onShowAllContent(pnOutput);
      break;
    }
    case "medications":
      this.onShowAllMedications("show");
      break;
    case "progressNotes": {
      let pnOutput = {type: "progressNotes", showAll: true}
      this.onShowAllContent(pnOutput);
    break;
    }
  }
}
}

