export const allPaths = {
        quickLookUp:{label:"Quick lookup", link: "/quick-lookup"},
        advancedSearch:{label:"Advanced search", link: "/advanced-search"},
        pastSearches:{label:"Past search", link: "/past-search"},
        patientDocuments:{label:"Patient documents", link:"/patient-documents"},
        selectProfile: {label:"Select a profile", link:"/select-profile"},
        internalPatientDocuments:{label:"Patient documents", link:"/Patient-documents"},
        LookupPatient:{label:"Patient lookup", link:"/lookup-patient"}
    }
    