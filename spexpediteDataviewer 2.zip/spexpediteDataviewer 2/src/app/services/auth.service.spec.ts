import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { AuthService } from '../services/auth.service';
import { HttpClient } from '@angular/common/http';



describe('authService', () => {
  let service: AuthService;
  let httpClient: HttpTestingController;
  beforeEach(() => TestBed.configureTestingModule({
    providers: [AuthService, HttpClient],
    imports:[HttpClientTestingModule]
    
  }));

  it('should be created', () => {
    const service: AuthService = TestBed.get(AuthService);
    expect(service).toBeTruthy();
  });
});
