import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { allPaths } from '../app-routes';
import { SearchService } from '../services/search.service';
import { SpinnerService } from '../spinner/spinner.service';
import { AuthService } from '../services/auth.service';
import { PatientDocumentService } from '../services/patientDocument.service';
// import { PatientDocumentService } from '../services/patientDocument.service';
import { errorBanners } from '../error-messages';
import { DateValidator } from '../DateValidator';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-quick-look-up',
  templateUrl: './quickLookup.component.html',
  styleUrls: ['./quickLookup.component.scss']
})
export class QuickLookUpComponent implements OnInit {

  quickLookUpForm: FormGroup;
  result: any;
  selectedLink: any;
  isSubmitted: boolean;
  internalDocSearchSubscriber: any;



  constructor(fb: FormBuilder, private router: Router, private authService: AuthService, private searchService: SearchService, private patientDocService: PatientDocumentService,private spinnerService: SpinnerService,private titleService:Title) {
    this.result = {};
    this.result.display = false;
    this.titleService.setTitle("Dataviewer - QuickLookup Patient");
    this.quickLookUpForm = fb.group({
      HBSID: ['', Validators.required]
    });
    const HBSID_VAL = this.searchService.retrieveHbsId();

    if (HBSID_VAL) {
      // this.quickLookUpForm.patchValue({HBSID});
      this.HBSID.setValue(HBSID_VAL);
    }
  }

  ngOnInit() {
  }



  startSearch() {
    this.searchService.setInternalResource(null);
    this.searchService.setSourcePage('internalSearch');
    this.router.navigate([allPaths.advancedSearch.link]);
  }
   
  onSubmit() {
    this.searchService.setShowfeedbackQuestion(true);
    this.isSubmitted = true;
    this.resetErrorBanner();
    if (this.quickLookUpForm.valid) {
      // this.searchService.setPatient(this.quickLookUpForm.value);
      this.searchService.storeHbsId(this.quickLookUpForm.value.HBSID);
      this.searchService.searchInternalPatient(this.quickLookUpForm.value).subscribe(data =>
        this.handleSearchResponse(data), error => this.handleSearchResponse(error));
    }
  }

  handleSearchResponse(body) {
    if (body && body.response) {
      if (body.response.statusCode === '0000') {
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        if (body.response.resources && body.response.resources.length > 0) {
          let list = body.response.resources[0].docRefs;
          list = list.filter(doc => doc.contentType == "text/xml");
          this.patientDocService.setDocList(list);
          this.patientDocService.setPrescriber(body.response.resources[0].prescriber)
          this.searchService.storeHbsId(this.quickLookUpForm.value.HBSID);
          this.router.navigate([allPaths.internalPatientDocuments.link]);
        }
        else {
          this.result.display = true;
          this.result.banner = errorBanners.internalPatientSearch[7004];
        }
      } else if (body.response.statusCode === '7003') {
        this.searchService.setShowfeedbackQuestion(false);
        const resource = body.response.resources[0];
        this.searchService.setInternalResource(resource);
        this.spinnerService.hide();
        this.searchService.setSourceLookupPage('Quick lookup');
        localStorage.setItem('quickLookup', 'Quick lookup');
        localStorage.removeItem("patientLookup");
        this.router.navigate([allPaths.internalPatientDocuments.link]);

      } else {
        this.handleError(body.response, body.status);
      }
    } else {
      let body = {
        statusCode: "Unknown",
        statusDesc: "Unknown error occured while calling backend service."
      }
      this.handleError(body);
    }
  }

  handleError(response, httpStatusCode = null) {
    this.resetErrorBanner();
    this.spinnerService.hide();
    this.result.display = true;
    this.result.banner = errorBanners.internalPatientSearch[response.statusCode];
    this.result.displayHBSIDError = true;
    if (!this.result.banner) {
      this.result.banner = errorBanners.internalPatientSearch['default'];
    }
    if (this.result.banner && this.result.banner.displayResponseStatus) {
      this.result.banner.info = `${httpStatusCode} - ${response.statusCode} - ${response.statusDesc}`;
    }

  }
  resetErrorBanner() {
    this.result.display = false;
    this.result.displayHBSIDError = false;
  }
  clearSearch() {
    this.isSubmitted = false;
    this.resetErrorBanner();
    // this.searchService.setPatient(null);
    this.searchService.storeHbsId(null);
    this.searchService.setResource(null);
    this.searchService.setInternalResource(null);
    this.quickLookUpForm.reset();
    this.HBSID.setValue("");
    this.result.display = false;
  }

  resetFormFieldsExceptLookUpOption() {
    Object.keys(this.quickLookUpForm.controls).forEach(field => {
      if (field === 'quickLookUpOption') {
        return;
      }
      const control = this.quickLookUpForm.get(field);

      if (control instanceof FormControl) {
        control.reset();

      }
    }
    );
  }

  restrictValue(control, type) {
    var newVal = control.value;
    if (type == 'numeric') {
      newVal = newVal.replace(/[^0-9]/g, '');
    } else {
      newVal = newVal.replace(/[^a-z0-9]/gi, '');
    }
    control.setValue(newVal);
  }

  


  maskDate(event) {
    if (event.inputType !== 'deleteContentBackward') {
      // remove all mask characters (keep only numeric)
      var newVal = event.target.value.replace(/[^0-9/]/g, '');
      // don't show braces for empty value
      if (newVal.length == 0) {
        newVal = '';
      } else {
        let dList = newVal.split("/");
        let count = (dList || []).length;
        //if the input already contains two / then format it. 
        if (count >= 3) {
          newVal = this.formatDate(newVal);
        } else {
          if (newVal.length == 2) { //only with two chars decides whether to append zero or not. 
            if (newVal.indexOf('/') == 1) {
              newVal = '0' + newVal;
            } else if (newVal.indexOf('/') < 0) { //if both chars are digits then append with / at end
              newVal = newVal.replace(/^(\d{0,2})/, '$1/');
            }
          } else if (newVal.length == 3) { //if user edit after entering 3 chars, we need append / accordingly. 
            if (newVal.indexOf('/') != 2) {
              newVal = newVal.replace(/[^0-9]/g, ''); //clear all / and format it as below. 
              newVal = newVal.replace(/^(\d{2})(\d{0,2})/, '$1/$2');
            }
          }
          else if (newVal.length == 5) { //when 5 chars, decide whether append dd with zero or not. 
            if (newVal.substring(3, 5).indexOf('/') == 1) {
              newVal = newVal.substring(0, 3) + '0' + newVal.substring(3, 5);
            } else if (newVal.substring(3, 5).indexOf('/') < 0) { //if dd slash is not entered, then add it at end. 
              newVal = newVal.replace(/[^0-9]/g, '');
              newVal = newVal.replace(/^(\d{0,2})(\d{0,2})/, '$1/$2/');
            }
          } else if (newVal.length >= 6) { //if length is more than 6 chars eligible for MM/DD/YYYY or it could be pasted content. 
            newVal = this.formatDate(newVal);
          }
        }

      }
      // set the new value
      this.dob.setValue(newVal);
    }
  }

  formatDate(date) {
    let dList = date.split("/");
    let count = (dList || []).length;
    if (count >= 3 && (dList[0].length == 1 || dList[1].length == 1)) {
      if (dList[0].length == 1) {
        dList[0] = "0" + dList[0];
      }
      if (dList[1].length == 1) {
        dList[1] = "0" + dList[1];
      }
      date = dList[0] + "/" + dList[1] + "/" + dList[2];
    }
    return date;
  }

  fnNumbers(event) {
    if (event.charCode != 43 && event.charCode > 31 && (event.charCode < 48 || event.charCode > 57)) {
      return false;
    }
  }

  get firstName() { return this.quickLookUpForm.get('firstName'); }
  get lastName() { return this.quickLookUpForm.get('lastName'); }
  get HBSID() { return this.quickLookUpForm.get('HBSID'); }
  get quickLookUpOption() { return this.quickLookUpForm.get('quickLookUpOption'); }
  get dob() { return this.quickLookUpForm.get('dob'); }
  get zipCode() { return this.quickLookUpForm.get('zipCode'); }


}