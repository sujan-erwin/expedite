import { Injectable, Injector } from '@angular/core';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { tap} from 'rxjs/operators';
import { timeout } from 'rxjs/operators';
import { pipe } from 'rxjs';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SpinnerService } from '../spinner/spinner.service';

@Injectable()
export class SpexInterceptor implements HttpInterceptor {
  constructor(private router: Router, private spinnerService: SpinnerService) { }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (request.url.indexOf('/login') !== -1) {
      request = request.clone({
        setHeaders: {
          'Content-Type': 'application/json'
        }
      });
      return next.handle(request); // do nothing
    }

    request = request.clone({
      setHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'verification-token': environment.config.apikey,
        'X-CorrelationID': this.createTransaction(),
      }
    });
    console.log("Requested URL: ", request.url);
    return next.handle(request).pipe(timeout(180000),
      // filter(event => event instanceof HttpResponse),
      tap(event => {
        if (event instanceof HttpResponse) {
          console.log("HttpStatuscode: ", event.status);
        }
        return event;
      }),
      catchError((error: HttpErrorResponse) => {
        console.log("HttpStatuscode: ", error.status);
        let errMsg = {};
        // Client Side Error
        if (error.error instanceof ErrorEvent) {
          throwError(error);
        }
        else {  // Server Side Error
          errMsg = { status: error.status, response: error.error.response };
        }
        return throwError(errMsg);
      })
    );
  }

  createTransaction() {
    return "ID-" + Math.random().toString(36).substr(2, 4) + "-" +
      Math.random().toString(36).substr(2, 4) + "-" +
      Math.random().toString(36).substr(2, 4) + "-" +
      Math.random().toString(36).substr(2, 4);
  }
}

