import { MedicationsMapper } from './medications-mapper.model';

describe('MedicationsMapper', () => {
  it('should create an instance', () => {
    expect(new MedicationsMapper()).toBeTruthy();
  });
});
