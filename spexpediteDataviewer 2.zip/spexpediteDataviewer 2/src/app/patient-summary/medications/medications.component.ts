import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { State, Store } from '@ngrx/store';
import { IPatientSummary } from '../../patient-summary/store/patient-summary.interface';
import { AppInitialState } from '../../patient-summary/store/api/app-initial.state';
import { PatientSummaryService } from '../store/patient-summary.service';
import * as PatientSummaryActions from '../store/patient-summary.action';
import { MedicationsMapper } from 'src/app/model/medications-mapper.model';
import { SpinnerServiceSVP } from 'src/app/spinner-svp/spinner-svp.service';

@Component({
  selector: 'app-medications',
  templateUrl: './medications.component.html',
  styleUrls: ['./medications.component.scss']
})
export class MedicationsComponent implements OnInit {

  @Output() showAllMedications: EventEmitter<any> = new EventEmitter();

  ipatientSummary: IPatientSummary;
  ipatientSummaryObserv: Observable<IPatientSummary>;
  medicationsToRender: any[];
  medicationsSliced: any;
 

  @Input() showAll: boolean;
  @Input() medicationsErrorBlock: any;
  @Input() set medicationsData(medications: any) {
    this._medicationsData = medications;
    this.constructMedicationsData();
  };

  _medicationsData: any;


  constructor(private store: Store<AppInitialState>, private patientSummaryService: PatientSummaryService,
    private medicationsMapper: MedicationsMapper, private spinnerServiceSVP: SpinnerServiceSVP) {
    this.medicationsToRender = [];
  }

  ngOnInit(): void {
  }
  
  constructMedicationsData() {
    const medicationsArr = []
    if (this._medicationsData && this._medicationsData.entry && this._medicationsData.entry.length > 0) {
      for (let i = 0; i < this._medicationsData.entry.length; i++) {
        medicationsArr.push(this.medicationsMapper.flattenMedication(this._medicationsData.entry[i].resource, i + 1))
      }
    }
    this.medicationsToRender = medicationsArr;
    this.medicationsSliced = medicationsArr.slice(0, 3);
  }


  onClickViewAllMedications() {
    this.showAllMedications.emit("show");
    setTimeout(() => {
      this.showAll = true;
    }, 500);
  }
}