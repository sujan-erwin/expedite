
import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { State, Store } from '@ngrx/store';
import { IPatientSummary } from '../../patient-summary/store/patient-summary.interface';
import { AppInitialState } from '../../patient-summary/store/api/app-initial.state';
import { PatientSummaryService } from '../store/patient-summary.service';
import * as PatientSummaryActions from '../store/patient-summary.action';
import { ProgressNotesMapper } from 'src/app/model/progressNotes-mapper.model';
import { SpinnerServiceSVP } from 'src/app/spinner-svp/spinner-svp.service';
import { SearchService } from 'src/app/services/search.service';

@Component({
    selector: 'app-progress-notes',
    templateUrl: './progress-notes.component.html',
    styleUrls: ['./progress-notes.component.scss']
  })
export class ProgressNotesComponent implements OnInit {

  @Output() showAllContent: EventEmitter<any> = new EventEmitter();

  ipatientSummary: IPatientSummary;
  ipatientSummaryObserv: Observable<IPatientSummary>;
  progressNotesToRender: any[];
  progressNotesSliced: any;

  @Input() individualProgressNotes: any;
  @Input() showPN: boolean = false;
  @Input() viewAll: boolean;
  @Input() progressNotesErrorBlock: any;
  @Input() set progressNotesData(progress: any) {
    this.constructProgressNotesData(progress);
  }


  constructor(private store: Store<AppInitialState>, private patientSummaryService: PatientSummaryService,
   private spinnerServiceSVP: SpinnerServiceSVP) {
    this.progressNotesToRender = [];
  }

  ngOnInit(): void {
      this.constructProgressNotesData(this.progressNotesData);
  }

  constructProgressNotesData(body) {
    if(!body && !body.response) return;
      if(body.response.statusCode === '0000') {
        const resources = body.response.resources;
        this.progressNotesToRender = resources;
        this.progressNotesSliced = resources.slice(0, 3);
      }
  }

  onClickViewAllProgressNotes() {
    this.viewAll = true;
    let output = {type: "progressNotes", showAll: true, viewAll: true}
    this.showAllContent.emit(output);
  }
  onClickViewIndividualProgressNotes(progressNotes) {
    let output = {type: "progressNotes", showAll: true, viewAll: false, showPN: true, individualProgressNotes: progressNotes}
    this.showAllContent.emit(output);
  }
   
  onViewProgressNotes() {
    
  }
  onClickviewFullProgressNotes(resources){
    this.patientSummaryService.getProgressNoteFullDocument(resources.documentRef).subscribe((data: any) => {
      if (data) {
        //document.viewStatus = "viewed";
        var htmlContent = window.atob(data.content[0].attachment.data);
        const length = htmlContent.length;
        const newWindow = window.open(data.id + '.html');
        newWindow.document.title = data.description;
        newWindow.document.write(htmlContent);
      } else {
        //this.handleRetry(document);
      }

    }, error => {
     // this.handleRetry(document);
    });
  }
}