import { IPatientSummary } from './../patient-summary.interface';

export interface AppState {
  patientSummary: IPatientSummary
}