import { HttpErrorResponse } from "@angular/common/http";
import { IPatientSummary } from './patient-summary.interface';
import { Action } from '@ngrx/store'

export const PATIENT_SUMMARY_INVOKE = '[Patient Summary API] Invoke';
export const PATIENT_SUMMARY_SUCCESS = '[Patient Summary API] Load Success';
export const PATIENT_SUMMARY_ERROR = '[Patient Summary API] Load Error';


export class PatientSummaryInvoke implements Action {
  readonly type = PATIENT_SUMMARY_INVOKE;
  constructor(public payload:string){}
}

export class PatientSummarySuccess implements Action{
  readonly type = PATIENT_SUMMARY_SUCCESS;
  constructor(public payload:IPatientSummary){}
}

export class PatientSummaryError implements Action{
  readonly type = PATIENT_SUMMARY_ERROR;
  constructor(public payload:HttpErrorResponse){}
}

export type Actions = PatientSummaryInvoke|PatientSummarySuccess|PatientSummaryError