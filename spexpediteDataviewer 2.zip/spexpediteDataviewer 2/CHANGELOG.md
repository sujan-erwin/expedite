# Changelog

## Unreleased 
| **Iteration** | **Stories** |
| ------ | ------ |
| PI-1.6 | [SA2-812](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-812), [SA2-813](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-813), [SA2-655](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-655) | 
| PI-1.7 | [US204102](https://rally1.rallydev.com/#/374705379980d/detail/userstory/375595591252?fdp=true),[US204275](https://rally1.rallydev.com/#/374705379980d/detail/userstory/375622882112?fdp=true),[US204277](https://rally1.rallydev.com/#/374705379980d/detail/userstory/375623398752?fdp=true)

### Added

| **Iteration** | **Stories** |
| ------ | ------ |
| PI-1.2 | [SA2-540](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-540), [SA2-644](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-644), [SA2-645](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-645), [SA2-676](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-676), [SA2-684](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-684), [SA2-727](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-727) | 
| PI-1.3 | [SA2-798](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-798), [SA2-797](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-797), [SA2-681](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-681), [SA2-686](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-686), [SA2-742](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-742) |
| PI-1.4 | [SA2-690](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-690), [SA2-692](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-692), [SA2-688](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-688), [SA2-811](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-811), [SA2-822](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-822), [SA2-823](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-823) |
| PI-1.5 | [SA2-830](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-830), [SA2-831](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-831), [SA2-832](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-832), [SA2-835](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-835),[SA2-880](http://jira.digital-east.cvshealthcloud.com:8080/browse/SA2-880) | 

### Changed

### Removed

### Fixed
